/*
# Allow deleting profiles cleanly (cascade match history)

1. Modified Tables
- `matches`: the foreign key to `profiles` previously had no ON DELETE action,
  so deleting a profile row (e.g. from the Supabase dashboard) failed with
  "update or delete on table profiles violates foreign key constraint
  matches_client_id_fk". The constraint is recreated with ON DELETE CASCADE:
  deleting a profile now automatically deletes that player's match history.

2. Data Safety
- No data is dropped or modified — only the constraint definition changes.
- Match rows for profiles that still exist are untouched.
*/

alter table matches drop constraint if exists matches_client_id_fk;

alter table matches
  add constraint matches_client_id_fk
  foreign key (client_id) references profiles(client_id)
  on delete cascade;