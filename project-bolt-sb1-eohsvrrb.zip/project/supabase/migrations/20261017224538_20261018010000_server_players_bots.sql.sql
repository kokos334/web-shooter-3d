/*
# Server players — bot support columns

1. Modified Tables
- `server_players`: three new columns so the host can publish its bots as
  server-side entities visible to every client:
  - `is_bot` (boolean, default false) — true for bot rows
  - `entity_key` (text, nullable) — the bot's in-match id, used by clients to
    merge these rows with movement broadcasts
  - `is_dead` (boolean, default false) — bot respawn state
  - `owner_id` (uuid, nullable) — the host client that publishes this bot row,
    so its rows can be cleaned up when the host leaves

2. Security
- No changes: existing permissive policies (public shared game state, no-auth
  app) already cover the new columns.

3. Notes
- Human players keep client_id = their per-tab UUID with is_bot = false.
- Bot rows use a random UUID per bot as client_id (primary key needs it) and
  carry the real bot id in entity_key.
*/

alter table server_players add column if not exists is_bot boolean not null default false;
alter table server_players add column if not exists entity_key text;
alter table server_players add column if not exists is_dead boolean not null default false;
alter table server_players add column if not exists owner_id uuid;