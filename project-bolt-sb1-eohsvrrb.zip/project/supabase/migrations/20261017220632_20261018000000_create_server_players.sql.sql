/*
# Server players — database-backed player list per server

1. New Tables
- `server_players`: one row per (player, server) pair. Replaces unreliable
  realtime presence as the source of truth for who is on a server.
  - `client_id` (uuid, part of primary key) — per-tab player id from the browser
  - `server_id` (uuid, part of primary key) — the server being joined
  - `nickname` (text) — in-game name, e.g. "TEST1"
  - `pos_x`, `pos_y`, `pos_z` (real) — current world position, so other clients
    can place the model immediately, before the first movement broadcast
  - `yaw` (real) — facing angle
  - `hp` (int) — current health
  - `kills`, `deaths` (int) — live score for the scoreboard
  - `updated_at` (timestamptz) — heartbeat; rows older than ~10s are stale

2. Security
- RLS enabled on `server_players`. This app has NO sign-in screen: every client
  operates with the anon key, so policies are scoped `TO anon, authenticated`
  and permissive by design — the player list is intentionally public shared
  game state, like the `servers` table.

3. Realtime
- `server_players` (and `servers`) added to the `supabase_realtime` publication
  so clients receive INSERT/UPDATE/DELETE events for the player list.
*/

create table if not exists server_players (
  client_id uuid not null,
  server_id uuid not null references servers(id) on delete cascade,
  nickname text not null default 'Player',
  pos_x real not null default 0,
  pos_y real not null default 0,
  pos_z real not null default 0,
  yaw real not null default 0,
  hp int not null default 100,
  kills int not null default 0,
  deaths int not null default 0,
  updated_at timestamptz not null default now(),
  primary key (client_id, server_id)
);

create index if not exists server_players_server_idx on server_players (server_id);

alter table server_players enable row level security;

drop policy if exists "server_players_read_all" on server_players;
create policy "server_players_read_all" on server_players for select
to anon, authenticated using (true);

drop policy if exists "server_players_insert_any" on server_players;
create policy "server_players_insert_any" on server_players for insert
to anon, authenticated with check (true);

drop policy if exists "server_players_update_any" on server_players;
create policy "server_players_update_any" on server_players for update
to anon, authenticated using (true) with check (true);

drop policy if exists "server_players_delete_any" on server_players;
create policy "server_players_delete_any" on server_players for delete
to anon, authenticated using (true);

do $$
begin
  begin
    alter publication supabase_realtime add table server_players;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table servers;
  exception when duplicate_object then null;
  end;
end $$;