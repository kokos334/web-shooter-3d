/*
# Web Shooter 3D — initial schema

1. New Tables
- `profiles`: one row per player, keyed by a client-generated UUID (no accounts).
  - `client_id` (uuid, primary key) — random UUID from the browser, stored in localStorage
  - `username` (text) — in-game nickname
  - `kills`, `deaths`, `matches_played` (int) — lifetime stats
  - `last_loadout` (jsonb) — last purchased weapon loadout from the buy menu
  - `settings` (jsonb) — crosshair/controls/graphics settings
  - timestamps
- `servers`: joinable game servers shown in the server browser.
  - `id` (uuid, primary key), `name`, `map_name`, `mode`, `max_players`, `bots_count`,
    `region`, `kill_limit`, `password_hash` (nullable sha-256 hex), `host_client_id`,
    `player_count`, `last_ping`, timestamps
- `matches`: per-player match results for the profile history.
  - `id` (uuid primary key), `client_id` (references profiles), `server_name`, `map_name`,
    `kills`, `deaths`, `score`, `duration_sec`, timestamp

2. Functions
- `check_server_password(server_id uuid, pass text) returns boolean` — SECURITY DEFINER RPC
  that compares a SHA-256 hex of the provided password against `servers.password_hash`.
  Returns true for servers without a password.

3. Security
- RLS enabled on all three tables. This app has NO sign-in screen: every client operates
  with the anon key, so all policies are scoped `TO anon, authenticated` and intentionally
  permissive because all game data (profiles, servers, matches) is public/shared by design.
- `check_server_password` is security definer and callable by anon/authenticated.

4. Notes
- `pgcrypto` is enabled for `digest(pass, 'sha256')`.
- 8 seed servers inserted (bots only, no host) for a populated server browser.
*/

create extension if not exists pgcrypto;

create table if not exists profiles (
  client_id uuid primary key,
  username text not null,
  kills int default 0,
  deaths int default 0,
  matches_played int default 0,
  last_loadout jsonb default '{}'::jsonb,
  settings jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists servers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  map_name text not null default 'container_yard',
  mode text not null default 'Deathmatch',
  max_players int default 16,
  bots_count int default 6,
  region text default 'EU',
  kill_limit int default 10,
  password_hash text,
  host_client_id uuid,
  player_count int default 0,
  last_ping int default 40,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists matches (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references profiles(client_id),
  server_name text,
  map_name text,
  kills int,
  deaths int,
  score int,
  duration_sec int,
  created_at timestamptz default now()
);

alter table profiles enable row level security;
alter table servers enable row level security;
alter table matches enable row level security;

drop policy if exists "profiles_read_all" on profiles;
create policy "profiles_read_all" on profiles for select to anon, authenticated using (true);
drop policy if exists "profiles_insert_own" on profiles;
create policy "profiles_insert_own" on profiles for insert to anon, authenticated with check (true);
drop policy if exists "profiles_update_own" on profiles;
create policy "profiles_update_own" on profiles for update to anon, authenticated using (true) with check (true);

drop policy if exists "servers_read_all" on servers;
create policy "servers_read_all" on servers for select to anon, authenticated using (true);
drop policy if exists "servers_insert_own" on servers;
create policy "servers_insert_own" on servers for insert to anon, authenticated with check (true);
drop policy if exists "servers_update_own" on servers;
create policy "servers_update_own" on servers for update to anon, authenticated using (true) with check (true);
drop policy if exists "servers_delete_own" on servers;
create policy "servers_delete_own" on servers for delete to anon, authenticated using (host_client_id is not null);

drop policy if exists "matches_read_all" on matches;
create policy "matches_read_all" on matches for select to anon, authenticated using (true);
drop policy if exists "matches_insert_own" on matches;
create policy "matches_insert_own" on matches for insert to anon, authenticated with check (true);

create or replace function check_server_password(server_id uuid, pass text)
returns boolean language plpgsql security definer as $$
declare stored text;
begin
  select password_hash into stored from servers where id = server_id;
  if stored is null then return true; end if;
  return stored = encode(digest(pass, 'sha256'), 'hex');
end $$;

grant execute on function check_server_password(uuid, text) to anon, authenticated;

insert into servers (name, map_name, mode, max_players, bots_count, region, player_count, last_ping) values
  ('EU | Web Shooter Public #1','container_yard','Deathmatch',16,9,'EU',9,24),
  ('RU | Мясорубка 24/7','warehouse','Deathmatch',20,14,'RU',14,31),
  ('US | Aim Arena | Bot Practice','arena_small','Aim',12,5,'US',5,62),
  ('EU | Warehouse Only','warehouse','Deathmatch',16,7,'EU',7,18),
  ('RU | Container Yard #2','container_yard','Deathmatch',16,11,'RU',11,41),
  ('EU | Chill Bots','arena_small','Deathmatch',10,3,'EU',3,55),
  ('US | Web Shooter 24/7','container_yard','Deathmatch',16,10,'US',10,70),
  ('RU | Новички','arena_small','Deathmatch',12,4,'RU',4,28)
on conflict do nothing;