/*
# Server settings — local servers, join codes, max ping, free kill limit

1. Modified Tables
- `servers`:
  - `is_local` (boolean, default false) — local servers are hidden from the
    public browser list and joinable only by their code
  - `join_code` (text, nullable) — short uppercase code for local servers
  - `max_ping` (int, default 0) — 0 disables the ping cap; otherwise clients
    whose measured ping exceeds it are kicked from the match

2. Security
- No policy changes; existing permissive policies already cover new columns.
*/

alter table servers add column if not exists is_local boolean not null default false;
alter table servers add column if not exists join_code text;
alter table servers add column if not exists max_ping int not null default 0;

create unique index if not exists servers_join_code_idx on servers (join_code) where join_code is not null;