import { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { useStore } from '@/store';
import { net, type PresencePlayer } from '@/game/net';
import { getMapDef } from '@/game/world';

export function LoadingScreen(): React.JSX.Element {
  const joinIntent = useStore((s) => s.joinIntent);
  const setScreen = useStore((s) => s.setScreen);
  const setJoinIntent = useStore((s) => s.setJoinIntent);
  const setCurrentServer = useStore((s) => s.setCurrentServer);
  const [players, setPlayers] = useState<PresencePlayer[]>([]);
  const [connected, setConnected] = useState(false);
  const startedRef = useRef(false);

  useEffect(() => {
    if (!joinIntent?.server || startedRef.current) return;
    startedRef.current = true;
    const server = joinIntent.server;

    const handlers = {
      onMove: () => {},
      onBotState: () => {},
      onHit: () => {},
      onKill: () => {},
      onChat: () => {},
      onPresence: (ps: PresencePlayer[]) => {
        setPlayers(ps);
        setConnected(true);
      },
    };

    net
      .join(
        { id: server.id, name: server.name, map: server.map_name, mode: server.mode, killLimit: server.kill_limit, botsCount: server.bots_count },
        handlers
      )
      .catch(() => setConnected(true));

    // hold presence briefly, then hand the (already joined) connection to the match
    const minWait = new Promise((r) => setTimeout(r, 1200));
    minWait.then(() => {
      setCurrentServer(server);
      setJoinIntent(null);
      setScreen('match');
    });

    return () => {
      // keep the connection alive across the screen transition (Match reuses `net`)
    };
  }, [joinIntent, setScreen, setJoinIntent, setCurrentServer]);

  const server = joinIntent?.server;
  const mapName = server ? getMapDef(server.map_name).name : '';

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center">
      <div className="text-center max-w-md px-6">
        <Loader2 size={40} className="mx-auto animate-spin text-emerald-400" />
        <h2 className="text-2xl font-bold font-mono mt-4 tracking-wider">{server?.name ?? 'Connecting…'}</h2>
        <p className="text-white/50 font-mono text-sm mt-1">{mapName} · {server?.mode} · first to {server?.kill_limit} kills</p>
        {server?.is_local && server.join_code && (
          <div className="mt-3 inline-block bg-zinc-900 border border-emerald-400/40 rounded px-4 py-2">
            <div className="text-[10px] uppercase tracking-widest text-emerald-300/70">Local server — share this code</div>
            <div className="text-xl font-bold font-mono tracking-[0.3em] text-emerald-300">{server.join_code}</div>
          </div>
        )}
        <div className="mt-6 font-mono text-sm">
          <div className={connected ? 'text-emerald-300' : 'text-white/40'}>
            {connected ? 'Connected to realtime channel' : 'Connecting to realtime channel…'}
          </div>
          <div className="text-white/40 mt-1">
            {players.filter((p) => p.client_id !== useStore.getState().clientId).length + 1} player
            {players.length === 0 ? '' : 's'} online (including you)
          </div>
        </div>
      </div>
    </div>
  );
}
