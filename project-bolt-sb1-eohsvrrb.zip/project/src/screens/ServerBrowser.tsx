import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, RefreshCw, Lock, Plus, Users, Bot as BotIcon, Signal, KeyRound } from 'lucide-react';
import { useStore, type ServerRow } from '@/store';
import { fetchServers } from '@/game/serverApi';
import { samplePing } from '@/game/ping';
import { getSupabase } from '@/lib/supabase';
import { getMapDef } from '@/game/world';
import { checkPassword, createServer } from '@/game/serverApi';
import { MAPS, MODES, MODE_DEFS, REGIONS, KILL_LIMIT_CHOICES, MAX_PING_CHOICES, BOT_DIFFICULTIES, botDifficultyConfig, modeDef, type BotDifficulty } from '@/game/constants';

type SortKey = 'name' | 'map_name' | 'player_count' | 'bots_count' | 'bot_difficulty' | 'region' | 'mode';

export function ServerBrowser(): React.JSX.Element {
  const setScreen = useStore((s) => s.setScreen);
  const setJoinIntent = useStore((s) => s.setJoinIntent);
  const [servers, setServers] = useState<ServerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('player_count');
  const [sortAsc, setSortAsc] = useState(false);
  const [fRegion, setFRegion] = useState('all');
  const [fMode, setFMode] = useState('all');
  const [hideFull, setHideFull] = useState(false);
  const [hidePass, setHidePass] = useState(false);
  const [pwTarget, setPwTarget] = useState<ServerRow | null>(null);
  const [pwInput, setPwInput] = useState('');
  const [pwError, setPwError] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const clientId = useStore((s) => s.clientId);
  const [myPing, setMyPing] = useState(0);

  useEffect(() => {
    let alive = true;
    const run = async () => {
      const p = await samplePing();
      if (alive && p != null) setMyPing(p);
    };
    void run();
    const iv = setInterval(() => void run(), 5000);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, []);

  const refetch = async () => {
    try {
      setError('');
      const rows = await fetchServers();
      setServers(rows);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load servers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
    const ch = getSupabase()
      .channel('servers-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'servers' }, () => refetch())
      .subscribe();
    return () => {
      getSupabase().removeChannel(ch);
    };
  }, []);

  const filtered = useMemo(() => {
    let list = servers.filter((s) => {
      if (fRegion !== 'all' && s.region !== fRegion) return false;
      if (fMode !== 'all' && s.mode !== fMode) return false;
      if (hideFull && s.player_count >= s.max_players) return false;
      if (hidePass && s.password_hash) return false;
      return true;
    });
    list = [...list].sort((a, b) => {
      const av = a[sortKey] ?? '';
      const bv = b[sortKey] ?? '';
      const cmp = typeof av === 'string' && typeof bv === 'string' ? av.localeCompare(bv) : Number(av) - Number(bv);
      return sortAsc ? cmp : -cmp;
    });
    return list;
  }, [servers, sortKey, sortAsc, fRegion, fMode, hideFull, hidePass]);

  const sortBy = (k: SortKey) => {
    if (sortKey === k) setSortAsc((v) => !v);
    else {
      setSortKey(k);
      setSortAsc(k === 'name' || k === 'region' || k === 'mode' || k === 'map_name' || k === 'bot_difficulty');
    }
  };

  const connect = async (s: ServerRow) => {
    if (s.password_hash) {
      setPwTarget(s);
      setPwInput('');
      setPwError('');
      return;
    }
    setJoinIntent({ server: s });
    setScreen('loading');
  };

  const submitPassword = async () => {
    if (!pwTarget) return;
    const ok = await checkPassword(pwTarget.id, pwInput);
    if (ok) {
      const s = pwTarget;
      setPwTarget(null);
      setJoinIntent({ server: s });
      setScreen('loading');
    } else {
      setPwError('Wrong password');
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <header className="flex items-center justify-between px-6 py-4 border-b border-white/10">
        <div className="flex items-center gap-4">
          <button onClick={() => setScreen('main_menu')} className="flex items-center gap-2 text-white/70 hover:text-white font-mono text-sm">
            <ArrowLeft size={18} /> Back
          </button>
          <h1 className="text-xl font-bold font-mono tracking-wider">SERVER BROWSER</h1>
        </div>
        <div className="flex gap-2">
          <button onClick={refetch} className="flex items-center gap-2 px-3 py-1.5 rounded bg-white/10 hover:bg-white/20 text-sm font-mono">
            <RefreshCw size={15} /> Refresh
          </button>
          <button onClick={() => setScreen('join_code')} className="flex items-center gap-2 px-3 py-1.5 rounded bg-white/10 hover:bg-white/20 text-sm font-mono">
            <KeyRound size={15} /> Join by code
          </button>
          <button onClick={() => setShowCreate(true)} className="flex items-center gap-2 px-3 py-1.5 rounded bg-emerald-500 hover:bg-emerald-400 text-black text-sm font-bold font-mono">
            <Plus size={15} /> Create Server
          </button>
        </div>
      </header>

      {/* filters */}
      <div className="flex flex-wrap gap-3 px-6 py-3 border-b border-white/5 text-sm font-mono">
        <select value={fRegion} onChange={(e) => setFRegion(e.target.value)} className="bg-zinc-900 border border-white/10 rounded px-2 py-1">
          <option value="all">All regions</option>
          {REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
        </select>
        <select value={fMode} onChange={(e) => setFMode(e.target.value)} className="bg-zinc-900 border border-white/10 rounded px-2 py-1">
          <option value="all">All modes</option>
          {MODES.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <label className="flex items-center gap-2 text-white/70">
          <input type="checkbox" checked={hideFull} onChange={(e) => setHideFull(e.target.checked)} /> Hide full
        </label>
        <label className="flex items-center gap-2 text-white/70">
          <input type="checkbox" checked={hidePass} onChange={(e) => setHidePass(e.target.checked)} /> Hide passworded
        </label>
        <span className="ml-auto text-white/40">{filtered.length} servers</span>
      </div>

      <main className="px-6 py-4">
        {loading ? (
          <div className="text-white/50 font-mono py-10 text-center">Loading servers…</div>
        ) : error ? (
          <div className="text-red-300 font-mono py-10 text-center">{error}</div>
        ) : (
          <div className="overflow-x-auto rounded-lg border border-white/10">
            <table className="w-full text-sm font-mono">
              <thead className="bg-white/5 text-white/50 text-xs uppercase">
                <tr>
                  <th className="px-3 py-2"></th>
                  {([['name', 'Name'], ['map_name', 'Map'], ['player_count', 'Players'], ['bots_count', 'Bots'], ['bot_difficulty', 'Difficulty'], ['region', 'Region'], ['mode', 'Mode']] as [SortKey, string][]).map(([k, label]) => (
                    <th key={k} className="px-3 py-2 text-left cursor-pointer hover:text-white select-none" onClick={() => sortBy(k)}>
                      {label}{sortKey === k ? (sortAsc ? ' ▲' : ' ▼') : ''}
                    </th>
                  ))}
                  <th className="px-3 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => {
                  const full = s.player_count >= s.max_players;
                  return (
                    <tr
                      key={s.id}
                      onDoubleClick={() => connect(s)}
                      className={`border-t border-white/5 hover:bg-white/5 ${full ? 'opacity-50' : ''}`}
                    >
                      <td className="px-3 py-2.5">{s.password_hash ? <Lock size={14} className="text-amber-300" /> : null}</td>
                      <td className="px-3 py-2.5 font-bold">{s.name}</td>
                      <td className="px-3 py-2.5 text-white/70">{getMapDef(s.map_name).name}</td>
                      <td className="px-3 py-2.5"><span className="inline-flex items-center gap-1"><Users size={13} /> {s.player_count}/{s.max_players}</span></td>
                      <td className="px-3 py-2.5 text-white/70"><span className="inline-flex items-center gap-1"><BotIcon size={13} /> {s.bots_count}</span></td>
                      <td className="px-3 py-2.5"><span className={`inline-flex items-center gap-1 font-bold ${botDifficultyConfig(s.bot_difficulty).color}`}>{botDifficultyConfig(s.bot_difficulty).label}</span></td>
                      <td className="px-3 py-2.5"><span className={`inline-flex items-center gap-1 ${myPing < 60 ? 'text-emerald-300' : myPing < 120 ? 'text-amber-300' : 'text-red-300'}`}><Signal size={13} /> {myPing || '…'}ms</span></td>
                      <td className="px-3 py-2.5 text-white/70">{s.region}</td>
                      <td className="px-3 py-2.5 text-white/70">{s.mode}</td>
                      <td className="px-3 py-2.5">
                        <button
                          disabled={full}
                          onClick={() => connect(s)}
                          className="px-3 py-1 rounded bg-emerald-500/90 hover:bg-emerald-400 disabled:opacity-40 disabled:cursor-not-allowed text-black text-xs font-bold"
                        >
                          Connect
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr><td colSpan={10} className="px-3 py-8 text-center text-white/40">No servers match your filters. Create one!</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
        <p className="text-xs text-white/30 font-mono mt-3">Tip: double-click a row to connect</p>
      </main>

      {/* password modal */}
      {pwTarget && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="w-80 bg-zinc-900 border border-white/15 rounded-xl p-5 font-mono">
            <h3 className="text-white font-bold mb-1">Server password</h3>
            <p className="text-xs text-white/50 mb-3">{pwTarget.name}</p>
            <input
              autoFocus
              type="password"
              value={pwInput}
              onChange={(e) => setPwInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submitPassword()}
              placeholder="Password (4–32 chars)"
              className="w-full bg-black/40 border border-white/15 rounded px-3 py-2 text-white mb-2"
            />
            {pwError && <div className="text-red-300 text-xs mb-2">{pwError}</div>}
            <div className="flex gap-2 justify-end">
              <button onClick={() => setPwTarget(null)} className="px-3 py-1.5 rounded bg-white/10 hover:bg-white/20 text-sm">Cancel</button>
              <button onClick={submitPassword} className="px-3 py-1.5 rounded bg-emerald-500 hover:bg-emerald-400 text-black text-sm font-bold">Join</button>
            </div>
          </div>
        </div>
      )}

      {showCreate && <CreateServerModal onClose={() => setShowCreate(false)} clientId={clientId} />}
    </div>
  );
}

function CreateServerModal({ onClose, clientId }: { onClose: () => void; clientId: string }): React.JSX.Element {
  const setJoinIntent = useStore((s) => s.setJoinIntent);
  const setScreen = useStore((s) => s.setScreen);
  const [name, setName] = useState('');
  const [map, setMap] = useState(MAPS[0].id);
  const [mode, setMode] = useState(MODES[0]);
  const [maxPlayers, setMaxPlayers] = useState(16);
  const [botsCount, setBotsCount] = useState(6);
  const [password, setPassword] = useState('');
  const [region, setRegion] = useState(REGIONS[0]);
  const [killLimit, setKillLimit] = useState(10);
  const [killLimitCustom, setKillLimitCustom] = useState('');
  const [isLocal, setIsLocal] = useState(false);
  const [maxPing, setMaxPing] = useState(0);
  const [botDifficulty, setBotDifficulty] = useState<BotDifficulty>('normal');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const parsedCustom = parseInt(killLimitCustom, 10);
  const effectiveKillLimit = killLimitCustom.trim() !== '' && !Number.isNaN(parsedCustom) && parsedCustom >= 1 && parsedCustom <= 100000
    ? parsedCustom
    : killLimit;
  const valid = name.trim().length >= 3 && name.trim().length <= 40 && (password === '' || (password.length >= 4 && password.length <= 32));

  const submit = async () => {
    if (!valid || busy) return;
    setBusy(true);
    setErr('');
    try {
      const row = await createServer({
        name: name.trim(),
        map,
        mode,
        maxPlayers,
        botsCount,
        region,
        killLimit: effectiveKillLimit,
        password: isLocal ? '' : password,
        hostClientId: clientId,
        botDifficulty,
        isLocal,
        maxPing,
      });
      setJoinIntent({ server: row, created: true });
      setScreen('loading');
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Failed to create server');
      setBusy(false);
    }
  };

  const field = 'w-full bg-black/40 border border-white/15 rounded px-3 py-2 text-white text-sm';
  const label = 'block text-xs uppercase tracking-wider text-white/50 mb-1 font-mono';

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-zinc-900 border border-white/15 rounded-xl p-6 font-mono text-white max-h-[90vh] overflow-y-auto">
        <h3 className="text-lg font-bold mb-4 tracking-wider">CREATE SERVER</h3>
        <div className="space-y-3">
          <div>
            <label className={label}>Server type</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setIsLocal(false)}
                className={`rounded border px-3 py-2 text-sm text-left transition-colors ${
                  !isLocal ? 'border-emerald-400 bg-emerald-400/10' : 'border-white/15 hover:border-white/30'
                }`}
              >
                <div className="font-bold">Public</div>
                <div className="text-xs text-white/40">Shown to everyone</div>
              </button>
              <button
                onClick={() => setIsLocal(true)}
                className={`rounded border px-3 py-2 text-sm text-left transition-colors ${
                  isLocal ? 'border-emerald-400 bg-emerald-400/10' : 'border-white/15 hover:border-white/30'
                }`}
              >
                <div className="font-bold">Local</div>
                <div className="text-xs text-white/40">Hidden — join by code</div>
              </button>
            </div>
          </div>
          <div>
            <label className={label}>Server name</label>
            <input className={field} value={name} onChange={(e) => setName(e.target.value)} placeholder="My cool server" maxLength={40} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className={label}>Map</label>
              <select className={field} value={map} onChange={(e) => setMap(e.target.value as typeof map)}>
                {MAPS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
              </select>
            </div>
            <div>
              <label className={label}>Mode</label>
              <select className={field} value={mode} onChange={(e) => setMode(e.target.value as typeof mode)}>
                {MODE_DEFS.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
              </select>
              <p className="text-xs text-white/40 mt-1">{modeDef(mode).description}</p>
            </div>
            <div>
              <label className={label}>Region</label>
              <select className={field} value={region} onChange={(e) => setRegion(e.target.value as typeof region)} disabled={isLocal}>
                {REGIONS.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div>
              <label className={label}>Kill limit</label>
              <select
                className={field}
                value={killLimitCustom.trim() !== '' ? 'custom' : killLimit}
                onChange={(e) => {
                  if (e.target.value === 'custom') setKillLimitCustom('25');
                  else { setKillLimitCustom(''); setKillLimit(Number(e.target.value)); }
                }}
              >
                {KILL_LIMIT_CHOICES.map((k) => <option key={k} value={k}>{k} kills</option>)}
                <option value="custom">Custom…</option>
              </select>
              {killLimitCustom.trim() !== '' && (
                <input
                  type="number"
                  min={1}
                  max={100000}
                  value={killLimitCustom}
                  onChange={(e) => setKillLimitCustom(e.target.value)}
                  placeholder="e.g. 250"
                  className={`${field} mt-2`}
                  autoFocus
                />
              )}
            </div>
          </div>
          <div>
            <label className={label}>Max ping: {maxPing === 0 ? 'no limit' : `${maxPing} ms`}</label>
            <select className={field} value={maxPing} onChange={(e) => setMaxPing(Number(e.target.value))}>
              {MAX_PING_CHOICES.map((p) => (
                <option key={p} value={p}>{p === 0 ? 'No limit (default)' : `${p} ms — kick above`}</option>
              ))}
            </select>
            <p className="text-xs text-white/40 mt-1">Players whose ping goes above the cap are kicked from the match</p>
          </div>
          <div>
            <label className={label}>Max players: {maxPlayers}</label>
            <input type="range" min={2} max={16} value={maxPlayers} onChange={(e) => setMaxPlayers(Number(e.target.value))} className="w-full accent-emerald-400" />
          </div>
          <div>
            <label className={label}>Bots: {botsCount}</label>
            <input type="range" min={0} max={14} value={botsCount} onChange={(e) => setBotsCount(Number(e.target.value))} className="w-full accent-emerald-400" />
          </div>
          <div>
            <label className={label}>Bot difficulty</label>
            <div className="grid grid-cols-2 gap-2">
              {BOT_DIFFICULTIES.map((d) => (
                <label
                  key={d.id}
                  className={`flex items-center gap-2 rounded border px-3 py-2 text-sm cursor-pointer transition-colors ${
                    botDifficulty === d.id ? 'border-emerald-400 bg-emerald-400/10' : 'border-white/15 hover:border-white/30'
                  }`}
                >
                  <input
                    type="radio"
                    name="bot_difficulty"
                    checked={botDifficulty === d.id}
                    onChange={() => setBotDifficulty(d.id)}
                    className="accent-emerald-400"
                  />
                  <span className={`font-bold ${d.color}`}>{d.label}</span>
                  <span className="ml-auto text-white/40 text-xs">{d.reactionDelayMs >= 1000 ? `${d.reactionDelayMs / 1000}s` : `${d.reactionDelayMs}ms`}</span>
                </label>
              ))}
            </div>
            <p className="text-xs text-white/40 mt-1">How long bots take to open fire after spotting you</p>
          </div>
          {!isLocal && (
            <div>
              <label className={label}>Password (optional)</label>
              <input type="password" className={field} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Empty = public" maxLength={32} />
            </div>
          )}
          {err && <div className="text-red-300 text-sm">{err}</div>}
          <div className="flex gap-2 justify-end pt-2">
            <button onClick={onClose} className="px-4 py-2 rounded bg-white/10 hover:bg-white/20 text-sm">Cancel</button>
            <button
              onClick={submit}
              disabled={!valid || busy}
              className="px-4 py-2 rounded bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-black text-sm font-bold"
            >
              {busy ? 'Creating…' : 'Create & Host'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
