import { useEffect, useState } from 'react';
import { ArrowLeft, Trophy, Skull, Swords, Timer } from 'lucide-react';
import { useStore } from '@/store';
import { getSupabase } from '@/lib/supabase';

interface MatchRow {
  id: string;
  server_name: string;
  map_name: string;
  kills: number;
  deaths: number;
  score: number;
  duration_sec: number;
  created_at: string;
}

export function ProfileScreen(): React.JSX.Element {
  const setScreen = useStore((s) => s.setScreen);
  const clientId = useStore((s) => s.clientId);
  const nickname = useStore((s) => s.nickname);
  const [matches, setMatches] = useState<MatchRow[]>([]);
  const [stats, setStats] = useState({ kills: 0, deaths: 0, matches_played: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const sb = getSupabase();
      const [mres, pres] = await Promise.all([
        sb.from('matches').select('*').eq('client_id', clientId).order('created_at', { ascending: false }).limit(15),
        sb.from('profiles').select('kills, deaths, matches_played').eq('client_id', clientId).maybeSingle(),
      ]);
      setMatches((mres.data ?? []) as MatchRow[]);
      if (pres.data) setStats(pres.data as typeof stats);
      setLoading(false);
    };
    load();
  }, [clientId]);

  const kd = stats.deaths === 0 ? stats.kills.toFixed(2) : (stats.kills / stats.deaths).toFixed(2);

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <header className="flex items-center gap-4 px-6 py-4 border-b border-white/10">
        <button onClick={() => setScreen('main_menu')} className="flex items-center gap-2 text-white/70 hover:text-white font-mono text-sm">
          <ArrowLeft size={18} /> Back
        </button>
        <h1 className="text-xl font-bold font-mono tracking-wider">PROFILE</h1>
      </header>

      <main className="px-6 py-6 max-w-3xl">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-14 h-14 rounded-lg bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-2xl font-black text-emerald-300 font-mono">
            {(nickname || 'P')[0].toUpperCase()}
          </div>
          <div>
            <div className="text-2xl font-bold font-mono">{nickname || 'Player'}</div>
            <div className="text-xs text-white/40 font-mono">client {clientId.slice(0, 8)}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
          <StatCard icon={<Trophy size={18} className="text-emerald-300" />} label="Kills" value={stats.kills} />
          <StatCard icon={<Skull size={18} className="text-red-300" />} label="Deaths" value={stats.deaths} />
          <StatCard icon={<Swords size={18} className="text-amber-300" />} label="K/D" value={kd} />
          <StatCard icon={<Timer size={18} className="text-sky-300" />} label="Matches" value={stats.matches_played} />
        </div>

        <h2 className="text-sm font-bold uppercase tracking-wider text-white/50 font-mono mb-3">Recent matches</h2>
        {loading ? (
          <div className="text-white/40 font-mono text-sm">Loading…</div>
        ) : matches.length === 0 ? (
          <div className="text-white/40 font-mono text-sm">No matches yet. Go play one!</div>
        ) : (
          <div className="rounded-lg border border-white/10 overflow-hidden">
            <table className="w-full text-sm font-mono">
              <thead className="bg-white/5 text-white/50 text-xs uppercase">
                <tr>
                  <th className="px-3 py-2 text-left">Server</th>
                  <th className="px-3 py-2 text-left">Map</th>
                  <th className="px-3 py-2 text-right">K</th>
                  <th className="px-3 py-2 text-right">D</th>
                  <th className="px-3 py-2 text-right">Score</th>
                  <th className="px-3 py-2 text-right">Time</th>
                </tr>
              </thead>
              <tbody>
                {matches.map((m) => (
                  <tr key={m.id} className="border-t border-white/5">
                    <td className="px-3 py-2">{m.server_name ?? '—'}</td>
                    <td className="px-3 py-2 text-white/60">{m.map_name}</td>
                    <td className="px-3 py-2 text-right text-emerald-300">{m.kills}</td>
                    <td className="px-3 py-2 text-right text-red-300">{m.deaths}</td>
                    <td className="px-3 py-2 text-right">{m.score}</td>
                    <td className="px-3 py-2 text-right text-white/60">{Math.floor((m.duration_sec ?? 0) / 60)}:{String((m.duration_sec ?? 0) % 60).padStart(2, '0')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: number | string }): React.JSX.Element {
  return (
    <div className="bg-white/5 border border-white/10 rounded-lg px-4 py-3">
      <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-white/50 font-mono">{icon} {label}</div>
      <div className="text-2xl font-bold font-mono mt-1">{value}</div>
    </div>
  );
}
