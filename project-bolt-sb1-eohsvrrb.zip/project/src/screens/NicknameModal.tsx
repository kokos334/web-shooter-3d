import { useState } from 'react';
import { useStore } from '@/store';
import { isValidNickname } from '@/game/constants';
import { getSupabase } from '@/lib/supabase';

export function NicknameModal(): React.JSX.Element | null {
  const nickname = useStore((s) => s.nickname);
  const nicknameConfirmed = useStore((s) => s.nicknameConfirmed);
  const confirmNickname = useStore((s) => s.confirmNickname);
  const setNickname = useStore((s) => s.setNickname);
  const clientId = useStore((s) => s.clientId);
  const [draft, setDraft] = useState(nickname);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  // guard against legacy persisted state where the modal was dismissed with
  // an empty nickname saved — keep asking until a valid nickname exists
  if (nicknameConfirmed && isValidNickname(nickname)) return null;

  const save = async () => {
    const n = draft.trim();
    if (!isValidNickname(n)) {
      setError('3–16 characters: letters, numbers and _ only');
      return;
    }
    setBusy(true);
    setNickname(n);
    await getSupabase()
      .from('profiles')
      .upsert({ client_id: clientId, username: n })
      .then();
    confirmNickname();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm bg-zinc-900 border border-white/15 rounded-xl p-6 font-mono text-white">
        <h2 className="text-xl font-bold tracking-wider mb-1">WELCOME</h2>
        <p className="text-xs text-white/50 mb-4">Pick a nickname before you play</p>
        <input
          autoFocus
          value={draft}
          maxLength={16}
          onChange={(e) => { setDraft(e.target.value); setError(''); }}
          onKeyDown={(e) => e.key === 'Enter' && save()}
          placeholder="e.g. NoScope_Nina"
          className="w-full bg-black/40 border border-white/15 rounded px-3 py-2.5 text-white mb-2"
        />
        {error && <div className="text-red-300 text-xs mb-2">{error}</div>}
        <button
          onClick={save}
          disabled={busy || !isValidNickname(draft.trim())}
          className="w-full px-4 py-2.5 rounded bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-black text-sm font-bold"
        >
          {busy ? 'Saving…' : 'Enter the game'}
        </button>
      </div>
    </div>
  );
}
