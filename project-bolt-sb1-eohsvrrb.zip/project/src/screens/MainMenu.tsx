import { useEffect } from 'react';
import { Play, Settings, User, KeyRound, ShoppingCart } from 'lucide-react';
import { useStore } from '@/store';
import { MenuBackground } from '@/game/components/MenuBackground';
import { getSupabase } from '@/lib/supabase';
import { ECONOMY } from '@/game/constants';

export function MainMenu(): React.JSX.Element {
  const setScreen = useStore((s) => s.setScreen);
  const nickname = useStore((s) => s.nickname);
  const money = useStore((s) => s.money);

  useEffect(() => {
    // ensure profile row exists
    const st = useStore.getState();
    if (!st.nickname) return;
    getSupabase()
      .from('profiles')
      .upsert({ client_id: st.clientId, username: st.nickname })
      .then();
  }, [nickname]);

  const btn = 'w-72 flex items-center gap-3 px-5 py-3.5 rounded-lg border text-left font-bold tracking-wide transition-all duration-150';

  return (
    <div className="min-h-screen text-white relative overflow-hidden">
      <MenuBackground />
      <div className="relative z-10 min-h-screen flex flex-col">
        <header className="flex justify-between items-center px-6 py-4">
          <div className="font-mono text-sm text-white/50">WEB SHOOTER 3D</div>
          <div className="flex items-center gap-4 font-mono text-sm">
            <span className="text-emerald-300 font-bold">${money}</span>
            <span className="px-3 py-1 rounded bg-white/10 border border-white/15">{nickname || 'Player'}</span>
          </div>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center gap-8 px-6">
          <div className="text-center">
            <h1 className="text-5xl sm:text-7xl font-black tracking-tight font-mono">
              WEB <span className="text-amber-400">SHOOTER</span>&nbsp;3D BETA
            </h1>
            <p className="text-white/50 mt-3 font-mono text-sm">Browser FPS · bots · live servers · CS-style economy</p>
          </div>

          <div className="flex flex-col gap-3">
            <button onClick={() => setScreen('server_browser')} className={`${btn} bg-emerald-500/90 hover:bg-emerald-400 border-emerald-300/30 text-black text-lg`}>
              <Play size={20} /> PLAY
            </button>
            <button onClick={() => setScreen('server_browser')} className={`${btn} bg-white/5 hover:bg-white/15 border-white/15 text-white/80`}>
              <ShoppingCart size={20} /> BUY LOADOUT <span className="ml-auto text-xs text-white/40 font-normal">in match · B</span>
            </button>
            <button onClick={() => setScreen('server_browser')} className={`${btn} bg-white/5 hover:bg-white/15 border-white/15 text-white/80`}>
              <KeyRound size={20} /> JOIN BY CODE <span className="ml-auto text-xs text-white/40 font-normal">local servers</span>
            </button>
            <button onClick={() => setScreen('settings')} className={`${btn} bg-white/5 hover:bg-white/15 border-white/15 text-white/80`}>
              <Settings size={20} /> SETTINGS
            </button>
            <button onClick={() => setScreen('profile')} className={`${btn} bg-white/5 hover:bg-white/15 border-white/15 text-white/80`}>
              <User size={20} /> PROFILE
            </button>
          </div>

          <div className="text-xs text-white/30 font-mono">
            Start money ${ECONOMY.start} · +${ECONOMY.kill}/kill · win +${ECONOMY.win} · loss +${ECONOMY.loss}
          </div>
        </main>
      </div>
    </div>
  );
}
