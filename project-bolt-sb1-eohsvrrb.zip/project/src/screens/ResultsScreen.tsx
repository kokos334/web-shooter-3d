import { useEffect } from 'react';
import { RotateCcw, Home, Trophy, Medal } from 'lucide-react';
import { useStore } from '@/store';
import { net } from '@/game/net';

export function ResultsScreen(): React.JSX.Element {
  const results = useStore((s) => s.results);
  const setScreen = useStore((s) => s.setScreen);
  const setJoinIntent = useStore((s) => s.setJoinIntent);
  const currentServer = useStore((s) => s.currentServer);
  const money = useStore((s) => s.money);

  useEffect(() => {
    net.leave();
    // grant win/loss economy bonus
    if (results) {
      const st = useStore.getState();
      st.setMoney(st.money + (results.won ? 1400 : 600));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const playAgain = () => {
    if (currentServer) {
      setJoinIntent({ server: currentServer });
      setScreen('loading');
    } else {
      setScreen('server_browser');
    }
  };

  if (!results) {
    return (
      <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center font-mono">
        No results. <button onClick={() => setScreen('main_menu')} className="underline ml-2">Main menu</button>
      </div>
    );
  }

  const mins = Math.floor(results.durationSec / 60);
  const secs = results.durationSec % 60;
  const kd = results.deaths === 0 ? results.kills.toFixed(2) : (results.kills / results.deaths).toFixed(2);

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center p-4">
      <div className="w-full max-w-xl">
        <div className="text-center mb-6">
          <div className={`inline-flex items-center gap-2 text-3xl font-black font-mono tracking-wider ${results.won ? 'text-emerald-300' : 'text-amber-300'}`}>
            {results.won ? <Trophy size={28} /> : <Medal size={28} />}
            {results.won ? 'VICTORY' : 'MATCH OVER'}
          </div>
          <div className="text-white/40 font-mono text-sm mt-1">{results.serverName} · {results.mapName}</div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6 font-mono">
          <Cell label="Kills" value={results.kills} tone="text-emerald-300" />
          <Cell label="Deaths" value={results.deaths} tone="text-red-300" />
          <Cell label="K/D" value={kd} tone="text-amber-300" />
          <Cell label="Duration" value={`${mins}:${String(secs).padStart(2, '0')}`} tone="text-sky-300" />
        </div>

        <div className="rounded-lg border border-white/10 overflow-hidden mb-6">
          <table className="w-full text-sm font-mono">
            <thead className="bg-white/5 text-white/50 text-xs uppercase">
              <tr>
                <th className="px-3 py-2 text-left">#</th>
                <th className="px-3 py-2 text-left">Player</th>
                <th className="px-3 py-2 text-right">Kills</th>
                <th className="px-3 py-2 text-right">Deaths</th>
                <th className="px-3 py-2 text-right">Score</th>
              </tr>
            </thead>
            <tbody>
              {results.leaderboard.map((p, i) => (
                <tr key={p.id} className={`border-t border-white/5 ${p.isLocal ? 'bg-emerald-500/10 text-emerald-300 font-bold' : p.isBot ? 'text-red-300/80' : 'text-sky-300/80'}`}>
                  <td className="px-3 py-2">{i + 1}</td>
                  <td className="px-3 py-2">{p.nickname}{p.isBot ? ' [BOT]' : ''}</td>
                  <td className="px-3 py-2 text-right">{p.kills}</td>
                  <td className="px-3 py-2 text-right">{p.deaths}</td>
                  <td className="px-3 py-2 text-right">{p.kills * 2 - p.deaths}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="text-center text-white/50 font-mono text-sm mb-6">
          Balance: <span className="text-emerald-300 font-bold">${money}</span>
        </div>

        <div className="flex gap-3 justify-center">
          <button onClick={playAgain} className="flex items-center gap-2 px-6 py-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-bold font-mono">
            <RotateCcw size={18} /> PLAY AGAIN
          </button>
          <button onClick={() => setScreen('main_menu')} className="flex items-center gap-2 px-6 py-3 rounded-lg bg-white/10 hover:bg-white/20 font-bold font-mono">
            <Home size={18} /> MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
}

function Cell({ label, value, tone }: { label: string; value: number | string; tone: string }): React.JSX.Element {
  return (
    <div className="bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-center">
      <div className="text-xs uppercase tracking-wider text-white/50">{label}</div>
      <div className={`text-2xl font-bold mt-1 ${tone}`}>{value}</div>
    </div>
  );
}
