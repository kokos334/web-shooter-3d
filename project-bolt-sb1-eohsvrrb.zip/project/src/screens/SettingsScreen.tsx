import { useEffect, useState } from 'react';
import { ArrowLeft, Crosshair, Keyboard, Monitor, User } from 'lucide-react';
import { useStore } from '@/store';
import {
  DEFAULT_KEYBINDS, DEFAULT_SETTINGS, REBINDABLE_ACTIONS, keyLabel, isValidNickname,
  type GameSettings,
} from '@/game/constants';
import { getSupabase } from '@/lib/supabase';
import { Crosshair as CrosshairPreview } from '@/game/components/Crosshair';

type Tab = 'crosshair' | 'nickname' | 'controls' | 'graphics';

const inputCls = 'bg-black/40 border border-white/15 rounded px-3 py-2 text-white text-sm font-mono w-full';
const labelCls = 'block text-xs uppercase tracking-wider text-white/50 mb-1 font-mono';

export function SettingsScreen(): React.JSX.Element {
  const setScreen = useStore((s) => s.setScreen);
  const settings = useStore((s) => s.settings);
  const updateSettings = useStore((s) => s.updateSettings);
  const nickname = useStore((s) => s.nickname);
  const setNickname = useStore((s) => s.setNickname);
  const clientId = useStore((s) => s.clientId);
  const [tab, setTab] = useState<Tab>('crosshair');
  const [nickDraft, setNickDraft] = useState(nickname);
  const [nickMsg, setNickMsg] = useState('');
  const [rebinding, setRebinding] = useState<string | null>(null);

  const saveProfile = (username: string, allSettings: GameSettings) => {
    getSupabase()
      .from('profiles')
      .upsert({ client_id: clientId, username, settings: allSettings })
      .then();
  };

  const saveNick = () => {
    const n = nickDraft.trim();
    if (!isValidNickname(n)) {
      setNickMsg('3–16 chars, letters, numbers and _ only');
      return;
    }
    setNickname(n);
    saveProfile(n, settings);
    setNickMsg('Saved!');
    setTimeout(() => setNickMsg(''), 1500);
  };

  useEffect(() => {
    if (!rebinding) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      if (e.code === 'Escape') {
        setRebinding(null);
        return;
      }
      const kb = { ...settings.keybinds };
      for (const [action, code] of Object.entries(kb)) {
        if (code === e.code && action !== rebinding) kb[action] = '';
      }
      kb[rebinding] = e.code;
      updateSettings({ keybinds: kb });
      saveProfile(nickname, { ...settings, keybinds: kb });
      setRebinding(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [rebinding, settings, nickname, updateSettings]);

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <header className="flex items-center gap-4 px-6 py-4 border-b border-white/10">
        <button onClick={() => setScreen('main_menu')} className="flex items-center gap-2 text-white/70 hover:text-white font-mono text-sm">
          <ArrowLeft size={18} /> Back
        </button>
        <h1 className="text-xl font-bold font-mono tracking-wider">SETTINGS</h1>
      </header>

      <div className="flex gap-1 px-6 pt-4 font-mono text-sm">
        {([
          ['crosshair', 'Crosshair', Crosshair],
          ['nickname', 'Nickname', User],
          ['controls', 'Controls', Keyboard],
          ['graphics', 'Graphics', Monitor],
        ] as [Tab, string, React.ComponentType<{ size?: number }>][]).map(([id, label, Icon]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-t-lg border-b-2 ${tab === id ? 'border-emerald-400 bg-white/5 text-white' : 'border-transparent text-white/50 hover:text-white'}`}
          >
            <Icon size={15} /> {label}
          </button>
        ))}
      </div>

      <main className="px-6 py-6 max-w-2xl">
        {tab === 'crosshair' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className={labelCls}>Style</label>
                <select className={inputCls} value={settings.crosshair.style} onChange={(e) => updateSettings({ crosshair: { ...settings.crosshair, style: e.target.value as 'cross' } })}>
                  <option value="cross">Cross</option>
                  <option value="dot">Dot</option>
                  <option value="circle">Circle</option>
                </select>
              </div>
              <div>
                <label className={labelCls}>Color</label>
                <input type="color" className="h-10 w-full rounded bg-black/40" value={settings.crosshair.color} onChange={(e) => updateSettings({ crosshair: { ...settings.crosshair, color: e.target.value } })} />
              </div>
              {([
                ['size', 'Size', 2, 30],
                ['thickness', 'Thickness', 1, 8],
                ['gap', 'Gap', 0, 16],
              ] as [keyof typeof settings.crosshair, string, number, number][]).map(([k, label, min, max]) => (
                <div key={k}>
                  <label className={labelCls}>{label}: {settings.crosshair[k]}</label>
                  <input type="range" min={min} max={max} value={settings.crosshair[k]} onChange={(e) => updateSettings({ crosshair: { ...settings.crosshair, [k]: Number(e.target.value) } })} className="w-full accent-emerald-400" />
                </div>
              ))}
              <div>
                <label className={labelCls}>Opacity: {Math.round(settings.crosshair.opacity * 100)}%</label>
                <input type="range" min={0.2} max={1} step={0.05} value={settings.crosshair.opacity} onChange={(e) => updateSettings({ crosshair: { ...settings.crosshair, opacity: Number(e.target.value) } })} className="w-full accent-emerald-400" />
              </div>
            </div>
            <div>
              <label className={labelCls}>Preview</label>
              <div className="relative w-full aspect-square max-w-[280px] bg-zinc-800 rounded-lg border border-white/10 overflow-hidden">
                <div className="absolute inset-0" style={{ background: 'linear-gradient(135deg, #3f3f46 25%, #52525b 25%, #52525b 50%, #3f3f46 50%, #3f3f46 75%, #52525b 75%)', backgroundSize: '40px 40px' }} />
                <CrosshairPreview visible />
              </div>
            </div>
          </div>
        )}

        {tab === 'nickname' && (
          <div className="space-y-3 max-w-sm">
            <label className={labelCls}>Nickname (3–16 chars: A-Z a-z 0-9 _)</label>
            <input className={inputCls} value={nickDraft} maxLength={16} onChange={(e) => setNickDraft(e.target.value)} placeholder="Your nickname" />
            {nickMsg && <div className={`text-sm ${nickMsg === 'Saved!' ? 'text-emerald-300' : 'text-red-300'}`}>{nickMsg}</div>}
            <button onClick={saveNick} disabled={!isValidNickname(nickDraft.trim())} className="px-4 py-2 rounded bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-black text-sm font-bold font-mono">
              Save nickname
            </button>
          </div>
        )}

        {tab === 'controls' && (
          <div className="space-y-2">
            {REBINDABLE_ACTIONS.map((a) => (
              <div key={a.id} className="flex items-center justify-between bg-white/5 rounded px-4 py-2.5 font-mono">
                <span className="text-sm">{a.label}</span>
                <button
                  onClick={() => setRebinding(a.id)}
                  className={`min-w-24 px-3 py-1 rounded text-sm font-bold border ${
                    rebinding === a.id ? 'bg-amber-400 text-black border-amber-300 animate-pulse' : 'bg-black/40 border-white/15 hover:border-white/40'
                  }`}
                >
                  {rebinding === a.id ? 'press key…' : keyLabel(settings.keybinds[a.id])}
                </button>
              </div>
            ))}
            <button
              onClick={() => {
                updateSettings({ keybinds: { ...DEFAULT_KEYBINDS } });
                saveProfile(nickname, { ...settings, keybinds: { ...DEFAULT_KEYBINDS } });
              }}
              className="mt-2 px-4 py-2 rounded bg-white/10 hover:bg-white/20 text-sm font-mono"
            >
              Reset to defaults
            </button>
            <p className="text-xs text-white/40 font-mono mt-2">Note: mouse and 1–4 weapon slots are fixed. Escape cancels rebinding.</p>
          </div>
        )}

        {tab === 'graphics' && (
          <div className="space-y-4 max-w-sm">
            <div>
              <label className={labelCls}>Mouse sensitivity: {settings.sensitivity.toFixed(2)}</label>
              <input type="range" min={0.2} max={3} step={0.05} value={settings.sensitivity} onChange={(e) => updateSettings({ sensitivity: Number(e.target.value) })} className="w-full accent-emerald-400" />
            </div>
            <div>
              <label className={labelCls}>Field of view: {settings.fov}°</label>
              <input type="range" min={60} max={110} value={settings.fov} onChange={(e) => updateSettings({ fov: Number(e.target.value) })} className="w-full accent-emerald-400" />
            </div>
            <div>
              <label className={labelCls}>Texture quality</label>
              <select className={inputCls} value={settings.textureQuality} onChange={(e) => updateSettings({ textureQuality: e.target.value as GameSettings['textureQuality'] })}>
                <option value="Low">Low (128px)</option>
                <option value="Med">Medium (256px)</option>
                <option value="High">High (512px)</option>
              </select>
            </div>
            <label className="flex items-center gap-2 font-mono text-sm text-white/70">
              <input type="checkbox" checked={settings.showFps} onChange={(e) => updateSettings({ showFps: e.target.checked })} className="accent-emerald-400" />
              Show FPS counter
            </label>
            <button
              onClick={() => {
                updateSettings(DEFAULT_SETTINGS);
                saveProfile(nickname, DEFAULT_SETTINGS);
              }}
              className="px-4 py-2 rounded bg-white/10 hover:bg-white/20 text-sm font-mono"
            >
              Reset all settings
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
