import { useState } from 'react';
import { ArrowLeft, KeyRound } from 'lucide-react';
import { useStore } from '@/store';
import { findServerByCode } from '@/game/serverApi';

export function JoinCodeScreen(): React.JSX.Element {
  const setScreen = useStore((s) => s.setScreen);
  const setJoinIntent = useStore((s) => s.setJoinIntent);
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const join = async () => {
    if (!code.trim() || busy) return;
    setBusy(true);
    setError('');
    const server = await findServerByCode(code);
    if (server) {
      setJoinIntent({ server });
      setScreen('loading');
    } else {
      setError('No server found with this code');
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <button onClick={() => setScreen('main_menu')} className="flex items-center gap-2 text-white/70 hover:text-white font-mono text-sm mb-6">
          <ArrowLeft size={18} /> Back
        </button>
        <div className="bg-zinc-900 border border-white/15 rounded-xl p-6 font-mono">
          <div className="flex items-center gap-2 mb-1">
            <KeyRound size={20} className="text-emerald-300" />
            <h1 className="text-xl font-bold tracking-wider">JOIN BY CODE</h1>
          </div>
          <p className="text-xs text-white/50 mb-4">Enter the code of a local server</p>
          <input
            autoFocus
            value={code}
            maxLength={8}
            onChange={(e) => { setCode(e.target.value.toUpperCase()); setError(''); }}
            onKeyDown={(e) => e.key === 'Enter' && join()}
            placeholder="e.g. K7XM2A"
            className="w-full bg-black/40 border border-white/15 rounded px-3 py-2.5 text-white mb-2 text-center text-lg tracking-[0.3em] uppercase"
          />
          {error && <div className="text-red-300 text-xs mb-2">{error}</div>}
          <button
            onClick={join}
            disabled={!code.trim() || busy}
            className="w-full px-4 py-2.5 rounded bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-black text-sm font-bold"
          >
            {busy ? 'Searching…' : 'Connect'}
          </button>
        </div>
      </div>
    </div>
  );
}
