import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { DEFAULT_SETTINGS, type GameSettings, type WeaponDef, type GameMode, type MapName, type Region } from '@/game/constants';

export type Screen =
  | 'main_menu'
  | 'server_browser'
  | 'loading'
  | 'match'
  | 'results'
  | 'settings'
  | 'profile'
  | 'join_code';

export interface ServerRow {
  id: string;
  name: string;
  map_name: string;
  mode: string;
  max_players: number;
  bots_count: number;
  region: string;
  kill_limit: number;
  password_hash: string | null;
  host_client_id: string | null;
  player_count: number;
  last_ping: number;
  updated_at: string;
  bot_difficulty: string;
  is_local: boolean;
  join_code: string | null;
  max_ping: number;
}

export interface PlayerScore {
  id: string;
  nickname: string;
  kills: number;
  deaths: number;
  isBot: boolean;
  isLocal: boolean;
}

export interface MatchResult {
  kills: number;
  deaths: number;
  score: number;
  durationSec: number;
  serverName: string;
  mapName: string;
  won: boolean;
  leaderboard: PlayerScore[];
}

export interface JoinIntent {
  server: ServerRow | null;
  created?: boolean;
}

interface StoreState {
  screen: Screen;
  nickname: string;
  clientId: string;
  nicknameConfirmed: boolean;
  settings: GameSettings;
  money: number;
  loadout: string[];
  hasKevlar: boolean;
  currentServer: ServerRow | null;
  ping: number;
  joinIntent: JoinIntent | null;
  results: MatchResult | null;
  setScreen: (s: Screen) => void;
  setNickname: (n: string) => void;
  confirmNickname: () => void;
  updateSettings: (s: Partial<GameSettings>) => void;
  setMoney: (m: number) => void;
  buyWeapon: (w: WeaponDef) => boolean;
  buyKevlar: () => boolean;
  setLoadout: (weaponIds: string[], kevlar: boolean) => void;
  setJoinIntent: (i: JoinIntent | null) => void;
  setCurrentServer: (s: ServerRow | null) => void;
  setResults: (r: MatchResult | null) => void;
}

function randomId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

// One id per browser tab (not per browser): two tabs must be two distinct
// players, or each client filters out the other's moves as its own.
function perTabId(): string {
  try {
    const existing = sessionStorage.getItem('ws3d_tab_client_id');
    if (existing) return existing;
    const id = randomId();
    sessionStorage.setItem('ws3d_tab_client_id', id);
    return id;
  } catch {
    return randomId();
  }
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      screen: 'main_menu',
      nickname: '',
      clientId: perTabId(),
      nicknameConfirmed: false,
      settings: DEFAULT_SETTINGS,
      money: 800,
      loadout: ['pistol'],
      hasKevlar: false,
      currentServer: null,
      ping: 0,
      joinIntent: null,
      results: null,
      setScreen: (s) => set({ screen: s }),
      setNickname: (n) => set({ nickname: n }),
      confirmNickname: () => set({ nicknameConfirmed: true }),
      updateSettings: (s) => set({ settings: { ...get().settings, ...s } }),
      setMoney: (m) => set({ money: Math.max(0, Math.round(m)) }),
      buyWeapon: (w) => {
        const st = get();
        if (st.money < w.price) return false;
        if (st.loadout.includes(w.id)) return false;
        set({ money: st.money - w.price, loadout: [...st.loadout, w.id] });
        return true;
      },
      buyKevlar: () => {
        const st = get();
        if (st.money < 650 || st.hasKevlar) return false;
        set({ money: st.money - 650, hasKevlar: true });
        return true;
      },
      setLoadout: (weaponIds, kevlar) => set({ loadout: weaponIds, hasKevlar: kevlar }),
      setJoinIntent: (i) => set({ joinIntent: i }),
      setCurrentServer: (s) => set({ currentServer: s }),
      setResults: (r) => set({ results: r }),
    }),
    {
      name: 'ws3d_store',
      partialize: (s) => ({
        nickname: s.nickname,
        nicknameConfirmed: s.nicknameConfirmed,
        settings: s.settings,
        money: s.money,
        loadout: s.loadout,
        hasKevlar: s.hasKevlar,
      }),
    }
  )
);
