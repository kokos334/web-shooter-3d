import { getSupabase } from '@/lib/supabase';
import { useStore } from '@/store';

let timer: ReturnType<typeof setInterval> | null = null;

// HTTP round-trip to the Supabase project ≈ real network ping to the game
// server. Two samples back to back; we keep the smaller one to strip out
// one-off stalls (GC, tab jank).
export async function samplePing(): Promise<number | null> {
  const t0 = performance.now();
  try {
    const { error } = await getSupabase()
      .from('servers')
      .select('id', { count: 'exact', head: true });
    if (error) return null;
    return Math.round(performance.now() - t0);
  } catch {
    return null;
  }
}

async function sample(): Promise<number | null> {
  return samplePing();
}

async function measure(): Promise<void> {
  const s1 = await sample();
  if (s1 == null) return;
  const s2 = await sample();
  const ping = s2 == null ? s1 : Math.min(s1, s2);
  const prev = useStore.getState().ping;
  // smooth: never jump up more than 2x the previous value
  const smoothed = prev > 0 ? Math.round(Math.min(ping, Math.max(prev * 2, prev + 20))) : ping;
  useStore.setState({ ping: smoothed });
  const server = useStore.getState().currentServer;
  if (server) {
    void getSupabase().from('servers').update({ last_ping: smoothed }).eq('id', server.id).then();
  }
}

export function startPingTracking(): void {
  stopPingTracking();
  void measure();
  timer = setInterval(() => void measure(), 5000);
}

export function stopPingTracking(): void {
  if (timer) {
    clearInterval(timer);
    timer = null;
  }
}
