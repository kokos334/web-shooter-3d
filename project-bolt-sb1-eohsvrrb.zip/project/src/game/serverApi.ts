import { getSupabase } from '@/lib/supabase';
import { useStore, type ServerRow } from '@/store';
import type { BotDifficulty } from '@/game/constants';

export async function sha256Hex(text: string): Promise<string> {
  const data = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export async function fetchServers(): Promise<ServerRow[]> {
  // local servers are hidden from the public list — joinable only by code
  const { data, error } = await getSupabase()
    .from('servers')
    .select('*')
    .eq('is_local', false)
    .order('updated_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as ServerRow[];
}

export async function checkPassword(serverId: string, pass: string): Promise<boolean> {
  const { data, error } = await getSupabase().rpc('check_server_password', {
    server_id: serverId,
    pass,
  });
  if (error) return false;
  return Boolean(data);
}

export async function createServer(opts: {
  name: string;
  map: string;
  mode: string;
  maxPlayers: number;
  botsCount: number;
  region: string;
  killLimit: number;
  password: string;
  hostClientId: string;
  botDifficulty: BotDifficulty;
  isLocal: boolean;
  maxPing: number;
}): Promise<ServerRow> {
  const password_hash = opts.password ? await sha256Hex(opts.password) : null;
  const join_code = opts.isLocal ? randomJoinCode() : null;
  const { data, error } = await getSupabase()
    .from('servers')
    .insert({
      name: opts.name,
      map_name: opts.map,
      mode: opts.mode,
      max_players: opts.maxPlayers,
      bots_count: opts.botsCount,
      region: opts.region,
      kill_limit: opts.killLimit,
      password_hash,
      host_client_id: opts.hostClientId,
      player_count: 1,
      bot_difficulty: opts.botDifficulty,
      is_local: opts.isLocal,
      join_code,
      max_ping: opts.maxPing,
    })
    .select()
    .single();
  if (error) throw error;
  return data as ServerRow;
}

function randomJoinCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) code += alphabet[Math.floor(Math.random() * alphabet.length)];
  return code;
}

// find a local server by its join code (case-insensitive)
export async function findServerByCode(code: string): Promise<ServerRow | null> {
  const clean = code.trim().toUpperCase();
  if (!clean) return null;
  const { data, error } = await getSupabase()
    .from('servers')
    .select('*')
    .ilike('join_code', clean)
    .maybeSingle();
  if (error || !data) return null;
  return data as ServerRow;
}

let pingTimer: ReturnType<typeof setInterval> | null = null;

export function startServerHeartbeat(serverId: string, getPlayerCount?: () => number): void {
  stopServerHeartbeat();
  pingTimer = setInterval(() => {
    const patch: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
      host_client_id: useStore.getState().clientId,
    };
    if (getPlayerCount) {
      const n = getPlayerCount();
      if (n > 0) patch.player_count = n;
    }
    getSupabase()
      .from('servers')
      .update(patch)
      .eq('id', serverId)
      .then();
  }, 10000);
}

export function stopServerHeartbeat(): void {
  if (pingTimer) {
    clearInterval(pingTimer);
    pingTimer = null;
  }
}
