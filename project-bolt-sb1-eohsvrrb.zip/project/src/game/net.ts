import type { RealtimeChannel } from '@supabase/supabase-js';
import { getSupabase } from '@/lib/supabase';
import { useStore } from '@/store';

export interface PresencePlayer {
  client_id: string;
  nickname: string;
  hp: number;
  weapon: string;
  team: string;
  isBot?: boolean;
  pos?: [number, number, number];
  entityKey?: string | null;
  isDead?: boolean;
}

export interface MoveSnapshot {
  id: string;
  p: [number, number, number];
  ry: number;
  rp: number;
  crouch: boolean;
  anim: number; // 0 idle, 1 run
  weapon?: string;
}

export interface BotSnapshot {
  id: string;
  p: [number, number, number];
  ry: number;
  hp: number;
  dead: boolean;
}

export interface HitEvent {
  from: string;
  fromName: string;
  target: string;
  dmg: number;
  part: 'head' | 'body' | 'legs';
  weapon: string;
}

export interface KillEvent {
  killer: string;
  killerName: string;
  victim: string;
  victimName: string;
  weapon: string;
}

export interface ChatEvent {
  from: string;
  fromName: string;
  text: string;
}

type Handlers = {
  onMove: (s: MoveSnapshot) => void;
  onBotState: (bots: BotSnapshot[]) => void;
  onHit: (h: HitEvent) => void;
  onKill: (k: KillEvent) => void;
  onChat: (c: ChatEvent) => void;
  onPresence?: (players: PresencePlayer[]) => void;
  onHostChange?: (hostId: string) => void;
};

export interface ServerInfo {
  id: string;
  name: string;
  map: string;
  mode: string;
  killLimit: number;
  botsCount: number;
}

const MOVE_HZ = 20;
const BOT_HZ = 10;
const SYNC_HZ = 0.5;

export class NetConnection {
  channel: RealtimeChannel | null = null;
  serverId = '';
  localId = '';
  isHost = false;
  hostId = '';
  serverInfo: ServerInfo | null = null;
  private handlers: Handlers | null = null;
  private moveTimer = 0;
  private botTimer = 0;
  private syncTimer = 0;
  private lastMove: MoveSnapshot | null = null;
  private lastBotState: BotSnapshot[] | null = null;
  private presence: PresencePlayer[] = [];
  private joined = false;

  async join(info: ServerInfo, handlers: Handlers): Promise<void> {
    // rejoin (loading screen -> match): tear down the old channel so presence
    // is re-tracked on the fresh one, otherwise this client is invisible
    if (this.channel) {
      await this.leave();
    }
    this.joined = false;
    this.serverInfo = info;
    this.localId = useStore.getState().clientId;
    this.handlers = handlers;
    const sb = getSupabase();

    this.channel = sb.channel(`server:${info.id}`, {
      config: { broadcast: { self: false }, presence: { key: this.localId } },
    });

    this.channel
      .on('broadcast', { event: 'player:move' }, ({ payload }) => handlers.onMove(payload as MoveSnapshot))
      .on('broadcast', { event: 'bot:state' }, ({ payload }) => handlers.onBotState((payload as { bots: BotSnapshot[] }).bots))
      .on('broadcast', { event: 'player:hit' }, ({ payload }) => handlers.onHit(payload as HitEvent))
      .on('broadcast', { event: 'player:kill' }, ({ payload }) => handlers.onKill(payload as KillEvent))
      .on('broadcast', { event: 'chat:msg' }, ({ payload }) => handlers.onChat(payload as ChatEvent))
      .on('presence', { event: 'sync' }, () => {
        const state = this.channel!.presenceState();
        const players: PresencePlayer[] = [];
        for (const [key, metas] of Object.entries(state)) {
          const meta = metas[0] as unknown as PresencePlayer;
          if (meta) players.push({ ...meta, client_id: key });
        }
        this.presence = players;
        handlers.onPresence?.(players);
        this.electHost(players);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED' && !this.joined) {
          this.joined = true;
          await this.trackSelf();
        }
      });
  }

  private async trackSelf(): Promise<void> {
    const { nickname } = useStore.getState();
    await this.channel?.track({
      client_id: this.localId,
      nickname,
      hp: 100,
      weapon: 'pistol',
      team: 'a',
    });
  }

  updatePresence(fields: Partial<PresencePlayer>): void {
    this.channel?.track({
      client_id: this.localId,
      nickname: useStore.getState().nickname,
      hp: 100,
      weapon: 'pistol',
      team: 'a',
      ...fields,
    });
  }

  private electHost(players: PresencePlayer[]): void {
    // Human players only; lowest client_id string wins (deterministic across clients)
    const humans = players
      .filter((p) => !p.isBot)
      .map((p) => p.client_id)
      .sort();
    const next = humans[0] ?? this.localId;
    const wasHost = this.isHost;
    this.hostId = next;
    this.isHost = next === this.localId;
    if (this.isHost !== wasHost) {
      this.handlers?.onHostChange?.(next);
    }
  }

  isChannelReady(): boolean {
    return this.joined && this.channel !== null;
  }

  getPresence(): PresencePlayer[] {
    return this.presence;
  }

  queueMove(s: MoveSnapshot): void {
    this.lastMove = s;
    const now = performance.now();
    if (now - this.moveTimer >= 1000 / MOVE_HZ) {
      this.moveTimer = now;
      this.channel?.send({ type: 'broadcast', event: 'player:move', payload: s });
    }
  }

  queueBotState(bots: BotSnapshot[]): void {
    this.lastBotState = bots;
    const now = performance.now();
    if (now - this.botTimer >= 1000 / BOT_HZ) {
      this.botTimer = now;
      this.channel?.send({ type: 'broadcast', event: 'bot:state', payload: { bots } });
    }
  }

  sendHit(h: HitEvent): void {
    this.channel?.send({ type: 'broadcast', event: 'player:hit', payload: h });
  }

  sendKill(k: KillEvent): void {
    this.channel?.send({ type: 'broadcast', event: 'player:kill', payload: k });
  }

  sendChat(c: ChatEvent): void {
    this.channel?.send({ type: 'broadcast', event: 'chat:msg', payload: c });
  }

  async leave(): Promise<void> {
    const ch = this.channel;
    this.channel = null;
    this.joined = false;
    this.presence = [];
    this.handlers = null;
    if (ch) {
      await ch.untrack();
      await getSupabase().removeChannel(ch);
    }
  }
}

export const net = new NetConnection();
