import * as THREE from 'three';

type Quality = 'Low' | 'Med' | 'High';

function makeCanvas(size: number): { canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return { canvas, ctx };
}

export function crateTexture(quality: Quality = 'Med'): THREE.CanvasTexture {
  const size = quality === 'Low' ? 128 : quality === 'Med' ? 256 : 512;
  const { canvas, ctx } = makeCanvas(size);
  ctx.fillStyle = '#8a6b42';
  ctx.fillRect(0, 0, size, size);

  // wood grain
  for (let i = 0; i < size / 6; i++) {
    ctx.fillStyle = `rgba(60,42,20,${0.05 + Math.random() * 0.08})`;
    ctx.fillRect(0, Math.random() * size, size, 2 + Math.random() * 4);
  }

  // frame
  const b = size * 0.08;
  ctx.strokeStyle = '#5a4428';
  ctx.lineWidth = b;
  ctx.strokeRect(b / 2, b / 2, size - b, size - b);

  // diagonal brace
  ctx.lineWidth = size * 0.05;
  ctx.strokeStyle = '#6b5232';
  ctx.beginPath();
  ctx.moveTo(b, b);
  ctx.lineTo(size - b, size - b);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(size - b, b);
  ctx.lineTo(b, size - b);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function concreteTexture(quality: Quality = 'Med'): THREE.CanvasTexture {
  const size = quality === 'Low' ? 128 : quality === 'Med' ? 256 : 512;
  const { canvas, ctx } = makeCanvas(size);
  ctx.fillStyle = '#7d7f83';
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 900; i++) {
    const s = 1 + Math.random() * 3;
    ctx.fillStyle = `rgba(${40 + Math.random() * 60},${40 + Math.random() * 60},${45 + Math.random() * 60},0.25)`;
    ctx.fillRect(Math.random() * size, Math.random() * size, s, s);
  }
  // panel seams
  ctx.strokeStyle = 'rgba(40,40,45,0.5)';
  ctx.lineWidth = 2;
  ctx.strokeRect(0, 0, size / 2, size / 2);
  ctx.strokeRect(size / 2, size / 2, size / 2, size / 2);
  ctx.strokeRect(size / 2, 0, size / 2, size / 2);
  ctx.strokeRect(0, size / 2, size / 2, size / 2);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

export function metalTexture(quality: Quality = 'Med'): THREE.CanvasTexture {
  const size = quality === 'Low' ? 128 : quality === 'Med' ? 256 : 512;
  const { canvas, ctx } = makeCanvas(size);
  ctx.fillStyle = '#6e4a33';
  ctx.fillRect(0, 0, size, size);

  // corrugated vertical ribs
  const ribs = 8;
  for (let i = 0; i < ribs; i++) {
    const x = (i / ribs) * size;
    const w = size / ribs;
    const g = ctx.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, '#4f3625');
    g.addColorStop(0.5, '#8a5d3f');
    g.addColorStop(1, '#4f3625');
    ctx.fillStyle = g;
    ctx.fillRect(x, 0, w, size);
  }
  // rust speckles
  for (let i = 0; i < 200; i++) {
    ctx.fillStyle = `rgba(120,60,20,${0.1 + Math.random() * 0.25})`;
    ctx.fillRect(Math.random() * size, Math.random() * size, 2 + Math.random() * 4, 2 + Math.random() * 4);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

export function floorTexture(quality: Quality = 'Med'): THREE.CanvasTexture {
  const size = quality === 'Low' ? 128 : quality === 'Med' ? 256 : 512;
  const { canvas, ctx } = makeCanvas(size);
  ctx.fillStyle = '#55585e';
  ctx.fillRect(0, 0, size, size);

  // asphalt noise
  for (let i = 0; i < 1400; i++) {
    const s = 1 + Math.random() * 2;
    ctx.fillStyle = `rgba(${30 + Math.random() * 70},${30 + Math.random() * 70},${35 + Math.random() * 70},0.3)`;
    ctx.fillRect(Math.random() * size, Math.random() * size, s, s);
  }
  // painted line / marking
  ctx.strokeStyle = 'rgba(230,200,60,0.55)';
  ctx.lineWidth = size * 0.03;
  ctx.setLineDash([size * 0.15, size * 0.1]);
  ctx.beginPath();
  ctx.moveTo(0, size / 2);
  ctx.lineTo(size, size / 2);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}
