import { useStore } from '@/store';

export function Crosshair({ visible }: { visible: boolean }): React.JSX.Element | null {
  const c = useStore((s) => s.settings.crosshair);
  if (!visible) return null;

  const line = (style: React.CSSProperties): React.JSX.Element => (
    <div className="absolute" style={{ background: c.color, opacity: c.opacity, ...style }} />
  );

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
      <div className="relative" style={{ width: 1, height: 1 }}>
        {c.style === 'cross' && (
          <>
            {line({ width: c.thickness, height: c.size, left: -c.thickness / 2, top: c.gap })}
            {line({ width: c.thickness, height: c.size, left: -c.thickness / 2, top: -c.gap - c.size })}
            {line({ width: c.size, height: c.thickness, top: -c.thickness / 2, left: c.gap })}
            {line({ width: c.size, height: c.thickness, top: -c.thickness / 2, left: -c.gap - c.size })}
          </>
        )}
        {c.style === 'dot' && line({ width: c.size, height: c.size, left: -c.size / 2, top: -c.size / 2, borderRadius: '50%' })}
        {c.style === 'circle' && (
          <div
            className="absolute rounded-full"
            style={{
              width: c.size * 2,
              height: c.size * 2,
              left: -c.size,
              top: -c.size,
              border: `${c.thickness}px solid ${c.color}`,
              opacity: c.opacity,
            }}
          />
        )}
      </div>
    </div>
  );
}
