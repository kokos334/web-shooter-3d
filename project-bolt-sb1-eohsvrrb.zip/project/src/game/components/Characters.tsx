import { useRef, useReducer } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { Billboard, Text } from '@react-three/drei';
import { WeaponViewModel } from '@/game/WeaponViewModel';
import { WEAPONS } from '@/game/constants';
import { input } from '@/game/input';
import type { MatchEngine, Bot, RemotePlayer } from '@/game/engine';

// weapon silhouettes: (length, height) per weapon id, with a magazine box
const GUN_SHAPES: Record<string, { len: number; h: number; mag: boolean }> = {
  pistol: { len: 0.42, h: 0.1, mag: false },
  shotgun: { len: 1.0, h: 0.12, mag: false },
  smg: { len: 0.62, h: 0.12, mag: true },
  ar: { len: 0.85, h: 0.13, mag: true },
  lmg: { len: 1.0, h: 0.16, mag: true },
  awp: { len: 1.15, h: 0.11, mag: true },
};

function HeldWeapon({ weaponId, color = '#1a1a1a' }: { weaponId: string; color?: string }): React.JSX.Element {
  const shape = GUN_SHAPES[weaponId] ?? GUN_SHAPES.pistol;
  return (
    <group position={[0.42, 1.22, -0.2]} rotation={[0, -0.08, 0]}>
      {/* receiver + barrel */}
      <mesh castShadow>
        <boxGeometry args={[0.08, shape.h, shape.len]} />
        <meshStandardMaterial color={color} roughness={0.4} metalness={0.5} />
      </mesh>
      {/* grip */}
      <mesh position={[0, -shape.h / 2 - 0.06, shape.len / 2 - 0.16]} rotation={[0.45, 0, 0]} castShadow>
        <boxGeometry args={[0.06, 0.16, 0.08]} />
        <meshStandardMaterial color="#101010" roughness={0.7} />
      </mesh>
      {shape.mag && (
        <mesh position={[0, -shape.h / 2 - 0.09, -0.02]} rotation={[0.12, 0, 0]} castShadow>
          <boxGeometry args={[0.055, 0.18, 0.09]} />
          <meshStandardMaterial color="#222222" roughness={0.5} metalness={0.3} />
        </mesh>
      )}
    </group>
  );
}

function BotModel({ bot, teamMode }: { bot: Bot; teamMode: boolean }): React.JSX.Element {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => {
    if (ref.current) {
      ref.current.position.set(bot.pos.x, bot.pos.y, bot.pos.z);
      ref.current.rotation.y = bot.yaw;
      ref.current.visible = !bot.dead;
    }
  });
  const bodyColor = teamMode ? (bot.team === 'a' ? '#2e9e4f' : '#c0392b') : '#c0392b';
  const nameColor = teamMode ? (bot.team === 'a' ? '#c9f7d4' : '#ffd9d9') : '#ffd9d9';
  const outlineColor = teamMode ? (bot.team === 'a' ? '#0e2a15' : '#301010') : '#301010';
  return (
    <group ref={ref}>
      <mesh position={[0, 0.9, 0]} castShadow>
        <capsuleGeometry args={[0.4, 1.0, 4, 8]} />
        <meshStandardMaterial color={bodyColor} roughness={0.7} />
      </mesh>
      <mesh position={[0, 1.78, 0]} castShadow>
        <sphereGeometry args={[0.26, 12, 12]} />
        <meshStandardMaterial color="#e0b088" roughness={0.8} />
      </mesh>
      <HeldWeapon weaponId={bot.weaponId} />
      <Billboard>
        <Text position={[0, 2.25, 0]} fontSize={0.28} color={nameColor} anchorX="center" outlineWidth={0.03} outlineColor={outlineColor}>
          {bot.nickname}
        </Text>
      </Billboard>
    </group>
  );
}

function RemoteModel({ remote, teamMode, remoteTeam }: { remote: RemotePlayer; teamMode: boolean; remoteTeam: 'a' | 'b' }): React.JSX.Element {
  const ref = useRef<THREE.Group>(null);
  const gunRef = useRef<THREE.Group>(null);
  const weaponNameRef = useRef('');
  useFrame(() => {
    if (ref.current) {
      ref.current.position.copy(remote.pos);
      ref.current.rotation.y = remote.yaw;
    }
    const w = WEAPONS[remote.weaponId];
    const name = w ? w.name : '';
    if (weaponNameRef.current !== name && gunRef.current) {
      weaponNameRef.current = name;
      const shape = GUN_SHAPES[remote.weaponId] ?? GUN_SHAPES.pistol;
      gunRef.current.scale.set(1, 1, shape.len);
    }
  });
  const isMate = !teamMode || remoteTeam === 'a';
  const bodyColor = teamMode ? (isMate ? '#2e9e4f' : '#c0392b') : '#2980b9';
  const nameColor = teamMode ? (isMate ? '#c9f7d4' : '#ffd9d9') : '#d0ecff';
  const outlineColor = teamMode ? (isMate ? '#0e2a15' : '#301010') : '#102030';
  return (
    <group ref={ref}>
      <mesh position={[0, 0.9, 0]} castShadow>
        <capsuleGeometry args={[0.4, 1.0, 4, 8]} />
        <meshStandardMaterial color={bodyColor} roughness={0.7} />
      </mesh>
      <mesh position={[0, 1.78, 0]} castShadow>
        <sphereGeometry args={[0.26, 12, 12]} />
        <meshStandardMaterial color="#e0b088" roughness={0.8} />
      </mesh>
      <group ref={gunRef}>
        <HeldWeapon weaponId={remote.weaponId} />
      </group>
      <Billboard>
        <Text position={[0, 2.25, 0]} fontSize={0.28} color={nameColor} anchorX="center" outlineWidth={0.03} outlineColor={outlineColor}>
          {remote.nickname}
        </Text>
      </Billboard>
    </group>
  );
}

export function Characters({ engine }: { engine: MatchEngine }): React.JSX.Element {
  const { camera } = useThree();
  const [, rerender] = useReducer((x: number) => x + 1, 0);
  const countsRef = useRef({ bots: -1, remotes: -1 });
  const teamMode = engine.isTeamMode();
  const localTeam = engine.localTeam();

  useFrame(() => {
    const eye = engine.eyePos();
    if (input.locked) {
      camera.position.set(eye.x, eye.y, eye.z);
      camera.rotation.set(engine.pitch + engine.recoilKick * 0.01, engine.yaw, 0, 'YXZ');
    } else {
      // pre-game menu: top-down overview of the map while bots keep fighting
      const height = engine.map.size + 18;
      camera.position.set(0, height, 0.001);
      camera.lookAt(0, 0, 0);
    }
    (camera as THREE.PerspectiveCamera).fov = engine.settings.fov;
    (camera as THREE.PerspectiveCamera).updateProjectionMatrix();

    // bots and remote players are added after mount (host election, joins);
    // re-render so their models get created
    if (engine.bots.length !== countsRef.current.bots || engine.remotes.size !== countsRef.current.remotes) {
      countsRef.current = { bots: engine.bots.length, remotes: engine.remotes.size };
      rerender();
    }
  });

  return (
    <group>
      <WeaponViewModel engine={engine} />
      {engine.bots.map((b) => (
        <BotModel key={b.id} bot={b} teamMode={teamMode} />
      ))}
      {Array.from(engine.remotes.entries()).map(([id, r]) => (
        <RemoteModel key={id} remote={r} teamMode={teamMode} remoteTeam={teamMode ? engine.teamOf(id) : 'a'} />
      ))}
    </group>
  );
}
