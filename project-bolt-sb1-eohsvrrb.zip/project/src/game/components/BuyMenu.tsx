import { useState } from 'react';
import { WEAPONS, KEVLAR_PRICE, KEVLAR_ARMOR } from '@/game/constants';
import { useStore } from '@/store';
import type { MatchEngine } from '@/game/engine';

interface BuyMenuProps {
  engine: MatchEngine;
  onClose: () => void;
}

const SLOTS: Record<string, string> = { pistol: '1', smg: '2', ar: '3', awp: '4', shotgun: '5', lmg: '6' };

export function BuyMenu({ engine, onClose }: BuyMenuProps): React.JSX.Element {
  const money = useStore((s) => s.money);
  const loadout = useStore((s) => s.loadout);
  const hasKevlar = useStore((s) => s.hasKevlar);
  const buyWeapon = useStore((s) => s.buyWeapon);
  const buyKevlar = useStore((s) => s.buyKevlar);
  const setLoadout = useStore((s) => s.setLoadout);
  const [flash, setFlash] = useState('');

  const doBuyWeapon = (id: string) => {
    const w = WEAPONS[id];
    if (!w) return;
    if (loadout.includes(id)) {
      engine.switchWeapon(id);
      setFlash(`${w.name} equipped`);
      setTimeout(() => setFlash(''), 1200);
      return;
    }
    if (buyWeapon(w)) {
      engine.switchWeapon(id);
      setFlash(`Bought ${w.name}`);
      setTimeout(() => setFlash(''), 1200);
    } else {
      setFlash('Not enough money');
      setTimeout(() => setFlash(''), 1200);
    }
  };

  const doBuyKevlar = () => {
    if (hasKevlar) return;
    if (buyKevlar()) {
      engine.armor = KEVLAR_ARMOR;
      setFlash('Bought Kevlar');
    } else {
      setFlash('Not enough money');
    }
    setTimeout(() => setFlash(''), 1200);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-2xl bg-zinc-900/95 border border-white/10 rounded-xl p-6 font-mono">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-wider">BUY MENU</h2>
            <div className="text-xs text-amber-300/80">Press B or Esc to close — switch weapons with 1–6</div>
          </div>
          <div className="text-2xl font-bold text-emerald-300">${money}</div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {Object.values(WEAPONS).map((w) => {
            const owned = loadout.includes(w.id);
            const equipped = engine.weaponId === w.id;
            const afford = money >= w.price;
            return (
              <button
                key={w.id}
                onClick={() => doBuyWeapon(w.id)}
                className={`text-left rounded-lg border p-3 transition-colors ${
                  equipped ? 'border-emerald-400 bg-emerald-900/30' : owned ? 'border-white/25 bg-white/5 hover:bg-white/10' : afford ? 'border-white/10 bg-black/30 hover:bg-white/10' : 'border-white/5 bg-black/20 opacity-50 cursor-not-allowed'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold">
                    <span className="text-amber-300/70 mr-2">[{SLOTS[w.id]}]</span>
                    {w.name}
                  </span>
                  <span className={owned ? 'text-emerald-300 text-sm' : afford ? 'text-white font-bold' : 'text-red-300 text-sm'}>
                    {owned ? (equipped ? 'EQUIPPED' : 'OWNED') : `$${w.price}`}
                  </span>
                </div>
                <div className="text-xs text-white/50 mt-1">
                  dmg {w.dmg} · {w.rpm} rpm · mag {w.mag}
                </div>
              </button>
            );
          })}

          <button
            onClick={doBuyKevlar}
            className={`text-left rounded-lg border p-3 transition-colors ${
              hasKevlar ? 'border-sky-400/60 bg-sky-900/20' : money >= KEVLAR_PRICE ? 'border-white/10 bg-black/30 hover:bg-white/10' : 'border-white/5 bg-black/20 opacity-50 cursor-not-allowed'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-white font-bold">
                <span className="text-amber-300/70 mr-2">[7]</span>
                Kevlar
              </span>
              <span className={hasKevlar ? 'text-sky-300 text-sm' : 'text-white font-bold'}>
                {hasKevlar ? 'ACTIVE' : `$${KEVLAR_PRICE}`}
              </span>
            </div>
            <div className="text-xs text-white/50 mt-1">+{KEVLAR_ARMOR} armor · halves incoming damage</div>
          </button>
        </div>

        {flash && <div className="mt-3 text-center text-amber-300 text-sm">{flash}</div>}

        <div className="mt-4 flex justify-between items-center text-xs text-white/40">
          <span>You start each match with the pistol — earn money from kills</span>
          <button onClick={onClose} className="px-4 py-1.5 rounded bg-white/10 hover:bg-white/20 text-white text-sm font-bold">
            Close (Esc)
          </button>
        </div>

        <button
          className="mt-3 w-full text-center text-xs text-white/30 hover:text-white/60"
          onClick={() => setLoadout(loadout, hasKevlar)}
        >
          Save loadout to profile
        </button>
      </div>
    </div>
  );
}
