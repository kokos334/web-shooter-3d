import { useEffect, useRef, useState } from 'react';
import { net } from '@/game/net';
import { useStore } from '@/store';
import type { MatchEngine } from '@/game/engine';

interface ChatOverlayProps {
  engine: MatchEngine;
}

const CHAT_KEYS = ['KeyY', 'Enter'];

export function ChatOverlay({ engine }: ChatOverlayProps): React.JSX.Element | null {
  const clientId = useStore((s) => s.clientId);
  const nickname = useStore((s) => s.nickname);
  const [messages, setMessages] = useState(engine.chatLog);
  const [typing, setTyping] = useState(false);
  const [draft, setDraft] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);
  const typingRef = useRef(false);
  const draftRef = useRef('');

  typingRef.current = typing;
  draftRef.current = draft;

  useEffect(() => {
    const iv = setInterval(() => {
      if (!typingRef.current) setMessages([...engine.chatLog]);
    }, 500);
    // instant refresh when a new message arrives (engine fires onChat)
    engine.onChat = () => {
      if (!typingRef.current) setMessages([...engine.chatLog]);
    };
    return () => {
      clearInterval(iv);
      engine.onChat = null;
    };
  }, [engine]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (CHAT_KEYS.includes(e.code) && !typingRef.current) {
        e.preventDefault();
        setTyping(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    if (typing) {
      document.exitPointerLock?.();
      setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [typing]);

  const send = () => {
    const text = draft.trim().slice(0, 120);
    if (text) {
      engine.applyChat({ fromName: nickname || 'Player', text });
      net.sendChat({ from: clientId, fromName: nickname || 'Player', text });
    }
    setDraft('');
    setTyping(false);
  };

  if (!typing && messages.length === 0) return null;

  return (
    <div className="absolute bottom-24 left-4 z-20 w-96 font-mono">
      <div className="flex flex-col gap-0.5 mb-1">
        {messages.slice(0, 5).map((m, i) => (
          <div key={m.at + '' + i} className="text-sm bg-black/45 rounded px-2 py-1 text-white/90 w-fit max-w-full border border-white/5">
            <span className="text-emerald-300 font-bold">{m.fromName}:</span> {m.text}
          </div>
        ))}
      </div>
      {typing && (
        <input
          ref={inputRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            e.stopPropagation();
            if (e.key === 'Enter') send();
            if (e.key === 'Escape') {
              setDraft('');
              setTyping(false);
            }
          }}
          onBlur={() => {
            setDraft('');
            setTyping(false);
          }}
          placeholder="Say something… (Enter to send)"
          maxLength={120}
          className="w-full bg-black/70 border border-emerald-400/40 rounded px-2 py-1.5 text-sm text-white outline-none"
        />
      )}
      {!typing && <div className="text-[10px] text-white/40 px-2">Press Y or Enter to chat</div>}
    </div>
  );
}
