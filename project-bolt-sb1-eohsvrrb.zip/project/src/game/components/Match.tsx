import { useEffect, useRef, useState, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import { GameWorld } from '@/game/components/GameWorld';
import { Characters } from '@/game/components/Characters';
import { MatchEngine, type ScoreEntry } from '@/game/engine';
import { net, type MoveSnapshot, type BotSnapshot, type HitEvent, type KillEvent, type ChatEvent, type PresencePlayer } from '@/game/net';
import { useStore, type ServerRow } from '@/store';
import { botDifficultyConfig, modeDef, type BotDifficulty, type GameMode } from '@/game/constants';
import { input, bindInput, requestLock, releaseLock } from '@/game/input';
import { startServerHeartbeat, stopServerHeartbeat } from '@/game/serverApi';
import { subscribeServerPlayers } from '@/game/serverPlayers';
import { startPingTracking, stopPingTracking } from '@/game/ping';
import { getMapDef } from '@/game/world';
import { BuyMenu } from '@/game/components/BuyMenu';
import { ChatOverlay } from '@/game/components/ChatOverlay';
import { Scoreboard } from '@/game/components/Scoreboard';
import { Crosshair } from '@/game/components/Crosshair';
import { TouchControls } from '@/game/components/TouchControls';
import { getSupabase } from '@/lib/supabase';

interface MatchProps {
  server: ServerRow;
  created: boolean;
}

interface HudSnapshot {
  hp: number;
  armor: number;
  mag: number;
  reserve: number;
  weaponName: string;
  dead: boolean;
  respawnIn: number;
  timeLeft: number;
  fps: number;
  killFeed: { text: string; at: number }[];
  scores: ScoreEntry[];
  myKills: number;
  myDeaths: number;
  reloading: boolean;
  teamMode: boolean;
  teamA: number;
  teamB: number;
  myTeam: 'a' | 'b';
}

function snapshotHud(e: MatchEngine): HudSnapshot {
  const nowSec = performance.now() / 1000;
  const ts = e.teamScores();
  return {
    hp: Math.max(0, Math.round(e.hp)),
    armor: Math.round(e.armor),
    mag: e.magAmmo,
    reserve: e.reserveAmmo,
    weaponName: e.weapon().name,
    dead: e.dead,
    respawnIn: Math.max(0, Math.ceil(e.respawnAt - nowSec)),
    timeLeft: 0,
    fps: e.fps,
    killFeed: [...e.killFeed],
    scores: e.leaderboard(),
    myKills: e.kills,
    myDeaths: e.deaths,
    reloading: e.reloadingUntil > nowSec,
    teamMode: e.isTeamMode(),
    teamA: ts.a,
    teamB: ts.b,
    myTeam: e.localTeam(),
  };
}

export function Match({ server, created }: MatchProps): React.JSX.Element {
  const setScreen = useStore((s) => s.setScreen);
  const setResults = useStore((s) => s.setResults);
  const setMoney = useStore((s) => s.setMoney);
  const clientId = useStore((s) => s.clientId);
  const pingMs = useStore((s) => s.ping);

  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [kicked, setKicked] = useState(false);
  const [showBoard, setShowBoard] = useState(false);
  const [showBuy, setShowBuy] = useState(false);
  const [locked, setLocked] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const isTouchDevice = useRef(typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0));
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<MatchEngine | null>(null);
  const overRef = useRef(false);
  const playersRef = useRef<PresencePlayer[]>([]);

  if (!engineRef.current) {
    const st = useStore.getState();
    engineRef.current = new MatchEngine(
      server.map_name,
      st.settings,
      server.kill_limit,
      0, // bots are spawned by whichever client wins host election
      st.money,
      (server.mode ?? 'Deathmatch') as GameMode,
      // shared bot roster id: every client derives identical bot ids, so the
      // host's broadcasted state merges into one shared set of server bots
      server.id
    );
  }
  const engine = engineRef.current!;
  const buyAllowed = engine.buyMenuAllowed();

  // input + engine loop: run the sim from the browser's animation frames
  // (~60 FPS) so movement feels smooth; the HUD mirrors state every frame
  useEffect(() => {
    const unbind = bindInput();
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const e = engineRef.current;
      if (!e) return;
      // clamp dt so tab-switch pauses don't teleport the player
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      // world keeps simulating (bots, remotes, broadcasts) even when the
      // pointer isn't locked — only mouse look/shoot are gated by lock
      if (!e.matchOver) {
        e.update(dt, canvasRef.current);
      }
      if (!overRef.current) setHud(snapshotHud(e));
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      unbind();
    };
  }, [engine]);

  // net handlers
  useEffect(() => {
    const e = engine;

    const handlers = {
      onMove: (s: MoveSnapshot) => e.applyRemoteMove(s),
      onBotState: (bots: BotSnapshot[]) => e.applyBotState(bots),
      onHit: (h: HitEvent) => e.applyHit(h),
      onKill: (k: KillEvent) => {
        e.applyKill(k);
        if (k.victim === clientId && e.scores.get('local')) {
          // death already handled locally
        }
      },
      onChat: (c: ChatEvent) => e.applyChat(c),
    };

    net
      .join(
        { id: server.id, name: server.name, map: server.map_name, mode: server.mode, killLimit: server.kill_limit, botsCount: server.bots_count },
        handlers
      )
      .catch(() => {});

    startServerHeartbeat(server.id, () => {
      const e = engineRef.current;
      return e ? 1 + e.remotes.size : 1;
    });

    startPingTracking();

    // database-backed player list: who is on this server, with positions.
    // The host also publishes its bots so they exist server-side.
    const stopPlayers = subscribeServerPlayers(
      server.id,
      () => {
        const e = engineRef.current;
        if (!e) return null;
        return {
          pos: [e.pos.x, e.pos.y, e.pos.z] as [number, number, number],
          yaw: e.yaw,
          hp: Math.round(e.hp),
          kills: e.kills,
          deaths: e.deaths,
          weapon: e.weaponId,
        };
      },
      () => {
        const e = engineRef.current;
        if (!e) return [];
        return e.bots.map((b) => ({
          id: b.id,
          nickname: b.nickname,
          pos: [b.pos.x, b.pos.y, b.pos.z] as [number, number, number],
          yaw: b.yaw,
          hp: b.hp,
          dead: b.dead,
        }));
      },
      () => engineRef.current?.isHost ?? false,
      (players) => {
        playersRef.current = players;
        e.applyPresence(players);
      }
    );

    return () => {
      stopServerHeartbeat();
      stopPingTracking();
      stopPlayers();
      net.leave();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [server.id]);

  // host election: lowest client_id among human database-listed players hosts;
  // the host simulates and broadcasts the bots. Bot rows are excluded — their
  // row keys are derived ids and could otherwise win the election.
  useEffect(() => {
    const fallbackAfter = Date.now() + 4000;
    const iv = setInterval(() => {
      const e = engineRef.current;
      if (!e) return;
      const wasHost = e.isHost;
      const humans = playersRef.current.filter((p) => !p.isBot);
      const others = humans.filter((p) => p.client_id !== clientId);
      const ids = humans.map((p) => p.client_id).sort();
      e.isHost = ids.length > 0 ? ids[0] === clientId : false;
      // fallback: if no other human has shown up shortly after joining, host
      // locally so the match is never empty (bots still publish to the db)
      const claimHost = e.isHost || (!others.length && e.bots.length === 0 && Date.now() > fallbackAfter);
      if (claimHost && !wasHost && e.bots.length === 0 && server.bots_count > 0) {
        const diff = botDifficultyConfig(server.bot_difficulty ?? 'normal').id as BotDifficulty;
        for (let i = 0; i < server.bots_count; i++) e.addBot(i, diff);
        e.spawnedBots = true;
        e.rebuildScores();
      }
      // a client running fallback bots hands them over once a real host exists
      if (e.spawnedBots && !e.isHost && ids.length > 0) {
        e.spawnedBots = false;
      }
    }, 1000);
    return () => clearInterval(iv);
  }, [engine, server.bots_count, server.bot_difficulty, clientId]);

  // max-ping enforcement: measured ping above the server cap kicks you out
  // of the match (0 disables the cap)
  useEffect(() => {
    const cap = server.max_ping ?? 0;
    if (!cap || kicked) return;
    if (pingMs > 0 && pingMs > cap) {
      setKicked(true);
      releaseLock();
    }
  }, [pingMs, server.max_ping, kicked]);

  const leaveAfterKick = () => {
    overRef.current = true;
    setScreen('server_browser');
  };

  // countdown
  useEffect(() => {
    if (countdown <= 0) return;
    const t = setTimeout(() => setCountdown((c) => c - 1), 700);
    return () => clearTimeout(t);
  }, [countdown]);

  // touch devices have no pointer lock: simulate the locked state once the
  // countdown ends so movement/shooting are not gated behind a mouse click
  useEffect(() => {
    if (countdown <= 0 && isTouchDevice.current) {
      input.locked = true;
      setLocked(true);
    }
  }, [countdown]);

  // match over watcher
  useEffect(() => {
    e_onMatchOver(engine, () => finishMatch());
    return () => {
      engine.onMatchOver = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine]);

  const finishMatch = useCallback(() => {
    if (overRef.current) return;
    overRef.current = true;
    const e = engine;
    releaseLock();
    const board = e.leaderboard();
    const myEntry = board.find((s) => s.id === 'local');
    const won = e.isTeamMode()
      ? (e.localTeam() === 'a' ? e.teamScores().a >= e.teamScores().b : e.teamScores().b >= e.teamScores().a)
      : board.length > 0 && board[0].id === 'local';
    setResults({
      kills: e.kills,
      deaths: e.deaths,
      score: e.kills * 2 - e.deaths,
      durationSec: Math.round(performance.now() / 1000 - e.startedAt),
      serverName: server.name,
      mapName: getMapDef(server.map_name).name,
      won,
      leaderboard: board.map((s) => ({
        id: s.id,
        nickname: s.name,
        kills: s.kills,
        deaths: s.deaths,
        isBot: s.isBot,
        isLocal: s.id === 'local',
      })),
    });
    void myEntry;
    // persist stats
    const st = useStore.getState();
    setMoney(e.money);
    getSupabase()
      .from('profiles')
      .upsert({
        client_id: st.clientId,
        username: st.nickname || 'Player',
        settings: st.settings,
      })
      .then();
    getSupabase()
      .from('matches')
      .insert({
        client_id: st.clientId,
        server_name: server.name,
        map_name: server.map_name,
        kills: e.kills,
        deaths: e.deaths,
        score: e.kills * 2 - e.deaths,
        duration_sec: Math.round(performance.now() / 1000 - e.startedAt),
      })
      .then();
    // clean up created server row
    if (created) {
      getSupabase().from('servers').delete().eq('id', server.id).then();
    }
    setScreen('results');
  }, [engine, server, created, setResults, setMoney, setScreen]);

  function e_onMatchOver(e: MatchEngine, cb: () => void): void {
    e.onMatchOver = cb;
    e.startedAt = performance.now() / 1000;
  }

  // keyboard UI toggles
  useEffect(() => {
    const kb = engine.settings.keybinds;
    const onKey = (ev: KeyboardEvent) => {
      if (ev.code === kb.buyMenu) {
        setShowBuy((v) => !v);
      }
      if (ev.code === 'Escape') {
        if (showBuyRef.current) setShowBuy(false);
        setShowBoard(false);
      }
      if (ev.code === kb.scoreboard) {
        ev.preventDefault();
        setShowBoard(true);
      }
      // weapon slots
      const digitMap: Record<string, string> = { Digit1: 'pistol', Digit2: 'smg', Digit3: 'ar', Digit4: 'awp', Digit5: 'shotgun', Digit6: 'lmg' };
      if (digitMap[ev.code]) engine.switchWeapon(digitMap[ev.code]);
    };
    const onKeyUp = (ev: KeyboardEvent) => {
      if (ev.code === kb.scoreboard) setShowBoard(false);
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [engine]);

  const showBuyRef = useRef(false);
  showBuyRef.current = showBuy;

  const handleCanvasClick = () => {
    if (!locked && !showBuy && !showBoard && countdown <= 0 && !engine.matchOver) {
      if (canvasRef.current) {
        requestLock(canvasRef.current);
      }
    }
  };

  useEffect(() => {
    const plc = () => setLocked(!!document.pointerLockElement);
    document.addEventListener('pointerlockchange', plc);
    return () => document.removeEventListener('pointerlockchange', plc);
  }, []);

  const mapDef = getMapDef(server.map_name);

  return (
    <div className="fixed inset-0 bg-black select-none">
      <Canvas
        shadows
        camera={{ fov: useStore.getState().settings.fov, near: 0.05, far: 300, position: [0, 1.6, 0] }}
        onCreated={({ gl }) => {
          gl.setClearColor(mapDef.sky);
          canvasRef.current = gl.domElement;
        }}
        onClick={handleCanvasClick}
        className="absolute inset-0"
      >
        <GameWorld mapId={server.map_name} quality={engine.settings.textureQuality} />
        <Characters engine={engine} />
      </Canvas>

      <TouchControls enabled={isTouchDevice.current && countdown <= 0 && !showBuy && !showBoard && !kicked} />

      {/* HUD */}
      {hud && (
        <>
          <Crosshair visible={locked && !showBuy && !showBoard} />
          {/* health / armor */}
          <div className="absolute bottom-4 left-4 flex gap-4 items-end font-mono">
            <div className="bg-black/55 rounded px-3 py-2 border border-white/10">
              <div className="text-[10px] uppercase tracking-widest text-emerald-300/70">HP</div>
              <div className={`text-2xl font-bold ${hud.hp < 30 ? 'text-red-400' : 'text-emerald-300'}`}>{hud.hp}</div>
            </div>
            <div className="bg-black/55 rounded px-3 py-2 border border-white/10">
              <div className="text-[10px] uppercase tracking-widest text-sky-300/70">Armor</div>
              <div className="text-2xl font-bold text-sky-300">{hud.armor}</div>
            </div>
          </div>
          {/* ammo */}
          <div className="absolute bottom-4 right-4 bg-black/55 rounded px-4 py-2 border border-white/10 font-mono text-right">
            <div className="text-[10px] uppercase tracking-widest text-amber-300/70">{hud.weaponName}</div>
            <div className="text-2xl font-bold text-white">
              {hud.reloading ? <span className="text-amber-300 animate-pulse">RELOADING…</span> : (
                <>{hud.mag} <span className="text-white/50 text-base">/ {hud.reserve}</span></>
              )}
            </div>
          </div>
          {/* money */}
          {buyAllowed && (
            <div className="absolute top-4 right-4 bg-black/55 rounded px-3 py-1.5 border border-white/10 font-mono text-emerald-300 text-lg font-bold">
              ${useStore.getState().money}
            </div>
          )}
          {/* score top-center */}
          {hud.teamMode ? (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/55 rounded px-4 py-1.5 border border-white/10 font-mono flex gap-6 text-sm items-center">
              <span className="text-emerald-300 font-bold">ALPHA {hud.teamA}</span>
              <span className="text-white/40">:</span>
              <span className="text-red-300 font-bold">BRAVO {hud.teamB}</span>
              <span className="text-white/50 text-xs">you: {hud.myTeam === 'a' ? 'ALPHA' : 'BRAVO'} · limit {server.kill_limit}</span>
            </div>
          ) : (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-black/55 rounded px-4 py-1.5 border border-white/10 font-mono flex gap-6 text-sm">
              <span className="text-emerald-300">{hud.myKills} kills</span>
              <span className="text-red-300">{hud.myDeaths} deaths</span>
              <span className="text-white/60">limit {server.kill_limit}</span>
            </div>
          )}
          {/* FPS + ping */}
          <div className="absolute top-4 left-4 flex flex-col gap-1 items-start">
            {engine.settings.showFps && (
              <div className="bg-black/55 rounded px-2 py-1 font-mono text-xs text-white/70">{hud.fps} FPS</div>
            )}
            <div
              className={`bg-black/55 rounded px-2 py-1 font-mono text-xs font-bold ${
                pingMs < 60 ? 'text-emerald-300' : pingMs < 120 ? 'text-amber-300' : 'text-red-300'
              }`}
            >
              {pingMs > 0 ? `${pingMs} ms` : '… ms'}
            </div>
          </div>
          {/* kill feed */}
          <div className="absolute top-16 right-4 flex flex-col gap-1 items-end">
            {hud.killFeed.map((k, i) => (
              <div key={k.at + '' + i} className="bg-black/50 rounded px-2 py-1 text-xs font-mono text-white/85 border border-white/5">
                {k.text}
              </div>
            ))}
          </div>
          {/* death overlay */}
          {hud.dead && (
            <div className="absolute inset-0 flex items-center justify-center bg-red-950/40 pointer-events-none">
              <div className="text-center">
                <div className="text-4xl font-bold text-red-300 font-mono">YOU DIED</div>
                <div className="text-white/70 mt-2 font-mono">Respawning in {hud.respawnIn}…</div>
              </div>
            </div>
          )}
          {/* click to lock hint (desktop only) */}
          {!locked && !showBuy && !showBoard && countdown <= 0 && !hud.dead && !engine.matchOver && !isTouchDevice.current && (
            <div
              className="absolute inset-0 flex items-center justify-center bg-black/40 cursor-pointer"
              onClick={handleCanvasClick}
            >
              <div className="text-white text-center font-mono">
                <div className="text-xl font-bold">Click to play</div>
                <div className="text-white/60 text-sm mt-1">
                  WASD move · Shift sprint · Space jump · Tab scoreboard · Y chat{buyAllowed ? ' · B buy menu' : ''}
                </div>
                <div className="text-amber-300/80 text-sm mt-1">{modeDef(server.mode).description}</div>
              </div>
            </div>
          )}
          {countdown > 0 && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50 pointer-events-none">
              <div className="text-7xl font-bold text-white font-mono">{countdown}</div>
            </div>
          )}
        </>
      )}

      {showBoard && hud && <Scoreboard entries={hud.scores} teamMode={hud.teamMode} myTeam={hud.myTeam} />}

      <ChatOverlay engine={engine} />

      {showBuy && buyAllowed && (
        <BuyMenu engine={engine} onClose={() => setShowBuy(false)} />
      )}

      {kicked && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/80">
          <div className="text-center font-mono">
            <div className="text-3xl font-bold text-red-300">KICKED: PING TOO HIGH</div>
            <div className="text-white/60 mt-2 text-sm">Your ping {pingMs} ms exceeds this server's cap of {server.max_ping} ms</div>
            <button onClick={leaveAfterKick} className="mt-5 px-5 py-2.5 rounded bg-emerald-500 hover:bg-emerald-400 text-black text-sm font-bold">
              Back to server list
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function leaveMatchCleanup(): void {
  stopServerHeartbeat();
  net.leave();
}
