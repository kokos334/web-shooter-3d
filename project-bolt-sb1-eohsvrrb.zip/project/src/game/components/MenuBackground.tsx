import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { crateTexture } from '@/game/textures';

function FloatingCrate({ tex, offset, speed }: { tex: THREE.Texture; offset: number; speed: number }): React.JSX.Element {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (!ref.current) return;
    const r = 3.2;
    const a = t * speed + offset;
    ref.current.position.set(Math.sin(a) * r, Math.sin(t * 0.8 + offset * 2) * 0.6, Math.cos(a) * r);
    ref.current.rotation.x = t * 0.4 + offset;
    ref.current.rotation.y = t * 0.55 + offset;
  });
  return (
    <group ref={ref} scale={0.9}>
      <mesh castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial map={tex} roughness={0.85} />
      </mesh>
    </group>
  );
}

export function MenuBackground(): React.JSX.Element {
  const tex = useMemo(() => crateTexture('Med'), []);
  return (
    <div className="absolute inset-0 -z-10 bg-gradient-to-b from-zinc-950 via-zinc-900 to-black">
      <Canvas shadows camera={{ position: [0, 0.6, 7], fov: 50 }} dpr={[1, 1.5]}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 8, 5]} intensity={1.2} castShadow shadow-mapSize-width={512} shadow-mapSize-height={512} />
        <pointLight position={[-6, -2, -4]} intensity={4} color="#22d3ee" />
        <pointLight position={[6, 3, -4]} intensity={4} color="#f59e0b" />
        {[0, 1, 2, 3, 4].map((i) => (
          <FloatingCrate key={i} tex={tex} offset={(i / 5) * Math.PI * 2} speed={0.5 + i * 0.07} />
        ))}
      </Canvas>
      <div className="absolute inset-0 bg-black/30" />
    </div>
  );
}
