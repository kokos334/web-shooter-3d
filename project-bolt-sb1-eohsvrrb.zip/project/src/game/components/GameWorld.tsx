import { useMemo } from 'react';
import * as THREE from 'three';
import { getMapDef } from '@/game/world';
import { crateTexture, concreteTexture, metalTexture, floorTexture } from '@/game/textures';
import type { GameSettings } from '@/game/constants';

interface WorldProps {
  mapId: string;
  quality: GameSettings['textureQuality'];
}

function BoxMesh({ p, s, t, textures }: { p: [number, number, number]; s: [number, number, number]; t: string; textures: Record<string, THREE.Texture> }) {
  const mat = textures[t] ?? textures.concrete;
  return (
    <mesh position={p} castShadow receiveShadow>
      <boxGeometry args={s} />
      <meshStandardMaterial map={mat} roughness={0.9} metalness={t === 'metal' ? 0.35 : 0.05} />
    </mesh>
  );
}

export function GameWorld({ mapId, quality }: WorldProps): React.JSX.Element {
  const map = getMapDef(mapId);
  const isNight = mapId === 'night_port';
  const isUnderwater = mapId === 'abyss_lab';
  const sunColor = isUnderwater ? '#7fd8e8' : isNight ? '#8fa8d8' : '#ffffff';
  const sunIntensity = isUnderwater ? 0.8 : isNight ? 0.45 : 1.4;
  const hemiIntensity = isUnderwater ? 0.7 : isNight ? 0.35 : 0.9;
  const fogNear = isUnderwater ? 8 : 40;
  const fogFar = isUnderwater ? 55 : 140;

  const textures = useMemo(() => {
    const crate = crateTexture(quality);
    const concrete = concreteTexture(quality);
    const metal = metalTexture(quality);
    return { crate, concrete, metal } as Record<string, THREE.Texture>;
  }, [quality]);

  const floor = useMemo(() => {
    const tex = floorTexture(quality);
    tex.repeat.set(map.size / 8, map.size / 8);
    return tex;
  }, [quality, map.size]);

  return (
    <group>
      <hemisphereLight args={[map.sky, map.floorColor, hemiIntensity]} />
      <directionalLight
        position={[30, 50, 20]}
        intensity={sunIntensity}
        color={sunColor}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-left={-60}
        shadow-camera-right={60}
        shadow-camera-top={60}
        shadow-camera-bottom={-60}
      />
      <fog attach="fog" args={[map.fog, fogNear, fogFar]} />
      <color attach="background" args={[map.sky]} />

      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[map.size, map.size]} />
        <meshStandardMaterial map={floor} roughness={0.95} />
      </mesh>

      {map.boxes.map((b, i) => (
        <BoxMesh key={i} p={b.p} s={b.s} t={b.t} textures={textures} />
      ))}
    </group>
  );
}
