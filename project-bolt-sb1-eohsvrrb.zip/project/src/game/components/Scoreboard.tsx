import type { ScoreEntry } from '@/game/engine';

function Row({ e, mine, highlight }: { e: ScoreEntry; mine: boolean; highlight: boolean }): React.JSX.Element {
  return (
    <tr className={`border-t border-white/5 ${highlight ? 'font-bold' : ''} ${mine ? 'text-emerald-300' : e.isBot ? 'text-white/80' : 'text-sky-300/90'}`}>
      <td className="py-1.5">{e.name}{e.isBot ? ' [BOT]' : ''}</td>
      <td className="text-right">{e.kills}</td>
      <td className="text-right">{e.deaths}</td>
      <td className="text-right">{e.deaths === 0 ? e.kills.toFixed(2) : (e.kills / e.deaths).toFixed(2)}</td>
    </tr>
  );
}

export function Scoreboard({ entries, teamMode, myTeam }: { entries: ScoreEntry[]; teamMode?: boolean; myTeam?: 'a' | 'b' }): React.JSX.Element {
  if (teamMode) {
    const teamA = entries.filter((e) => e.team === 'a');
    const teamB = entries.filter((e) => e.team === 'b');
    const sum = (list: ScoreEntry[]) => list.reduce((acc, e) => acc + e.kills, 0);
    const section = (title: string, list: ScoreEntry[], color: string, isMine: boolean) => (
      <div className={`flex-1 ${isMine ? '' : 'opacity-90'}`}>
        <div className={`flex justify-between text-sm font-bold tracking-wider mb-1 ${color}`}>
          <span>{title}{isMine ? ' (YOU)' : ''}</span>
          <span>{sum(list)}</span>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white/40 text-xs uppercase tracking-wider">
              <th className="text-left pb-1">Player</th>
              <th className="text-right pb-1">K</th>
              <th className="text-right pb-1">D</th>
            </tr>
          </thead>
          <tbody>
            {list.map((e) => (
              <Row key={e.id} e={e} mine={e.id === 'local'} highlight={isMine} />
            ))}
          </tbody>
        </table>
      </div>
    );
    return (
      <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/50 pointer-events-none">
        <div className="w-full max-w-2xl bg-zinc-900/95 border border-white/10 rounded-xl p-5 font-mono">
          <h3 className="text-lg font-bold text-white tracking-widest mb-3">TEAM DEATHMATCH</h3>
          <div className="flex gap-8">
            {section('ALPHA', teamA, 'text-emerald-300', myTeam === 'a')}
            {section('BRAVO', teamB, 'text-red-300', myTeam === 'b')}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/50 pointer-events-none">
      <div className="w-full max-w-lg bg-zinc-900/95 border border-white/10 rounded-xl p-5 font-mono">
        <h3 className="text-lg font-bold text-white tracking-widest mb-3">SCOREBOARD</h3>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white/40 text-xs uppercase tracking-wider">
              <th className="text-left pb-2">Player</th>
              <th className="text-right pb-2">Kills</th>
              <th className="text-right pb-2">Deaths</th>
              <th className="text-right pb-2">K/D</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((e) => (
              <Row key={e.id} e={e} mine={e.id === 'local'} highlight={false} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
