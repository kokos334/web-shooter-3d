import { useEffect, useRef, useState } from 'react';
import { Crosshair, RotateCcw, ArrowDownToLine } from 'lucide-react';
import { input } from '@/game/input';

interface Props {
  enabled: boolean;
  onFireChange?: (firing: boolean) => void;
}

const MOVE_MAX = 56;

// Virtual joystick state kept in refs so touchmove never re-renders
interface Stick {
  active: boolean;
  id: number;
  cx: number;
  cy: number;
  dx: number;
  dy: number;
}

export function TouchControls({ enabled, onFireChange }: Props): React.JSX.Element | null {
  const stickRef = useRef<Stick>({ active: false, id: -1, cx: 0, cy: 0, dx: 0, dy: 0 });
  const lookRef = useRef({ id: -1, lastX: 0, lastY: 0 });
  const [stickUi, setStickUi] = useState({ cx: 0, cy: 0, dx: 0, dy: 0, active: false });
  const [firing, setFiring] = useState(false);

  const isTouch = useRef(typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0));

  useEffect(() => {
    if (!enabled) {
      // release any held keys when controls hide (buy menu, scoreboard…)
      input.keys.delete('KeyW');
      input.keys.delete('KeyA');
      input.keys.delete('KeyS');
      input.keys.delete('KeyD');
      input.keys.delete('Space');
      input.keys.delete('ShiftLeft');
      input.keys.delete('ControlLeft');
      input.shooting = false;
    }
  }, [enabled]);

  if (!enabled || !isTouch.current) return null;

  const setKey = (code: string, down: boolean) => {
    if (down) input.keys.add(code);
    else input.keys.delete(code);
  };

  // left half of the screen: dynamic joystick — move
  const onLeftTouchStart = (e: React.TouchEvent) => {
    const t = e.changedTouches[0];
    stickRef.current = { active: true, id: t.identifier, cx: t.clientX, cy: t.clientY, dx: 0, dy: 0 };
    setStickUi({ cx: t.clientX, cy: t.clientY, dx: 0, dy: 0, active: true });
  };

  const onLeftTouchMove = (e: React.TouchEvent) => {
    const s = stickRef.current;
    if (!s.active) return;
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier !== s.id) continue;
      let dx = t.clientX - s.cx;
      let dy = t.clientY - s.cy;
      const len = Math.hypot(dx, dy);
      if (len > MOVE_MAX) {
        dx = (dx / len) * MOVE_MAX;
        dy = (dy / len) * MOVE_MAX;
      }
      s.dx = dx;
      s.dy = dy;
      setStickUi({ cx: s.cx, cy: s.cy, dx, dy, active: true });
      // WASD emulation, deadzone ~20%
      setKey('KeyW', dy < -MOVE_MAX * 0.2);
      setKey('KeyS', dy > MOVE_MAX * 0.2);
      setKey('KeyA', dx < -MOVE_MAX * 0.2);
      setKey('KeyD', dx > MOVE_MAX * 0.2);
      // sprint when the stick is pushed far forward
      setKey('ShiftLeft', dy < -MOVE_MAX * 0.85);
    }
  };

  const onLeftTouchEnd = (e: React.TouchEvent) => {
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier !== stickRef.current.id) continue;
      stickRef.current.active = false;
      stickRef.current.id = -1;
      setKey('KeyW', false);
      setKey('KeyS', false);
      setKey('KeyA', false);
      setKey('KeyD', false);
      setKey('ShiftLeft', false);
      setStickUi({ cx: 0, cy: 0, dx: 0, dy: 0, active: false });
    }
  };

  // right half: look — drag to turn, no pointer lock needed on touch
  const onRightTouchStart = (e: React.TouchEvent) => {
    const t = e.changedTouches[0];
    lookRef.current = { id: t.identifier, lastX: t.clientX, lastY: t.clientY };
  };

  const onRightTouchMove = (e: React.TouchEvent) => {
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier !== lookRef.current.id) continue;
      input.mouseDX += t.clientX - lookRef.current.lastX;
      input.mouseDY += t.clientY - lookRef.current.lastY;
      lookRef.current.lastX = t.clientX;
      lookRef.current.lastY = t.clientY;
    }
  };

  const onRightTouchEnd = (e: React.TouchEvent) => {
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier === lookRef.current.id) lookRef.current.id = -1;
    }
  };

  const btn =
    'flex items-center justify-center rounded-full bg-black/45 border border-white/20 backdrop-blur-sm active:bg-white/25 text-white select-none touch-none';

  return (
    <>
      {/* movement joystick (left) */}
      <div
        className="absolute inset-y-0 left-0 w-1/2 touch-none z-20"
        onTouchStart={onLeftTouchStart}
        onTouchMove={onLeftTouchMove}
        onTouchEnd={onLeftTouchEnd}
        onTouchCancel={onLeftTouchEnd}
      />
      {/* look area (right) */}
      <div
        className="absolute inset-y-0 right-0 w-1/2 touch-none z-20"
        onTouchStart={onRightTouchStart}
        onTouchMove={onRightTouchMove}
        onTouchEnd={onRightTouchEnd}
        onTouchCancel={onRightTouchEnd}
      />
      {/* joystick visual */}
      {stickUi.active && (
        <div className="pointer-events-none absolute z-30" style={{ left: stickUi.cx - MOVE_MAX, top: stickUi.cy - MOVE_MAX }}>
          <div className="rounded-full border-2 border-white/30" style={{ width: MOVE_MAX * 2, height: MOVE_MAX * 2 }} />
          <div
            className="absolute rounded-full bg-white/40 border border-white/60"
            style={{
              width: MOVE_MAX,
              height: MOVE_MAX,
              left: MOVE_MAX / 2 + stickUi.dx,
              top: MOVE_MAX / 2 + stickUi.dy,
            }}
          />
        </div>
      )}
      {/* action buttons (right side, above the look area) */}
      <div className="absolute bottom-24 right-5 z-30 flex flex-col items-center gap-3 touch-none">
        <button
          className={`${btn} w-14 h-14`}
          onTouchStart={(e) => {
            e.stopPropagation();
            setKey('Space', true);
          }}
          onTouchEnd={(e) => {
            e.stopPropagation();
            setKey('Space', false);
          }}
        >
          <ArrowDownToLine className="w-6 h-6 rotate-180" />
        </button>
        <div className="flex gap-3">
          <button
            className={`${btn} w-14 h-14`}
            onTouchStart={(e) => {
              e.stopPropagation();
              setKey('ControlLeft', true);
            }}
            onTouchEnd={(e) => {
              e.stopPropagation();
              setKey('ControlLeft', false);
            }}
          >
            <ArrowDownToLine className="w-6 h-6" />
          </button>
          <button
            className={`${btn} w-14 h-14`}
            onTouchStart={(e) => {
              e.stopPropagation();
              input.keys.add('KeyR');
            }}
            onTouchEnd={(e) => {
              e.stopPropagation();
              input.keys.delete('KeyR');
            }}
          >
            <RotateCcw className="w-6 h-6" />
          </button>
        </div>
      </div>
      {/* fire button */}
      <button
        className={`${btn} absolute bottom-32 right-28 z-30 w-20 h-20 touch-none ${firing ? 'bg-red-500/50 border-red-300/60' : ''}`}
        onTouchStart={(e) => {
          e.stopPropagation();
          input.shooting = true;
          setFiring(true);
          onFireChange?.(true);
        }}
        onTouchEnd={(e) => {
          e.stopPropagation();
          input.shooting = false;
          setFiring(false);
          onFireChange?.(false);
        }}
        onTouchCancel={() => {
          input.shooting = false;
          setFiring(false);
          onFireChange?.(false);
        }}
      >
        <Crosshair className="w-8 h-8" />
      </button>
    </>
  );
}
