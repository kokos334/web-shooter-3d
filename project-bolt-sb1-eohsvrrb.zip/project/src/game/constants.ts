export type MapName = 'container_yard' | 'warehouse' | 'arena_small' | 'night_port' | 'abyss_lab' | 'desert_outpost' | 'frozen_dock';
export type GameMode = 'Deathmatch' | 'Aim' | 'Team DM' | 'Gun Game' | 'One in the Chamber' | 'Insta Kill' | 'Pistols Only';
export type Region = 'EU' | 'RU' | 'US';

export interface WeaponDef {
  id: string;
  name: string;
  price: number;
  dmg: number;
  rpm: number;
  mag: number;
  reloadSec: number;
  spread: number;
  recoil: number;
}

export const WEAPONS: Record<string, WeaponDef> = {
  pistol: { id: 'pistol', name: 'Starter 9mm', price: 0, dmg: 25, rpm: 300, mag: 15, reloadSec: 1.6, spread: 0.012, recoil: 0.9 },
  shotgun: { id: 'shotgun', name: 'Boomstick-12', price: 1800, dmg: 55, rpm: 75, mag: 8, reloadSec: 3.0, spread: 0.055, recoil: 2.6 },
  smg: { id: 'smg', name: 'SMG-Spray', price: 1250, dmg: 22, rpm: 900, mag: 25, reloadSec: 2.0, spread: 0.03, recoil: 0.6 },
  ar: { id: 'ar', name: 'AR-Web', price: 2700, dmg: 35, rpm: 600, mag: 30, reloadSec: 2.2, spread: 0.018, recoil: 1.2 },
  lmg: { id: 'lmg', name: 'Minigun-X', price: 3600, dmg: 24, rpm: 1000, mag: 60, reloadSec: 4.2, spread: 0.045, recoil: 0.5 },
  awp: { id: 'awp', name: 'AWP-Web', price: 4750, dmg: 115, rpm: 40, mag: 5, reloadSec: 3.2, spread: 0.002, recoil: 3.5 },
};

export const KEVLAR_PRICE = 650;
export const KEVLAR_ARMOR = 50;

export const BUY_PHASE_SEC = 15;

export const ECONOMY = {
  start: 800,
  kill: 300,
  win: 1400,
  loss: 600,
};

export const KILL_LIMIT_CHOICES = [10, 15, 25, 50, 100, 250, 500];
export const MAX_PING_CHOICES = [0, 60, 80, 100, 150, 200];

export interface GameSettings {
  crosshair: {
    style: 'cross' | 'dot' | 'circle';
    color: string;
    size: number;
    thickness: number;
    gap: number;
    opacity: number;
  };
  sensitivity: number;
  fov: number;
  showFps: boolean;
  textureQuality: 'Low' | 'Med' | 'High';
  keybinds: Record<string, string>;
}

export const DEFAULT_KEYBINDS: Record<string, string> = {
  forward: 'KeyW',
  back: 'KeyS',
  left: 'KeyA',
  right: 'KeyD',
  jump: 'Space',
  crouch: 'KeyC',
  sprint: 'ShiftLeft',
  reload: 'KeyR',
  buyMenu: 'KeyB',
  scoreboard: 'Tab',
};

export const REBINDABLE_ACTIONS = [
  { id: 'forward', label: 'Forward' },
  { id: 'back', label: 'Back' },
  { id: 'left', label: 'Left' },
  { id: 'right', label: 'Right' },
  { id: 'jump', label: 'Jump' },
  { id: 'crouch', label: 'Crouch' },
  { id: 'sprint', label: 'Sprint' },
  { id: 'reload', label: 'Reload' },
  { id: 'buyMenu', label: 'Buy Menu' },
  { id: 'scoreboard', label: 'Scoreboard' },
] as const;

export const DEFAULT_SETTINGS: GameSettings = {
  crosshair: { style: 'cross', color: '#00ff88', size: 10, thickness: 2, gap: 4, opacity: 1 },
  sensitivity: 1.0,
  fov: 75,
  showFps: true,
  textureQuality: 'Med',
  keybinds: { ...DEFAULT_KEYBINDS },
};

export const MAPS: { id: MapName; label: string }[] = [
  { id: 'container_yard', label: 'Container Yard' },
  { id: 'warehouse', label: 'Warehouse' },
  { id: 'arena_small', label: 'Arena Small' },
  { id: 'night_port', label: 'Night Port' },
  { id: 'abyss_lab', label: 'Abyss Lab (Underwater)' },
  { id: 'desert_outpost', label: 'Desert Outpost' },
  { id: 'frozen_dock', label: 'Frozen Dock' },
];

export const MODES: GameMode[] = ['Deathmatch', 'Aim', 'Team DM', 'Gun Game', 'One in the Chamber', 'Insta Kill', 'Pistols Only'];

export interface ModeDef {
  id: GameMode;
  label: string;
  description: string;
}

export const MODE_DEFS: ModeDef[] = [
  { id: 'Deathmatch', label: 'Deathmatch', description: 'Classic free-for-all. Buy any weapons. First to the kill limit wins.' },
  { id: 'Aim', label: 'Aim', description: 'Headshots only do damage. Body and leg shots are ignored.' },
  { id: 'Team DM', label: 'Team DM', description: 'You and your bots vs enemy bots. First team to the kill limit wins.' },
  { id: 'Gun Game', label: 'Gun Game', description: 'Every kill upgrades your weapon through the ladder. First through all weapons wins.' },
  { id: 'One in the Chamber', label: 'One in the Chamber', description: 'One bullet, one kill. Hit or miss, you are left with a knife-speed pistol. Kills reload your chamber.' },
  { id: 'Insta Kill', label: 'Insta Kill', description: 'Any hit is lethal. Pure reflexes.' },
  { id: 'Pistols Only', label: 'Pistols Only', description: 'Buy menu is disabled — everyone plays with the starter pistol.' },
];

export function modeDef(id: string): ModeDef {
  return MODE_DEFS.find((m) => m.id === id) ?? MODE_DEFS[0];
}

export const GUN_GAME_LADDER = ['pistol', 'smg', 'shotgun', 'ar', 'lmg', 'awp'];
export const REGIONS: Region[] = ['EU', 'RU', 'US'];

export const HITBOX = { head: 3, body: 1, legs: 0.7 };

export type BotDifficulty = 'easy' | 'normal' | 'hard' | 'impossible';

export interface BotDifficultyDef {
  id: BotDifficulty;
  label: string;
  reactionDelayMs: number;
  spreadDeg: number;
  color: string;
}

export const BOT_DIFFICULTIES: BotDifficultyDef[] = [
  { id: 'easy', label: 'Easy', reactionDelayMs: 7000, spreadDeg: 8, color: 'text-emerald-400' },
  { id: 'normal', label: 'Normal', reactionDelayMs: 5000, spreadDeg: 5, color: 'text-amber-300' },
  { id: 'hard', label: 'Hard', reactionDelayMs: 2000, spreadDeg: 2, color: 'text-orange-400' },
  { id: 'impossible', label: 'Impossible', reactionDelayMs: 10, spreadDeg: 0.3, color: 'text-red-400' },
];

export function botDifficultyConfig(id: string): BotDifficultyDef {
  return BOT_DIFFICULTIES.find((d) => d.id === id) ?? BOT_DIFFICULTIES[1];
}

export function isValidNickname(n: string): boolean {
  return /^[A-Za-z0-9_]{3,16}$/.test(n);
}

export function keyLabel(code: string): string {
  if (!code) return '---';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code === 'Space') return 'SPACE';
  if (code === 'ShiftLeft' || code === 'ShiftRight') return 'SHIFT';
  if (code === 'ControlLeft' || code === 'ControlRight') return 'CTRL';
  if (code === 'AltLeft' || code === 'AltRight') return 'ALT';
  if (code === 'Tab') return 'TAB';
  if (code === 'CapsLock') return 'CAPS';
  return code.toUpperCase();
}
