import { useEffect, useRef } from 'react';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { WEAPONS } from '@/game/constants';
import type { MatchEngine } from '@/game/engine';

// Geometry is authored in ~10cm units; the group is scaled down to 0.05 so the
// finished gun is roughly 40-50cm long when held 0.5m from the camera.
const GUN_SCALE = 0.05;

// Metals render black without an environment map, so keep metalness low.
const bodyMaterial = { color: '#9aa0a6', metalness: 0.45, roughness: 0.4 } as const;
const gripMaterial = { color: '#3a3d42', metalness: 0.2, roughness: 0.7 } as const;
const barrelMaterial = { color: '#6b7076', metalness: 0.5, roughness: 0.35 } as const;
const matProps = {
  depthTest: false,
  depthWrite: false,
} as const;

export function WeaponViewModel({ engine }: { engine: MatchEngine }): React.JSX.Element {
  const camera = useThree((state) => state.camera);
  const scene = useThree((state) => state.scene);
  const weaponGroup = useRef<THREE.Group>(null);

  useEffect(() => {
    const g = weaponGroup.current;
    if (!g) return;
    // three.js only renders descendants of the scene, so the camera itself
    // must be part of the scene for its children (the gun) to be drawn.
    scene.add(camera);
    camera.add(g);
    return () => {
      camera.remove(g);
      scene.remove(camera);
    };
  }, [camera, scene]);

  const w = WEAPONS[engine.weaponId];
  const barrelLen = w.id === 'awp' ? 6 : w.id === 'pistol' ? 3 : 4.5;

  return (
    <group
      ref={weaponGroup}
      scale={[GUN_SCALE, GUN_SCALE, GUN_SCALE]}
      position={[0.3, -0.3, -0.5]}
      rotation={[0, -Math.PI / 8, 0]}
    >
      {/* body */}
      <mesh position={[0, 0, -barrelLen / 2]} renderOrder={999}>
        <boxGeometry args={[1.2, 1.6, barrelLen]} />
        <meshStandardMaterial {...bodyMaterial} {...matProps} />
      </mesh>
      {/* slide */}
      <mesh position={[0, 1.0, -barrelLen / 2]} renderOrder={999}>
        <boxGeometry args={[1.1, 0.8, barrelLen * 0.9]} />
        <meshStandardMaterial {...barrelMaterial} {...matProps} />
      </mesh>
      {/* grip */}
      <mesh position={[0, -1.6, 0.6]} rotation={[0.3, 0, 0]} renderOrder={999}>
        <boxGeometry args={[1.0, 2.6, 1.4]} />
        <meshStandardMaterial {...gripMaterial} {...matProps} />
      </mesh>
      {/* barrel */}
      <mesh position={[0, 0.4, -barrelLen - 0.6]} rotation={[Math.PI / 2, 0, 0]} renderOrder={999}>
        <cylinderGeometry args={[0.28, 0.28, 1.6, 8]} />
        <meshStandardMaterial {...barrelMaterial} {...matProps} />
      </mesh>
      {/* scope for sniper */}
      {w.id === 'awp' && (
        <mesh position={[0, 2.2, -barrelLen / 2]} rotation={[Math.PI / 2, 0, 0]} renderOrder={999}>
          <cylinderGeometry args={[0.5, 0.5, 3, 10]} />
          <meshStandardMaterial {...barrelMaterial} {...matProps} />
        </mesh>
      )}
    </group>
  );
}
