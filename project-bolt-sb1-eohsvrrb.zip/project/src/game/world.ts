export type TextureKind = 'crate' | 'metal' | 'concrete';

export interface WorldBox {
  p: [number, number, number]; // center
  s: [number, number, number]; // size
  t: TextureKind;
}

export interface MapDef {
  name: string;
  size: number; // half-extent of playable square
  sky: string;
  fog: string;
  floorColor: string;
  boxes: WorldBox[];
  spawns: [number, number][];
  waypoints: [number, number][];
}

function perimeter(size: number, h: number): WorldBox[] {
  const t = 1;
  const c = size / 2;
  return [
    { p: [0, h / 2, -c], s: [size + t, h, t], t: 'concrete' },
    { p: [0, h / 2, c], s: [size + t, h, t], t: 'concrete' },
    { p: [-c, h / 2, 0], s: [t, h, size + t], t: 'concrete' },
    { p: [c, h / 2, 0], s: [t, h, size + t], t: 'concrete' },
  ];
}

const containerYard: MapDef = {
  name: 'Container Yard',
  size: 56,
  sky: '#9db4c8',
  fog: '#9db4c8',
  floorColor: '#5a5d63',
  boxes: [
    // containers (metal)
    { p: [-14, 1.3, -10], s: [12, 2.6, 3], t: 'metal' },
    { p: [-14, 3.9, -10], s: [12, 2.6, 3], t: 'metal' },
    { p: [10, 1.3, -16], s: [3, 2.6, 14], t: 'metal' },
    { p: [16, 1.3, 8], s: [12, 2.6, 3], t: 'metal' },
    { p: [-4, 1.3, 14], s: [3, 2.6, 12], t: 'metal' },
    { p: [-18, 1.3, 4], s: [3, 2.6, 12], t: 'metal' },
    { p: [2, 1.3, -4], s: [10, 2.6, 3], t: 'metal' },
    // crates
    { p: [6, 0.75, 2], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [6, 2.25, 2], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-8, 0.75, -18], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [18, 0.75, -6], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-22, 0.75, -14], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [0, 0.75, 20], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [22, 0.75, 18], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-24, 0.75, 18], s: [1.5, 1.5, 1.5], t: 'crate' },
    // center ramp-block
    { p: [0, 0.65, 6], s: [6, 1.3, 6], t: 'concrete' },
    ...perimeter(56, 5),
  ],
  spawns: [
    [-22, -22], [22, -22], [-22, 22], [22, 22], [0, -24], [0, 24], [-24, 0], [24, 0],
    [-10, 18], [10, -18],
  ],
  waypoints: [
    [-20, -20], [0, -18], [20, -20], [24, 0], [18, 16], [0, 22], [-18, 16], [-24, 0],
    [-8, -4], [8, 4], [0, 12], [-14, 8],
  ],
};

const warehouse: MapDef = {
  name: 'Warehouse',
  size: 44,
  sky: '#8a8f96',
  fog: '#8a8f96',
  floorColor: '#4e5055',
  boxes: [
    // outer building walls with gaps
    { p: [-12, 1.5, -16], s: [14, 3, 1], t: 'concrete' },
    { p: [14, 1.5, -16], s: [10, 3, 1], t: 'concrete' },
    { p: [-16, 1.5, 14], s: [12, 3, 1], t: 'concrete' },
    { p: [16, 1.5, 14], s: [12, 3, 1], t: 'concrete' },
    { p: [-20, 1.5, -4], s: [1, 3, 14], t: 'concrete' },
    { p: [-20, 1.5, 12], s: [1, 3, 8], t: 'concrete' },
    { p: [20, 1.5, 0], s: [1, 3, 20], t: 'concrete' },
    // shelving rows
    { p: [-6, 1.25, -6], s: [10, 2.5, 2], t: 'metal' },
    { p: [8, 1.25, -2], s: [2, 2.5, 12], t: 'metal' },
    { p: [-2, 1.25, 8], s: [12, 2.5, 2], t: 'metal' },
    { p: [4, 1.25, -12], s: [2, 2.5, 8], t: 'metal' },
    // crates
    { p: [0, 0.75, 0], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [1.6, 0.75, 0], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [0.8, 2.25, 0], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-14, 0.75, 2], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [14, 0.75, 8], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-8, 0.75, -14], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [12, 0.75, -10], s: [1.5, 1.5, 1.5], t: 'crate' },
    ...perimeter(44, 6),
  ],
  spawns: [
    [-16, -16], [16, -16], [-16, 16], [16, 16], [0, -16], [0, 16], [-16, 0], [16, 0],
    [-10, 6], [10, -6],
  ],
  waypoints: [
    [-14, -14], [0, -12], [14, -14], [16, 0], [14, 12], [0, 14], [-14, 12], [-14, 0],
    [-6, -10], [12, -2], [-2, 11], [8, -12],
  ],
};

const arenaSmall: MapDef = {
  name: 'Arena Small',
  size: 32,
  sky: '#a8b8b0',
  fog: '#a8b8b0',
  floorColor: '#5c6058',
  boxes: [
    // symmetric cover
    { p: [-8, 1.3, -8], s: [5, 2.6, 2], t: 'crate' },
    { p: [8, 1.3, 8], s: [5, 2.6, 2], t: 'crate' },
    { p: [8, 1.3, -8], s: [2, 2.6, 5], t: 'metal' },
    { p: [-8, 1.3, 8], s: [2, 2.6, 5], t: 'metal' },
    { p: [0, 0.65, 0], s: [4, 1.3, 4], t: 'concrete' },
    { p: [-13, 1.3, 0], s: [2, 2.6, 6], t: 'metal' },
    { p: [13, 1.3, 0], s: [2, 2.6, 6], t: 'metal' },
    { p: [0, 1.3, -13], s: [6, 2.6, 2], t: 'metal' },
    { p: [0, 1.3, 13], s: [6, 2.6, 2], t: 'metal' },
    { p: [-4, 0.75, -4], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [4, 0.75, 4], s: [1.5, 1.5, 1.5], t: 'crate' },
    ...perimeter(32, 5),
  ],
  spawns: [
    [-12, -12], [12, -12], [-12, 12], [12, 12], [0, -13], [0, 13], [-13, 0], [13, 0],
    [-6, 10], [6, -10],
  ],
  waypoints: [
    [-12, -12], [0, -11], [12, -12], [13, 0], [12, 12], [0, 12], [-12, 12], [-13, 0],
    [-6, -6], [6, 6], [-6, 6], [6, -6],
  ],
};

const nightPort: MapDef = {
  name: 'Night Port',
  size: 56,
  sky: '#0a0e1a',
  fog: '#0a0e1a',
  floorColor: '#141a26',
  boxes: [
    // stacked shipping containers as cover
    { p: [-16, 1.3, -12], s: [10, 2.6, 3], t: 'metal' },
    { p: [-16, 3.9, -12], s: [10, 2.6, 3], t: 'metal' },
    { p: [12, 1.3, -14], s: [3, 2.6, 12], t: 'metal' },
    { p: [18, 1.3, 10], s: [10, 2.6, 3], t: 'metal' },
    { p: [-6, 1.3, 16], s: [12, 2.6, 3], t: 'metal' },
    { p: [-20, 1.3, 6], s: [3, 2.6, 10], t: 'metal' },
    { p: [4, 1.3, -2], s: [8, 2.6, 3], t: 'metal' },
    { p: [22, 1.3, -20], s: [6, 2.6, 3], t: 'metal' },
    { p: [-24, 1.3, -22], s: [3, 2.6, 6], t: 'metal' },
    // crates
    { p: [0, 0.75, 8], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [1.6, 0.75, 8], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-10, 0.75, -2], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [10, 0.75, 20], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [20, 0.75, -8], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-22, 0.75, 18], s: [1.5, 1.5, 1.5], t: 'crate' },
    // center loading platform
    { p: [0, 0.65, 0], s: [6, 1.3, 6], t: 'concrete' },
    ...perimeter(56, 6),
  ],
  spawns: [
    [-22, -22], [22, -22], [-22, 22], [22, 22], [0, -24], [0, 24], [-24, 0], [24, 0],
    [-10, 14], [12, -18],
  ],
  waypoints: [
    [-22, -20], [0, -20], [22, -22], [24, -8], [18, 16], [0, 22], [-18, 18], [-24, 6],
    [-10, -2], [8, 6], [0, 14], [14, -4],
  ],
};

const abyssLab: MapDef = {
  name: 'Abyss Lab',
  size: 44,
  sky: '#03222e',
  fog: '#03222e',
  floorColor: '#06303f',
  boxes: [
    // outer lab walls with gaps
    { p: [-12, 1.5, -16], s: [14, 3, 1], t: 'concrete' },
    { p: [14, 1.5, -16], s: [10, 3, 1], t: 'concrete' },
    { p: [-16, 1.5, 14], s: [12, 3, 1], t: 'concrete' },
    { p: [16, 1.5, 14], s: [12, 3, 1], t: 'concrete' },
    { p: [-20, 1.5, -4], s: [1, 3, 14], t: 'concrete' },
    { p: [-20, 1.5, 12], s: [1, 3, 8], t: 'concrete' },
    { p: [20, 1.5, 0], s: [1, 3, 20], t: 'concrete' },
    // coral tanks and lab equipment
    { p: [-6, 1.25, -6], s: [8, 2.5, 2], t: 'metal' },
    { p: [8, 1.25, -2], s: [2, 2.5, 10], t: 'metal' },
    { p: [-2, 1.25, 8], s: [10, 2.5, 2], t: 'metal' },
    { p: [4, 1.25, -12], s: [2, 2.5, 6], t: 'metal' },
    { p: [-14, 1.25, 6], s: [2, 2.5, 6], t: 'metal' },
    // crates
    { p: [0, 0.75, 0], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [1.6, 0.75, 0], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-14, 0.75, -10], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [14, 0.75, 8], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-8, 0.75, -14], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [12, 0.75, -10], s: [1.5, 1.5, 1.5], t: 'crate' },
    // center reactor
    { p: [0, 0.65, 4], s: [5, 1.3, 5], t: 'concrete' },
    ...perimeter(44, 6),
  ],
  spawns: [
    [-16, -16], [16, -16], [-16, 16], [16, 16], [0, -16], [0, 16], [-16, 0], [16, 0],
    [-10, 6], [10, -6],
  ],
  waypoints: [
    [-14, -14], [0, -12], [14, -14], [16, 0], [14, 12], [0, 14], [-14, 12], [-14, 0],
    [-6, -10], [12, -4], [-2, 11], [8, -12],
  ],
};

const desertOutpost: MapDef = {
  name: 'Desert Outpost',
  size: 56,
  sky: '#d8b98a',
  fog: '#d8b98a',
  floorColor: '#b09568',
  boxes: [
    // sandstone walls and barricades
    { p: [-14, 1.3, -10], s: [12, 2.6, 3], t: 'concrete' },
    { p: [12, 1.3, -16], s: [3, 2.6, 14], t: 'concrete' },
    { p: [16, 1.3, 8], s: [12, 2.6, 3], t: 'concrete' },
    { p: [-4, 1.3, 14], s: [3, 2.6, 12], t: 'concrete' },
    { p: [-18, 1.3, 4], s: [3, 2.6, 12], t: 'concrete' },
    { p: [2, 1.3, -4], s: [10, 2.6, 3], t: 'concrete' },
    { p: [22, 1.3, -18], s: [8, 2.6, 3], t: 'concrete' },
    // crates
    { p: [6, 0.75, 2], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [6, 2.25, 2], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-8, 0.75, -18], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [18, 0.75, -6], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-22, 0.75, -14], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [0, 0.75, 20], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-24, 0.75, 18], s: [1.5, 1.5, 1.5], t: 'crate' },
    // center bunker
    { p: [0, 0.65, 6], s: [6, 1.3, 6], t: 'concrete' },
    ...perimeter(56, 5),
  ],
  spawns: [
    [-22, -22], [22, -22], [-22, 22], [22, 22], [0, -24], [0, 24], [-24, 0], [24, 0],
    [-10, 18], [10, -18],
  ],
  waypoints: [
    [-20, -20], [0, -18], [20, -20], [24, 0], [18, 16], [0, 22], [-18, 16], [-24, 0],
    [-8, -4], [8, 4], [0, 12], [-14, 8],
  ],
};

const frozenDock: MapDef = {
  name: 'Frozen Dock',
  size: 44,
  sky: '#c8d8e8',
  fog: '#c8d8e8',
  floorColor: '#a8b8c8',
  boxes: [
    // ice containers and stacked cargo
    { p: [-12, 1.5, -16], s: [14, 3, 1], t: 'metal' },
    { p: [14, 1.5, -16], s: [10, 3, 1], t: 'metal' },
    { p: [-16, 1.5, 14], s: [12, 3, 1], t: 'metal' },
    { p: [16, 1.5, 14], s: [12, 3, 1], t: 'metal' },
    { p: [-20, 1.5, -4], s: [1, 3, 14], t: 'metal' },
    { p: [-20, 1.5, 12], s: [1, 3, 8], t: 'metal' },
    { p: [20, 1.5, 0], s: [1, 3, 20], t: 'metal' },
    { p: [-6, 1.25, -6], s: [10, 2.5, 2], t: 'metal' },
    { p: [8, 1.25, -2], s: [2, 2.5, 12], t: 'metal' },
    { p: [-2, 1.25, 8], s: [12, 2.5, 2], t: 'metal' },
    { p: [4, 1.25, -12], s: [2, 2.5, 8], t: 'metal' },
    // crates
    { p: [0, 0.75, 0], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-14, 0.75, 2], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [14, 0.75, 8], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [-8, 0.75, -14], s: [1.5, 1.5, 1.5], t: 'crate' },
    { p: [12, 0.75, -10], s: [1.5, 1.5, 1.5], t: 'crate' },
    ...perimeter(44, 6),
  ],
  spawns: [
    [-16, -16], [16, -16], [-16, 16], [16, 16], [0, -16], [0, 16], [-16, 0], [16, 0],
    [-10, 6], [10, -6],
  ],
  waypoints: [
    [-14, -14], [0, -12], [14, -14], [16, 0], [14, 12], [0, 14], [-14, 12], [-14, 0],
    [-6, -10], [12, -2], [-2, 11], [8, -12],
  ],
};

export const MAP_DEFS: Record<string, MapDef> = {
  container_yard: containerYard,
  warehouse: warehouse,
  arena_small: arenaSmall,
  night_port: nightPort,
  abyss_lab: abyssLab,
  desert_outpost: desertOutpost,
  frozen_dock: frozenDock,
};

export function getMapDef(id: string): MapDef {
  return MAP_DEFS[id] ?? containerYard;
}

export function isInsideBounds(map: MapDef, x: number, z: number): boolean {
  const c = map.size / 2 - 1;
  return Math.abs(x) <= c && Math.abs(z) <= c;
}

// Simple AABB overlap check used by bots to not walk into walls (XZ plane)
export function blockedByBox(map: MapDef, x: number, z: number, radius: number): boolean {
  for (const b of map.boxes) {
    const [w, , d] = b.s;
    if (w === 0) continue;
    const hw = w / 2 + radius;
    const hd = d / 2 + radius;
    if (
      x > b.p[0] - hw && x < b.p[0] + hw &&
      z > b.p[2] - hd && z < b.p[2] + hd &&
      b.p[1] + b.s[1] / 2 > 0.3 // ignore buried boxes
    ) {
      return true;
    }
  }
  return false;
}
