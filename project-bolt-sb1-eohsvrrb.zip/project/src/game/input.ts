export const input = {
  keys: new Set<string>(),
  mouseDX: 0,
  mouseDY: 0,
  shooting: false,
  locked: false,
  rebinding: null as null | string,
};

export function bindInput(): () => void {
  const kd = (e: KeyboardEvent) => {
    if (input.rebinding) return; // settings screen handles capture
    input.keys.add(e.code);
    if (e.code === 'Tab' || e.code === 'Space') e.preventDefault();
  };
  const ku = (e: KeyboardEvent) => input.keys.delete(e.code);
  const mm = (e: MouseEvent) => {
    if (!input.locked) return;
    input.mouseDX += e.movementX;
    input.mouseDY += e.movementY;
  };
  const md = (e: MouseEvent) => {
    if (e.button === 0) input.shooting = true;
  };
  const mu = (e: MouseEvent) => {
    if (e.button === 0) input.shooting = false;
  };
  const plc = () => {
    input.locked = document.pointerLockElement !== null;
    if (!input.locked) input.keys.clear();
    input.shooting = false;
  };
  window.addEventListener('keydown', kd);
  window.addEventListener('keyup', ku);
  window.addEventListener('mousemove', mm);
  window.addEventListener('mousedown', md);
  window.addEventListener('mouseup', mu);
  document.addEventListener('pointerlockchange', plc);
  return () => {
    window.removeEventListener('keydown', kd);
    window.removeEventListener('keyup', ku);
    window.removeEventListener('mousemove', mm);
    window.removeEventListener('mousedown', md);
    window.removeEventListener('mouseup', mu);
    document.removeEventListener('pointerlockchange', plc);
    input.keys.clear();
    input.shooting = false;
    input.locked = false;
  };
}

export function requestLock(canvas: HTMLCanvasElement): void {
  try {
    const result = canvas.requestPointerLock?.() as unknown;
    if (result && typeof (result as Promise<void>).catch === 'function') {
      (result as Promise<void>).catch(() => {});
    }
  } catch {
    // browser refused (e.g. too soon after exiting) — user can click again
  }
}

export function releaseLock(): void {
  document.exitPointerLock?.();
}
