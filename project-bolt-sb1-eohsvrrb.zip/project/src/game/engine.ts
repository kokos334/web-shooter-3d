import * as THREE from 'three';
import { getMapDef, blockedByBox, isInsideBounds, type MapDef } from '@/game/world';
import { WEAPONS, HITBOX, botDifficultyConfig, GUN_GAME_LADDER, type WeaponDef, type GameSettings, type BotDifficulty, type GameMode } from '@/game/constants';
import { net, type MoveSnapshot, type PresencePlayer } from '@/game/net';
import { useStore } from '@/store';
import { input } from '@/game/input';

export interface Bot {
  id: string;
  nickname: string;
  team: 'a' | 'b';
  weaponId: string;
  pos: THREE.Vector3;
  yaw: number;
  hp: number;
  dead: boolean;
  respawnAt: number;
  kills: number;
  deaths: number;
  state: 'patrol' | 'chase' | 'alert' | 'attack';
  wpIdx: number;
  targetPos: THREE.Vector3;
  lastSeen: THREE.Vector3;
  velY: number;
  nextShootAt: number;
  sawPlayerAt: number;
  lostSightAt: number;
  reactionAt: number;
  lastPatrolPos: THREE.Vector3;
  lastPatrolCheckAt: number;
  difficulty: BotDifficulty;
  reactionDelayMs: number;
  spreadDeg: number;
}

export interface BotTarget {
  id: string;
  pos: THREE.Vector3;
  crouch: boolean;
  name: string;
  isLocal: boolean;
  team: 'a' | 'b';
  bot?: Bot;
}

export interface RemotePlayer {
  id: string;
  nickname: string;
  pos: THREE.Vector3;
  yaw: number;
  pitch: number;
  crouch: boolean;
  anim: number;
  kills: number;
  deaths: number;
  hp: number;
  weaponId: string;
  lastUpdate: number;
  snapshots: { t: number; p: THREE.Vector3; ry: number; rp: number }[];
}

export interface ScoreEntry {
  id: string;
  name: string;
  kills: number;
  deaths: number;
  isBot: boolean;
  team?: 'a' | 'b';
}

const GRAVITY = 22;
const JUMP_V = 8.2;
const WALK = 6.2;
const SPRINT = 9.0;
const CROUCH_W = 3.0;
const PLAYER_R = 0.45;
const EYE_STAND = 1.62;
const EYE_CROUCH = 0.95;
const MAX_HP = 100;
const RESPAWN_INVULN = 1.0;

// cosmetic weapon each bot carries (visible in its hands)
const BOT_WEAPONS = ['pistol', 'smg', 'ar', 'shotgun', 'lmg', 'awp'];

export class MatchEngine {
  map: MapDef;
  settings: GameSettings;
  mode: GameMode;
  killLimit = 10;
  isHost = false;
  running = false;
  startedAt = 0;
  buyPhaseEndsAt = 0;
  gunGameStage = 0;
  chamberBullets = 1;

  // local player
  pos = new THREE.Vector3(0, 0, 0);
  vel = new THREE.Vector3();
  yaw = 0;
  pitch = 0;
  crouching = false;
  onGround = true;
  hp = MAX_HP;
  armor = 0;
  dead = false;
  respawnAt = 0;
  invulnUntil = 0;
  kills = 0;
  deaths = 0;
  money = 800;
  weaponId = 'pistol';
  magAmmo = 15;
  reserveAmmo = 60;
  reloadingUntil = 0;
  nextShotAt = 0;
  recoilKick = 0;
  shotIndex = 0;

  bots: Bot[] = [];
  remotes = new Map<string, RemotePlayer>();
  scores = new Map<string, ScoreEntry>();
  chatLog: { fromName: string; text: string; at: number }[] = [];
  killFeed: { text: string; at: number }[] = [];
  hitsOnLocal: { dmg: number; dir: THREE.Vector3; at: number }[] = [];

  rosterId = 'local';
  spawnedBots = false;

  winnerId: string | null = null;
  matchOver = false;
  onMatchOver: ((winnerId: string) => void) | null = null;
  onChat: (() => void) | null = null;
  private lastAttackerId = '';

  private fpsFrames = 0;
  private fpsTime = 0;
  fps = 0;

  constructor(mapId: string, settings: GameSettings, killLimit: number, botsCount: number, money: number, mode: GameMode = 'Deathmatch', rosterId = 'local') {
    this.rosterId = rosterId;
    this.map = getMapDef(mapId);
    this.settings = settings;
    this.mode = mode;
    this.killLimit = killLimit;
    this.money = money;
    // everyone starts with the pistol; better guns are bought in the buy menu
    this.weaponId = 'pistol';
    this.magAmmo = WEAPONS.pistol.mag;
    this.reserveAmmo = WEAPONS.pistol.mag * 4;
    if (mode === 'Gun Game') {
      this.killLimit = GUN_GAME_LADDER.length;
      this.equipLadderStage(0);
    }
    if (mode === 'One in the Chamber') this.equipChamber();
    this.spawnLocal();
    for (let i = 0; i < botsCount; i++) this.addBot(i);
    this.rebuildScores();
  }

  // ---------- spawning ----------

  buyMenuAllowed(): boolean {
    return this.mode !== 'Pistols Only' && this.mode !== 'Gun Game' && this.mode !== 'One in the Chamber';
  }

  equipLadderStage(stage: number): void {
    const idx = Math.min(stage, GUN_GAME_LADDER.length - 1);
    this.gunGameStage = idx;
    this.weaponId = GUN_GAME_LADDER[idx];
    this.refillAmmo();
  }

  equipChamber(): void {
    this.chamberBullets = 1;
    this.weaponId = 'pistol';
    this.magAmmo = 1;
    this.reserveAmmo = 0;
    this.reloadingUntil = 0;
  }

  spawnPoint(): THREE.Vector3 {
    // dead-zone safe spawn: never inside a box/wall, and not too close to
    // another living player or bot
    const map = this.map;
    for (let tries = 0; tries < 40; tries++) {
      const sp = map.spawns[Math.floor(Math.random() * map.spawns.length)];
      const x = sp[0] + (Math.random() - 0.5) * 3;
      const z = sp[1] + (Math.random() - 0.5) * 3;
      if (blockedByBox(map, x, z, 0.8)) continue;
      if (!isInsideBounds(map, x, z)) continue;
      let tooClose = false;
      const near = (px: number, pz: number) => Math.hypot(px - x, pz - z) < 3;
      if (near(this.pos.x, this.pos.z)) tooClose = true;
      for (const b of this.bots) if (!b.dead && near(b.pos.x, b.pos.z)) tooClose = true;
      for (const [, r] of this.remotes) if (near(r.pos.x, r.pos.z)) tooClose = true;
      if (tooClose && tries < 30) continue;
      return new THREE.Vector3(x, 0, z);
    }
    const sp = map.spawns[0];
    return new THREE.Vector3(sp[0], 0, sp[1]);
  }

  spawnLocal(): void {
    const p = this.spawnPoint();
    this.pos.copy(p);
    this.vel.set(0, 0, 0);
    this.hp = MAX_HP;
    this.armor = 0;
    this.dead = false;
    this.crouching = false;
    this.invulnUntil = performance.now() / 1000 + RESPAWN_INVULN;
    this.refillAmmo();
  }

  refillAmmo(): void {
    this.magAmmo = WEAPONS[this.weaponId].mag;
    this.reserveAmmo = WEAPONS[this.weaponId].mag * 4;
    this.reloadingUntil = 0;
    if (this.mode === 'One in the Chamber') {
      this.magAmmo = this.chamberBullets;
      this.reserveAmmo = 0;
    }
  }

  botNickname(i: number): string {
    const names = ['CyberDoom', 'xX_Havoc_Xx', 'SgtPepper', 'NoScope_Nina', 'DustRunner', 'IronMike', 'GhostByte', 'RushB', 'Wh1spr', 'TapSnap', 'LagWizard', 'PixelPain', 'Bot_Storm', 'ZeroPing'];
    return names[i % names.length] + (i >= names.length ? String(Math.floor(i / names.length)) : '');
  }

  addBot(i: number, difficulty: BotDifficulty = 'normal'): void {
    // deterministic id: every client derives the same roster, so the host's
    // broadcasted bot state merges in place instead of duplicating bots
    const id = `bot_${this.rosterId}_${i}`;
    const p = this.spawnPoint();
    const diff = botDifficultyConfig(difficulty);
    const wp = this.map.waypoints[i % Math.max(1, this.map.waypoints.length)] ?? [0, 0];
    this.bots.push({
      id,
      nickname: this.botNickname(i),
      team: i % 2 === 0 ? 'a' : 'b',
      weaponId: BOT_WEAPONS[i % BOT_WEAPONS.length],
      pos: p.clone(),
      yaw: Math.random() * Math.PI * 2,
      hp: MAX_HP,
      dead: false,
      respawnAt: 0,
      kills: 0,
      deaths: 0,
      state: 'patrol',
      wpIdx: Math.floor(Math.random() * this.map.waypoints.length),
      targetPos: new THREE.Vector3(wp[0], 0, wp[1]),
      lastSeen: p.clone(),
      velY: 0,
      nextShootAt: 0,
      sawPlayerAt: 0,
      lostSightAt: 0,
      reactionAt: 0,
      lastPatrolPos: p.clone(),
      lastPatrolCheckAt: 0,
      difficulty,
      reactionDelayMs: diff.reactionDelayMs,
      spreadDeg: diff.spreadDeg,
    });
  }

  rebuildScores(): void {
    const { nickname, clientId } = useStore.getState();
    this.scores.set('local', { id: 'local', name: nickname || 'Player', kills: this.kills, deaths: this.deaths, isBot: false });
    for (const b of this.bots) this.scores.set(b.id, { id: b.id, name: b.nickname, kills: b.kills, deaths: b.deaths, isBot: true });
    for (const [rid, r] of this.remotes) this.scores.set(rid, { id: rid, name: r.nickname, kills: r.kills, deaths: r.deaths, isBot: false });
  }

  // ---------- networking glue ----------

  applyRemoteMove(s: MoveSnapshot): void {
    if (s.id === this.localKey()) return;
    let r = this.remotes.get(s.id);
    if (!r) {
      r = {
        id: s.id,
        nickname: 'Player',
        pos: new THREE.Vector3(...s.p),
        yaw: s.ry,
        pitch: s.rp,
        crouch: s.crouch,
        anim: s.anim,
        kills: 0,
        deaths: 0,
        hp: 100,
        weaponId: 'pistol',
        lastUpdate: performance.now(),
        snapshots: [],
      };
      this.remotes.set(s.id, r);
      this.rebuildScores();
    }
    r.snapshots.push({ t: performance.now(), p: new THREE.Vector3(...s.p), ry: s.ry, rp: s.rp });
    if (r.snapshots.length > 2) r.snapshots.shift();
    r.crouch = s.crouch;
    r.anim = s.anim;
    if (s.weapon && WEAPONS[s.weapon]) r.weaponId = s.weapon;
    r.lastUpdate = performance.now();
  }

  applyBotState(bots: { id: string; p: [number, number, number]; ry: number; hp: number; dead: boolean }[]): void {
    if (this.isHost) return;
    let changed = false;
    const roster = new Map(bots.map((s) => [s.id, s]));
    // drop anything not in the host's roster (e.g. bots from an earlier
    // fallback spawn) so the roster stays identical on every client
    this.bots = this.bots.filter((b) => roster.has(b.id));
    for (const s of bots) {
      const b = this.bots.find((x) => x.id === s.id);
      if (b) {
        b.pos.set(...s.p);
        b.yaw = s.ry;
        b.hp = s.hp;
        b.dead = s.dead;
      } else {
        this.bots.push({
          id: s.id, nickname: 'Bot', team: parseInt(s.id.slice(s.id.lastIndexOf('_') + 1), 10) % 2 === 0 ? ('a' as const) : ('b' as const),
          weaponId: 'pistol', pos: new THREE.Vector3(...s.p), yaw: s.ry, hp: s.hp,
          dead: s.dead, respawnAt: 0, kills: 0, deaths: 0, state: 'patrol' as const,
          wpIdx: 0, targetPos: new THREE.Vector3(), lastSeen: new THREE.Vector3(...s.p),
          velY: 0, nextShootAt: 0, sawPlayerAt: 0,
          lostSightAt: 0, reactionAt: 0, lastPatrolPos: new THREE.Vector3(...s.p),
          lastPatrolCheckAt: 0, difficulty: 'normal' as BotDifficulty,
          reactionDelayMs: 5000, spreadDeg: 5,
        });
        changed = true;
      }
    }
    if (changed) this.rebuildScores();
  }

  localKey(): string {
    return useStore.getState().clientId;
  }

  applyHit(h: { from: string; fromName: string; target: string; dmg: number; part: 'head' | 'body' | 'legs'; weapon: string }): void {
    if (h.target !== this.localKey()) return;
    if (this.dead || performance.now() / 1000 < this.invulnUntil) return;
    this.lastAttackerId = h.from;
    this.takeDamage(h.dmg, null, h.fromName, h.weapon);
  }

  isTeamMode(): boolean {
    return this.mode === 'Team DM';
  }

  // deterministic team for any combatant: bots carry their team, humans are
  // alternating over the sorted client-id list so every client agrees
  teamOf(id: string): 'a' | 'b' {
    const b = this.bots.find((x) => x.id === id);
    if (b) return b.team;
    const ids = [this.localKey(), ...Array.from(this.remotes.keys())].sort();
    const i = ids.indexOf(id);
    return i > 0 && i % 2 === 1 ? 'b' : 'a';
  }

  localTeam(): 'a' | 'b' {
    return this.teamOf(this.localKey());
  }

  teamScores(): { a: number; b: number } {
    const lt = this.localTeam();
    let a = lt === 'a' ? this.kills : 0;
    let b = lt === 'b' ? this.kills : 0;
    for (const bot of this.bots) {
      if (bot.team === 'a') a += bot.kills;
      else b += bot.kills;
    }
    for (const [, r] of this.remotes) {
      if (this.teamOf(r.id) === 'a') a += r.kills;
      else b += r.kills;
    }
    return { a, b };
  }

  applyPresence(players: PresencePlayer[]): void {
    let changed = false;
    for (const p of players) {
      // bot rows published by the host in the database: merge nicknames into
      // the bots received via bot:state broadcasts
      if (p.isBot && p.entityKey) {
        const b = this.bots.find((x) => x.id === p.entityKey);
        if (b && b.nickname !== p.nickname) {
          b.nickname = p.nickname;
          changed = true;
        }
        continue;
      }
      if (p.client_id === this.localKey()) continue;
      let r = this.remotes.get(p.client_id);
      if (!r) {
        r = {
          id: p.client_id,
          nickname: p.nickname || 'Player',
          pos: p.pos ? new THREE.Vector3(...p.pos) : new THREE.Vector3(),
          yaw: 0,
          pitch: 0,
          crouch: false,
          anim: 0,
          kills: 0,
          deaths: 0,
          hp: p.hp ?? 100,
          weaponId: 'pistol',
          lastUpdate: performance.now(),
          snapshots: [],
        };
        this.remotes.set(p.client_id, r);
        changed = true;
      } else if (!r.snapshots.length && p.pos) {
        // seed position for players whose move broadcasts haven't arrived yet
        r.pos.set(...p.pos);
        r.lastUpdate = performance.now();
        changed = true;
      }
      if (p.nickname && r.nickname !== p.nickname) {
        r.nickname = p.nickname;
        changed = true;
      }
    }
    if (changed) this.rebuildScores();
  }

  applyKill(k: { killer: string; killerName: string; victim: string; victimName: string; weapon: string }): void {
    // credit the killer — including this client when it made the kill (the
    // victim broadcasts the event, so the killer would otherwise never score)
    if (k.killer === this.localKey() && k.victim !== this.localKey()) {
      this.onLocalKill(k.victimName);
      this.checkKillLimit('local');
    }
    const r = this.remotes.get(k.killer);
    if (r && r.id !== this.localKey()) r.kills += 1;
    // bot kills are credited by bot id so team scores and the scoreboard match
    const kb = this.bots.find((x) => x.id === k.killer);
    if (kb) kb.kills += 1;
    const vr = this.remotes.get(k.victim);
    if (vr) vr.deaths += 1;
    // victim may be a bot (bot-vs-bot kills seen on non-host clients)
    const vb = this.bots.find((x) => x.id === k.victim);
    if (vb && k.killer !== k.victim) vb.deaths += 1;
    if (k.victim === this.localKey() && k.killer !== this.localKey()) {
      this.killFeed.unshift({ text: `${k.killerName} killed ${this.myName()}`, at: performance.now() });
    } else if (!(k.killer === this.localKey() && (this.mode === 'Gun Game' || this.mode === 'One in the Chamber'))) {
      this.killFeed.unshift({ text: `${k.killerName} killed ${k.victimName}`, at: performance.now() });
    }
    if (this.killFeed.length > 5) this.killFeed.pop();
    this.rebuildScores();
  }

  applyChat(c: { fromName: string; text: string }): void {
    this.chatLog.unshift({ fromName: c.fromName, text: c.text, at: performance.now() });
    if (this.chatLog.length > 6) this.chatLog.pop();
    this.onChat?.();
  }

  takeDamage(dmg: number, _dir: THREE.Vector3 | null, fromName: string, weapon: string): void {
    if (this.dead) return;
    let remaining = dmg;
    if (this.armor > 0) {
      const absorbed = Math.min(this.armor, Math.floor(remaining * 0.5));
      this.armor -= absorbed;
      remaining -= absorbed;
    }
    this.hp -= remaining;
    if (this.hp <= 0) {
      this.hp = 0;
      this.dead = true;
      this.deaths += 1;
      this.respawnAt = performance.now() / 1000 + 3;
      this.killFeed.unshift({ text: `${fromName} killed ${this.myName()}`, at: performance.now() });
      if (this.killFeed.length > 5) this.killFeed.pop();
      net.sendKill({ killer: this.lastAttackerId, killerName: fromName, victim: this.localKey(), victimName: this.myName(), weapon });
      this.rebuildScores();
    }
  }

  myName(): string {
    return useStore.getState().nickname || 'Player';
  }

  // ---------- weapons ----------

  weapon(): WeaponDef {
    return WEAPONS[this.weaponId];
  }

  switchWeapon(id: string): void {
    if (!WEAPONS[id] || id === this.weaponId) return;
    if (!this.buyMenuAllowed() && this.mode !== 'Pistols Only') return;
    if (this.mode === 'Pistols Only' && id !== 'pistol') return;
    this.weaponId = id;
    this.refillAmmo();
  }

  tryShoot(nowSec: number, hitCallback: (hit: { point: THREE.Vector3; part: 'head' | 'body' | 'legs' | null; bot?: Bot; remote?: RemotePlayer }) => void): void {
    if (this.dead || this.matchOver) return;
    const w = this.weapon();
    if (nowSec < this.reloadingUntil || nowSec < this.nextShotAt) return;
    if (this.magAmmo <= 0) {
      this.startReload(nowSec);
      return;
    }
    this.nextShotAt = nowSec + 60 / w.rpm;
    this.magAmmo -= 1;

    // direction with spread + recoil
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ'));
    const spread = w.spread * (this.crouching ? 0.6 : 1) * (this.vel.length() > 1 ? 1.5 : 1);
    dir.x += (Math.random() - 0.5) * spread * 2;
    dir.y += (Math.random() - 0.5) * spread * 2;
    dir.normalize();

    const origin = this.eyePos();
    // find closest target hit
    let bestT = Infinity;
    let bestPart: 'head' | 'body' | 'legs' | null = null;
    let bestBot: Bot | undefined;
    let bestRemote: RemotePlayer | undefined;

    const checkTarget = (tp: THREE.Vector3, crouchFactor: number, isBot: boolean, ref: Bot | RemotePlayer) => {
      // cylinder-ish body: check head sphere, body box, legs
      const bodyBase = tp.y + (crouchFactor ? 0 : 0);
      const headC = new THREE.Vector3(tp.x, bodyBase + (crouchFactor ? 1.15 : 1.62), tp.z);
      const headHit = raySphere(origin, dir, headC, 0.28);
      const bodyMin = new THREE.Vector3(tp.x - 0.45, bodyBase + (crouchFactor ? 0.7 : 1.0), tp.z - 0.45);
      const bodyMax = new THREE.Vector3(tp.x + 0.45, bodyBase + (crouchFactor ? 1.35 : 1.55), tp.z + 0.45);
      const bodyHit = rayAABB(origin, dir, bodyMin, bodyMax);
      const legMin = new THREE.Vector3(tp.x - 0.35, bodyBase + 0.0, tp.z - 0.35);
      const legMax = new THREE.Vector3(tp.x + 0.35, bodyBase + (crouchFactor ? 0.7 : 1.0), tp.z + 0.35);
      const legHit = rayAABB(origin, dir, legMin, legMax);

      const candidates: { t: number; part: 'head' | 'body' | 'legs' }[] = [];
      if (headHit >= 0) candidates.push({ t: headHit, part: 'head' });
      if (bodyHit >= 0) candidates.push({ t: bodyHit, part: 'body' });
      if (legHit >= 0) candidates.push({ t: legHit, part: 'legs' });
      if (candidates.length === 0) return;
      candidates.sort((a, b) => a.t - b.t);
      const c = candidates[0];
      if (c.t < bestT) {
        bestT = c.t;
        bestPart = c.part;
        if (isBot) { bestBot = ref as Bot; bestRemote = undefined; }
        else { bestRemote = ref as RemotePlayer; bestBot = undefined; }
      }
    };

    for (const b of this.bots) {
      if (b.dead) continue;
      checkTarget(b.pos, b.pos.y < 0.5 ? 1 : 0, true, b);
    }
    for (const [, r] of this.remotes) {
      if (performance.now() - r.lastUpdate > 5000) continue;
      checkTarget(r.pos, r.crouch ? 1 : 0, false, r);
    }

    // wall occlusion: compare with map boxes distance
    const wallT = rayWorldBoxes(origin, dir, this.map);
    if (wallT >= 0 && wallT < bestT) {
      hitCallback({ point: origin.clone().add(dir.clone().multiplyScalar(wallT)), part: null });
      return;
    }

    if (bestPart) {
      hitCallback({ point: origin.clone().add(dir.clone().multiplyScalar(bestT)), part: bestPart, bot: bestBot, remote: bestRemote });
    } else {
      hitCallback({ point: origin.clone().add(dir.clone().multiplyScalar(200)), part: null });
    }

    // recoil: kick pitch up, drift yaw
    this.pitch += (w.recoil * 0.012) * (1 + this.shotIndex * 0.08);
    this.yaw += (Math.random() - 0.5) * w.recoil * 0.004;
    this.shotIndex = Math.min(this.shotIndex + 1, 10);
    this.recoilKick = Math.min(this.recoilKick + w.recoil * 0.4, 6);
  }

  endShotRecoil(dt: number): void {
    this.shotIndex = Math.max(0, this.shotIndex - dt * 12);
    this.recoilKick = Math.max(0, this.recoilKick - dt * 18);
    // settle pitch back down
    if (this.pitch > 0 && this.recoilKick <= 0) {
      this.pitch = Math.max(0, this.pitch - dt * 0.5);
    }
  }

  startReload(nowSec: number): void {
    const w = this.weapon();
    // One in the Chamber: no reserve — the chamber refills itself after a delay
    if (this.mode === 'One in the Chamber') {
      if (this.magAmmo >= this.chamberBullets || this.reloadingUntil > 0) return;
      this.reloadingUntil = nowSec + 1.2;
      return;
    }
    if (this.magAmmo >= w.mag || this.reserveAmmo <= 0) return;
    this.reloadingUntil = nowSec + w.reloadSec;
  }

  finishReloadIfNeeded(nowSec: number): void {
    const w = this.weapon();
    if (this.reloadingUntil > 0 && nowSec >= this.reloadingUntil) {
      if (this.mode === 'One in the Chamber') {
        this.magAmmo = this.chamberBullets;
        this.reloadingUntil = 0;
        return;
      }
      const need = w.mag - this.magAmmo;
      const take = Math.min(need, this.reserveAmmo);
      this.magAmmo += take;
      this.reserveAmmo -= take;
      this.reloadingUntil = 0;
    }
  }

  onHitConfirm(hit: { part: 'head' | 'body' | 'legs' | null; bot?: Bot; remote?: RemotePlayer }, nowSec: number): void {
    if (!hit.part) return;
    // Aim mode: only headshots register
    if (this.mode === 'Aim' && hit.part !== 'head') return;
    // Team DM: no friendly fire — shooting a teammate does nothing
    if (hit.bot && this.isTeamMode() && hit.bot.team === this.localTeam()) return;
    if (hit.remote && this.isTeamMode() && this.teamOf(hit.remote.id) === this.localTeam()) return;
    const mult = HITBOX[hit.part];
    const w = this.weapon();
    let dmg = Math.round(w.dmg * mult);
    if (this.mode === 'Insta Kill') dmg = 1000;

    if (hit.bot) {
      const b = hit.bot;
      b.hp -= dmg;
      if (b.hp <= 0 && !b.dead) {
        b.dead = true;
        b.deaths += 1;
        b.respawnAt = nowSec + 3;
        this.onLocalKill(b.nickname);
        // in team mode the local kill also credits the whole team via teamScores()
        this.checkKillLimit('local');
      }
    } else if (hit.remote) {
      net.sendHit({
        from: this.localKey(),
        fromName: this.myName(),
        target: hit.remote.id,
        dmg,
        part: hit.part,
        weapon: w.id,
      });
    }
    this.rebuildScores();
  }

  checkKillLimit(scorer: string): void {
    if (this.matchOver) return;
    if (this.isTeamMode()) {
      const ts = this.teamScores();
      if (ts.a >= this.killLimit || ts.b >= this.killLimit) {
        this.matchOver = true;
        this.winnerId = ts.a >= this.killLimit ? 'team_a' : 'team_b';
        this.onMatchOver?.(this.winnerId);
      }
      return;
    }
    const entry = this.scores.get(scorer);
    const k = scorer === 'local' ? this.kills : (entry?.kills ?? 0);
    if (k >= this.killLimit) {
      this.matchOver = true;
      this.winnerId = scorer;
      this.onMatchOver?.(scorer);
    }
  }

  onLocalKill(victimName: string): void {
    this.kills += 1;
    if (this.mode === 'Gun Game') {
      this.equipLadderStage(this.gunGameStage + 1);
      return;
    }
    if (this.mode === 'One in the Chamber') {
      this.chamberBullets = Math.min(this.chamberBullets + 1, 5);
      this.equipChamber();
      this.magAmmo = this.chamberBullets;
      return;
    }
    this.money += 300;
    this.killFeed.unshift({ text: `${this.myName()} killed ${victimName}`, at: performance.now() });
    if (this.killFeed.length > 5) this.killFeed.pop();
  }

  onBotKillLocal(b: Bot): void {
    // bot killed the local player (host-authoritative bot shooting)
    this.takeDamage(30, null, b.nickname, 'bot');
  }

  // ---------- bot vision ----------

  // ---------- main update ----------

  update(dt: number, canvasEl: HTMLCanvasElement | null): void {
    const nowSec = performance.now() / 1000;
    // fps
    this.fpsFrames++;
    this.fpsTime += dt;
    if (this.fpsTime >= 0.5) {
      this.fps = Math.round(this.fpsFrames / this.fpsTime);
      this.fpsFrames = 0;
      this.fpsTime = 0;
    }

    if (this.matchOver) return;

    this.finishReloadIfNeeded(nowSec);
    this.endShotRecoil(dt);

    // respawn
    if (this.dead && nowSec >= this.respawnAt) this.spawnLocal();

    // look
    if (input.locked && !this.dead) {
      const sens = this.settings.sensitivity * 0.0022;
      this.yaw -= input.mouseDX * sens;
      this.pitch -= input.mouseDY * sens;
      const lim = Math.PI / 2 - 0.02;
      this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
    }
    input.mouseDX = 0;
    input.mouseDY = 0;

    // movement
    const kb = this.settings.keybinds;
    const wish = new THREE.Vector3();
    if (!this.dead && input.locked) {
      if (input.keys.has(kb.forward)) wish.z -= 1;
      if (input.keys.has(kb.back)) wish.z += 1;
      if (input.keys.has(kb.left)) wish.x -= 1;
      if (input.keys.has(kb.right)) wish.x += 1;
    }
    this.crouching = !this.dead && input.keys.has(kb.crouch);
    const sprinting = !this.crouching && input.keys.has(kb.sprint) && wish.z < 0;
    let speed = this.crouching ? CROUCH_W : sprinting ? SPRINT : WALK;

    const moveLen = wish.length();
    if (moveLen > 0) {
      wish.normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
    }

    // horizontal velocity approach
    const target = wish.multiplyScalar(speed);
    this.vel.x += (target.x - this.vel.x) * Math.min(1, dt * 12);
    this.vel.z += (target.z - this.vel.z) * Math.min(1, dt * 12);

    // jump & gravity
    if (!this.dead && input.keys.has(kb.jump) && this.onGround) {
      this.vel.y = JUMP_V;
      this.onGround = false;
    }
    this.vel.y -= GRAVITY * dt;

    // integrate + collide
    this.moveAndCollide(dt);

    // eye height lerp
    // (handled in camera update)

    // shooting
    if (input.shooting && input.locked && !this.dead) {
      this.tryShoot(nowSec, (hit) => this.onHitConfirm(hit, nowSec));
    }

    // reload key
    if (!this.dead && input.keys.has(kb.reload)) {
      this.startReload(nowSec);
    }

    // bots (host, or a client that spawned fallback bots while alone)
    if (this.isHost || this.spawnedBots) this.updateBots(dt, nowSec);

    // network sync
    const moving = Math.hypot(this.vel.x, this.vel.z) > 1.2;
    net.queueMove({
      id: this.localKey(),
      p: [this.pos.x, this.pos.y, this.pos.z],
      ry: this.yaw,
      rp: this.pitch,
      crouch: this.crouching,
      anim: moving ? 1 : 0,
      weapon: this.weaponId,
    });
    if (this.isHost || this.spawnedBots) {
      net.queueBotState(this.bots.map((b) => ({ id: b.id, p: [b.pos.x, b.pos.y, b.pos.z] as [number, number, number], ry: b.yaw, hp: b.hp, dead: b.dead })));
    }

    // interpolate remotes
    const tNow = performance.now();
    for (const [, r] of this.remotes) {
      if (r.snapshots.length >= 2) {
        const [a, b2] = r.snapshots;
        const span = Math.max(1, b2.t - a.t);
        const f = Math.min(1, Math.max(0, (tNow - b2.t) / span + 1));
        r.pos.lerpVectors(a.p, b2.p, f);
        r.yaw = a.ry + shortestAngle(a.ry, b2.ry) * f;
        r.pitch = a.rp + (b2.rp - a.rp) * f;
      } else if (r.snapshots.length === 1) {
        r.pos.lerp(r.snapshots[0].p, Math.min(1, dt * 10));
        r.yaw = r.snapshots[0].ry;
      }
      if (tNow - r.lastUpdate > 8000) {
        this.remotes.delete(r.id);
        this.rebuildScores();
      }
    }

    // expire kill feed / chat
    const nowMs = performance.now();
    this.killFeed = this.killFeed.filter((k) => nowMs - k.at < 6000);
    this.chatLog = this.chatLog.filter((c) => nowMs - c.at < 12000);
  }

  eyePos(): THREE.Vector3 {
    const eye = this.crouching ? EYE_CROUCH : EYE_STAND;
    return new THREE.Vector3(this.pos.x, this.pos.y + eye, this.pos.z);
  }

  moveAndCollide(dt: number): void {
    // Y axis
    this.pos.y += this.vel.y * dt;
    if (this.pos.y <= 0) {
      this.pos.y = 0;
      this.vel.y = 0;
      this.onGround = true;
    }
    // step-up onto boxes: find ground height under position
    const groundY = this.groundHeight(this.pos.x, this.pos.z, this.pos.y);
    if (this.pos.y < groundY) {
      if (this.vel.y <= 0 && groundY - this.pos.y < 1.4) {
        this.pos.y = groundY;
        this.vel.y = 0;
        this.onGround = true;
      }
    }

    // XZ with collision resolve
    const tryMove = (axis: 'x' | 'z') => {
      const old = this.pos[axis];
      this.pos[axis] += (axis === 'x' ? this.vel.x : this.vel.z) * dt;
      for (const b of this.map.boxes) {
        const [w, h, d] = b.s;
        if (w <= 0) continue;
        const topY = b.p[1] + h / 2;
        const bottomY = b.p[1] - h / 2;
        // can we stand on it?
        if (this.pos.y >= topY - 0.05) continue;
        if (bottomY > this.pos.y + 1.7) continue; // can walk under
        const hw = w / 2 + PLAYER_R;
        const hd = d / 2 + PLAYER_R;
        if (this.pos.x > b.p[0] - hw && this.pos.x < b.p[0] + hw && this.pos.z > b.p[2] - hd && this.pos.z < b.p[2] + hd) {
          this.pos[axis] = old;
          if (axis === 'x') this.vel.x = 0;
          else this.vel.z = 0;
          return;
        }
      }
      if (!isInsideBounds(this.map, this.pos.x, this.pos.z)) {
        this.pos[axis] = old;
        if (axis === 'x') this.vel.x = 0;
        else this.vel.z = 0;
      }
    };
    tryMove('x');
    tryMove('z');
  }

  groundHeight(x: number, z: number, currentY: number): number {
    let best = 0;
    for (const b of this.map.boxes) {
      const [w, h, d] = b.s;
      if (w <= 0) continue;
      const topY = b.p[1] + h / 2;
      if (topY > currentY + 0.31) continue; // too high to step
      const hw = w / 2 + PLAYER_R * 0.6;
      const hd = d / 2 + PLAYER_R * 0.6;
      if (x > b.p[0] - hw && x < b.p[0] + hw && z > b.p[2] - hd && z < b.p[2] + hd) {
        if (topY > best) best = topY;
      }
    }
    return best;
  }

  // ---------- bots ----------

  updateBots(dt: number, nowSec: number): void {
    const FOV_HALF = (90 / 2) * (Math.PI / 180);
    const tNow = performance.now();
    // candidate targets: the local player plus every recently-updated remote
    const targets: BotTarget[] = [];
    if (!this.dead) targets.push({ id: 'local', pos: this.pos, crouch: this.crouching, name: this.myName(), isLocal: true, team: this.localTeam() });
    for (const [, r] of this.remotes) {
      if (tNow - r.lastUpdate > 3000 || r.hp <= 0) continue;
      targets.push({ id: r.id, pos: r.pos, crouch: r.crouch, name: r.nickname, isLocal: false, team: this.teamOf(r.id) });
    }
    // bots fight each other too (skip same team in Team DM below)
    for (const ob of this.bots) {
      if (ob.dead) continue;
      targets.push({ id: ob.id, pos: ob.pos, crouch: false, name: ob.nickname, isLocal: false, team: ob.team, bot: ob });
    }

    for (const b of this.bots) {
      if (b.dead) {
        if (nowSec >= b.respawnAt) {
          const p = this.spawnPoint();
          b.pos.copy(p);
          b.hp = MAX_HP;
          b.dead = false;
          b.state = 'patrol';
          b.reactionAt = 0;
        }
        continue;
      }

      // gravity: land on the floor or on top of boxes
      b.velY -= GRAVITY * dt;
      b.pos.y += b.velY * dt;
      if (b.velY <= 0) {
        const g = this.groundHeight(b.pos.x, b.pos.z, b.pos.y + 0.31);
        if (b.pos.y <= g) {
          b.pos.y = g;
          b.velY = 0;
        }
      }

      const eye = new THREE.Vector3(b.pos.x, b.pos.y + 1.6, b.pos.z);
      // find the closest target the bot can actually see
      let best: BotTarget | null = null;
      let bestDir: THREE.Vector3 | null = null;
      let bestDist = Infinity;
      let inFov = false;
      for (const t of targets) {
        // a bot never targets itself
        if (t.id === b.id) continue;
        // team mode: bots never engage their own team
        if (this.isTeamMode() && t.team === b.team) continue;
        const to = t.pos.clone().sub(eye);
        const dist = to.length();
        if (dist > 30 || dist >= bestDist) continue;
        const dirTo = to.normalize();
        const wallT = rayWorldBoxes(eye, dirTo, this.map);
        if (wallT >= 0 && wallT < dist) continue; // blocked by geometry
        best = t;
        bestDir = dirTo;
        bestDist = dist;
        const facing = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, b.yaw, 0, 'YXZ'));
        if (facing.dot(dirTo) >= Math.cos(FOV_HALF)) inFov = true;
      }

      if (best && inFov) {
        b.sawPlayerAt = nowSec;
        b.lostSightAt = 0;
        b.lastSeen.copy(best.pos);
        if (b.state === 'patrol' || b.state === 'chase') {
          // just spotted: enter alert, start reaction timer
          b.state = 'alert';
          b.reactionAt = nowSec + b.reactionDelayMs / 1000;
        }
      } else if (b.state === 'alert' || b.state === 'attack') {
        if (b.lostSightAt === 0) b.lostSightAt = nowSec;
        if (nowSec - b.lostSightAt > 2) {
          // lost LOS for >2s → go look where the target was last seen
          b.state = 'chase';
          b.lostSightAt = 0;
        }
      }

      switch (b.state) {
        case 'alert': {
          // track the player but do NOT shoot until reaction delay elapses
          if (bestDir) b.yaw = Math.atan2(-bestDir.x, -bestDir.z);
          if (nowSec >= b.reactionAt) b.state = 'attack';
          break;
        }
        case 'attack': {
          if (best && bestDir && inFov && nowSec >= b.nextShootAt) {
            b.nextShootAt = nowSec + 0.6;
            this.botShoot(b, best, bestDir, bestDist, nowSec);
          }
          if (bestDir) {
            // strafe a bit while shooting
            const strafe = Math.sin(nowSec * 2) * 0.4;
            this.moveBot(b, bestDir.x * 0.3 + strafe * bestDir.z, dt, bestDist > 10 ? 1 : 0.3, bestDir.z * 0.3 - strafe * bestDir.x);
            b.yaw = Math.atan2(-bestDir.x, -bestDir.z);
            // hop occasionally while fighting
            if (b.pos.y <= 0 && Math.random() < dt * 0.7) b.velY = JUMP_V * 0.7;
          }
          break;
        }
        case 'chase': {
          // move toward last seen position
          const dir = b.lastSeen.clone().sub(b.pos);
          dir.y = 0;
          if (dir.length() < 2 || nowSec - b.sawPlayerAt > 4) {
            b.state = 'patrol';
          } else {
            dir.normalize();
            b.yaw = Math.atan2(-dir.x, -dir.z);
            this.moveBot(b, dir.x, dt, 1.2, dir.z);
            // jump over obstacles while running
            if (b.pos.y <= 0 && Math.random() < dt * 1.2) b.velY = JUMP_V * 0.8;
          }
          break;
        }
        case 'patrol': {
          const wp = this.map.waypoints[b.wpIdx];
          const tw = new THREE.Vector3(wp[0], 0, wp[1]);
          const dir = tw.clone().sub(b.pos);
          dir.y = 0;
          if (dir.length() < 2) {
            b.wpIdx = (b.wpIdx + 1) % this.map.waypoints.length;
          } else {
            dir.normalize();
            b.yaw = Math.atan2(-dir.x, -dir.z);
            this.moveBot(b, dir.x, dt, 1, dir.z);
            if (b.pos.y <= 0 && Math.random() < dt * 0.5) b.velY = JUMP_V * 0.7;
          }
          // stuck check: if the bot barely moved for 1.5s, skip to the next
          // waypoint; if truly frozen for 4s+, jump straight to the waypoint
          // so it can never wedge against geometry permanently.
          if (nowSec - b.lastPatrolCheckAt > 1.5) {
            const distMoved = b.pos.distanceTo(b.lastPatrolPos);
            if (dir.length() >= 2 && distMoved < 0.5) {
              if (distMoved < 0.1 && nowSec - b.lastPatrolCheckAt > 4) {
                const wp2 = this.map.waypoints[(b.wpIdx + 1) % this.map.waypoints.length];
                b.pos.set(wp2[0], 0, wp2[1]);
              }
              b.wpIdx = (b.wpIdx + 1) % this.map.waypoints.length;
            }
            b.lastPatrolPos.copy(b.pos);
            b.lastPatrolCheckAt = nowSec;
          }
          break;
        }
      }
    }
  }

  // Difficulty-driven aim: pick a hitbox with spread from the server's config.
  private botShoot(b: Bot, target: BotTarget, dirTo: THREE.Vector3, dist: number, nowSec: number): void {
    if (dist > 30) return;
    const spreadRad = (b.spreadDeg * (Math.PI / 180)) * (1 + dist / 40);
    const dir = dirTo.clone();
    dir.x += (Math.random() - 0.5) * spreadRad * 2;
    dir.y += (Math.random() - 0.5) * spreadRad * 2;
    dir.z += (Math.random() - 0.5) * spreadRad * 2;
    dir.normalize();

    // fire at head/body/legs with spread-determined odds
    const origin = new THREE.Vector3(b.pos.x, b.pos.y + 1.6, b.pos.z);
    const tp = target.pos;
    const headC = new THREE.Vector3(tp.x, tp.y + (target.crouch ? 1.15 : 1.62), tp.z);
    const headT = raySphere(origin, dir, headC, 0.28);
    const bodyMin = new THREE.Vector3(tp.x - 0.45, tp.y + (target.crouch ? 0.7 : 1.0), tp.z - 0.45);
    const bodyMax = new THREE.Vector3(tp.x + 0.45, tp.y + (target.crouch ? 1.35 : 1.55), tp.z + 0.45);
    const bodyT = rayAABB(origin, dir, bodyMin, bodyMax);
    const legMin = new THREE.Vector3(tp.x - 0.35, tp.y, tp.z - 0.35);
    const legMax = new THREE.Vector3(tp.x + 0.35, tp.y + (target.crouch ? 0.7 : 1.0), tp.z + 0.35);
    const legT = rayAABB(origin, dir, legMin, legMax);

    const candidates: { t: number; part: 'head' | 'body' | 'legs' }[] = [];
    if (headT >= 0) candidates.push({ t: headT, part: 'head' });
    if (bodyT >= 0) candidates.push({ t: bodyT, part: 'body' });
    if (legT >= 0) candidates.push({ t: legT, part: 'legs' });
    if (candidates.length === 0) return;
    candidates.sort((a, b2) => a.t - b2.t);

    const wallT = rayWorldBoxes(origin, dir, this.map);
    if (wallT >= 0 && wallT < candidates[0].t) return; // hit cover
    const dmg = Math.round(22 * HITBOX[candidates[0].part]);
    if (target.isLocal) {
      this.takeDamage(dmg, dir, b.nickname, 'bot');
    } else if (target.bot) {
      // host simulates bot-vs-bot damage directly, then broadcasts the kill
      const ob = target.bot;
      ob.hp -= dmg;
      if (ob.hp <= 0 && !ob.dead) {
        ob.dead = true;
        ob.deaths += 1;
        ob.respawnAt = nowSec + 3;
        b.kills += 1;
        this.killFeed.unshift({ text: `${b.nickname} killed ${ob.nickname}`, at: performance.now() });
        if (this.killFeed.length > 5) this.killFeed.pop();
        net.sendKill({ killer: b.id, killerName: b.nickname, victim: ob.id, victimName: ob.nickname, weapon: 'bot' });
        this.rebuildScores();
        this.checkKillLimit(b.id);
      }
    } else {
      // remote target: broadcast the hit so the owning client applies it
      net.sendHit({
        from: b.id,
        fromName: b.nickname,
        target: target.id,
        dmg,
        part: candidates[0].part,
        weapon: 'bot',
      });
    }
  }

  moveBot(b: Bot, dirX: number, dt: number, speedMul: number, dirZ?: number): void {
    const speed = 4.2 * speedMul;
    const dz = dirZ ?? 0;
    // normalize so diagonal movement isn't faster
    const len = Math.hypot(dirX, dz);
    const mx = len > 1e-6 ? (dirX / len) * speed * dt : 0;
    const mz = len > 1e-6 ? (dz / len) * speed * dt : 0;
    const nx = b.pos.x + mx;
    const nz = b.pos.z + mz;
    let movedX = false;
    let movedZ = false;
    if (!blockedByBox(this.map, nx, b.pos.z, 0.5) && isInsideBounds(this.map, nx, b.pos.z)) {
      b.pos.x = nx;
      movedX = true;
    }
    if (!blockedByBox(this.map, b.pos.x, nz, 0.5) && isInsideBounds(this.map, b.pos.x, nz)) {
      b.pos.z = nz;
      movedZ = true;
    }
    // vertical position is driven by gravity/jump in updateBots
    void movedX;
    void movedZ;
  }

  leaderboard(): ScoreEntry[] {
    const list: ScoreEntry[] = [
      { id: 'local', name: this.myName(), kills: this.kills, deaths: this.deaths, isBot: false, team: this.localTeam() },
      ...this.bots.map((b) => ({ id: b.id, name: b.nickname, kills: b.kills, deaths: b.deaths, isBot: true, team: b.team })),
      ...Array.from(this.remotes.values()).map((r) => ({ id: r.id, name: r.nickname, kills: r.kills, deaths: r.deaths, isBot: false, team: this.teamOf(r.id) })),
    ];
    // remote kills tracked in remotes; local kills/deaths in engine
    list.sort((a, b) => b.kills - a.kills || a.deaths - b.deaths);
    return list;
  }
}

// ---------- ray helpers ----------

function raySphere(o: THREE.Vector3, d: THREE.Vector3, c: THREE.Vector3, r: number): number {
  const oc = o.clone().sub(c);
  const b = oc.dot(d);
  const cc = oc.dot(oc) - r * r;
  const disc = b * b - cc;
  if (disc < 0) return -1;
  const t = -b - Math.sqrt(disc);
  return t >= 0 ? t : -1;
}

function rayAABB(o: THREE.Vector3, d: THREE.Vector3, min: THREE.Vector3, max: THREE.Vector3): number {
  let tmin = -Infinity;
  let tmax = Infinity;
  for (const ax of ['x', 'y', 'z'] as const) {
    if (Math.abs(d[ax]) < 1e-9) {
      if (o[ax] < min[ax] || o[ax] > max[ax]) return -1;
    } else {
      let t1 = (min[ax] - o[ax]) / d[ax];
      let t2 = (max[ax] - o[ax]) / d[ax];
      if (t1 > t2) [t1, t2] = [t2, t1];
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return -1;
    }
  }
  return tmin >= 0 ? tmin : -1;
}

export function rayWorldBoxes(o: THREE.Vector3, d: THREE.Vector3, map: MapDef): number {
  let best = -1;
  for (const b of map.boxes) {
    const [w, h, dd] = b.s;
    if (w <= 0) continue;
    const min = new THREE.Vector3(b.p[0] - w / 2, b.p[1] - h / 2, b.p[2] - dd / 2);
    const max = new THREE.Vector3(b.p[0] + w / 2, b.p[1] + h / 2, b.p[2] + dd / 2);
    const t = rayAABB(o, d, min, max);
    if (t >= 0 && (best < 0 || t < best)) best = t;
  }
  // floor
  if (d.y < -1e-6) {
    const t = -o.y / d.y;
    if (t >= 0 && (best < 0 || t < best)) best = t;
  }
  return best;
}

function shortestAngle(a: number, b: number): number {
  let diff = (b - a) % (Math.PI * 2);
  if (diff > Math.PI) diff -= Math.PI * 2;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return diff;
}
