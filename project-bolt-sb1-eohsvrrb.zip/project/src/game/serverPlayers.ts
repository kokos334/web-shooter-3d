import { getSupabase } from '@/lib/supabase';
import { useStore } from '@/store';
import type { PresencePlayer } from '@/game/net';

export interface SelfState {
  pos: [number, number, number];
  yaw: number;
  hp: number;
  kills: number;
  deaths: number;
  weapon: string;
}

interface ServerPlayerRow {
  client_id: string;
  server_id: string;
  nickname: string;
  pos_x: number;
  pos_y: number;
  pos_z: number;
  yaw: number;
  hp: number;
  kills: number;
  deaths: number;
  is_bot: boolean;
  entity_key: string | null;
  is_dead: boolean;
  updated_at: string;
}

const STALE_MS = 10000;

// Database-backed player list: each client upserts its own row on a heartbeat
// and reads everyone else's rows for the same server. The host also publishes
// its bots here, one row per bot (stable unique client_id per bot), so every
// client sees the same server-side bot roster. Postgres change events push
// updates to all clients instantly.
export function subscribeServerPlayers(
  serverId: string,
  getSelfState: () => SelfState | null,
  getBots: () => { id: string; nickname: string; pos: [number, number, number]; yaw: number; hp: number; dead: boolean }[],
  isHost: () => boolean,
  onPlayers: (players: PresencePlayer[]) => void
): () => void {
  const sb = getSupabase();
  const clientId = useStore.getState().clientId;
  // stable per-bot row key derived from the tab id + bot id; the table's
  // primary key is (client_id, server_id), so every bot gets its own row
  const botRowKey = (botId: string): string => clientId.slice(0, 8) + 'b0t' + botId.replace(/[^a-z0-9]/gi, '').slice(0, 20);

  const upsertSelf = () => {
    const self = getSelfState();
    const st = useStore.getState();
    void sb
      .from('server_players')
      .upsert({
        client_id: clientId,
        server_id: serverId,
        nickname: st.nickname || 'Player',
        pos_x: self?.pos[0] ?? 0,
        pos_y: self?.pos[1] ?? 0,
        pos_z: self?.pos[2] ?? 0,
        yaw: self?.yaw ?? 0,
        hp: self?.hp ?? 100,
        kills: self?.kills ?? 0,
        deaths: self?.deaths ?? 0,
        is_bot: false,
        entity_key: null,
        is_dead: false,
        updated_at: new Date().toISOString(),
      });
  };

  upsertSelf();
  const heartbeat = setInterval(upsertSelf, 3000);

  // host publishes bots so they are server-side shared entities
  const botHeartbeat = setInterval(() => {
    if (!isHost()) return;
    const bots = getBots();
    if (!bots.length) return;
    const now = new Date().toISOString();
    void sb
      .from('server_players')
      .upsert(
        bots.map((b) => ({
          client_id: botRowKey(b.id),
          server_id: serverId,
          nickname: b.nickname,
          entity_key: b.id,
          is_bot: true,
          is_dead: b.dead,
          pos_x: b.pos[0],
          pos_y: b.pos[1],
          pos_z: b.pos[2],
          yaw: b.yaw,
          hp: b.hp,
          kills: 0,
          deaths: 0,
          owner_id: clientId,
          updated_at: now,
        }))
      );
  }, 3000);

  // drop bot rows this client published (called on cleanup)
  const cleanupBots = () => {
    void sb
      .from('server_players')
      .delete()
      .eq('owner_id', clientId)
      .eq('server_id', serverId);
  };

  const refresh = async () => {
    const cutoff = new Date(Date.now() - STALE_MS).toISOString();
    const { data, error } = await sb
      .from('server_players')
      .select('*')
      .eq('server_id', serverId)
      .gte('updated_at', cutoff);
    if (error || !data) return;
    const players: PresencePlayer[] = (data as ServerPlayerRow[]).map((r) => ({
      client_id: r.client_id,
      nickname: r.nickname,
      hp: r.hp,
      weapon: 'pistol',
      team: 'a',
      pos: [r.pos_x, r.pos_y, r.pos_z],
      isBot: r.is_bot,
      entityKey: r.entity_key,
      isDead: r.is_dead,
    }));
    onPlayers(players);
  };

  const ch = sb
    .channel(`server-players:${serverId}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'server_players', filter: `server_id=eq.${serverId}` },
      () => void refresh()
    )
    .subscribe();

  void refresh();

  return () => {
    clearInterval(heartbeat);
    clearInterval(botHeartbeat);
    cleanupBots();
    // remove own human row
    void sb
      .from('server_players')
      .delete()
      .eq('client_id', clientId)
      .eq('server_id', serverId);
    void sb.removeChannel(ch);
  };
}
