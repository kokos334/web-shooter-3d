import { useEffect, useRef } from 'react';
import { useStore } from '@/store';
import { MainMenu } from '@/screens/MainMenu';
import { ServerBrowser } from '@/screens/ServerBrowser';
import { LoadingScreen } from '@/screens/LoadingScreen';
import { ResultsScreen } from '@/screens/ResultsScreen';
import { SettingsScreen } from '@/screens/SettingsScreen';
import { ProfileScreen } from '@/screens/ProfileScreen';
import { JoinCodeScreen } from '@/screens/JoinCodeScreen';
import { NicknameModal } from '@/screens/NicknameModal';
import { Match } from '@/game/components/Match';
import { releaseLock } from '@/game/input';

function App(): React.JSX.Element {
  const screen = useStore((s) => s.screen);
  const joinIntent = useStore((s) => s.joinIntent);
  const currentServer = useStore((s) => s.currentServer);
  const setCurrentServer = useStore((s) => s.setCurrentServer);
  const prevScreen = useRef(screen);

  useEffect(() => {
    if (screen !== 'match' && prevScreen.current === 'match') {
      releaseLock();
    }
    if (screen === 'match') {
      const server = joinIntent?.server ?? currentServer;
      if (server && currentServer?.id !== server.id) setCurrentServer(server);
    }
    prevScreen.current = screen;
  }, [screen, joinIntent, currentServer, setCurrentServer]);

  return (
    <>
      {screen === 'main_menu' && <MainMenu />}
      {screen === 'server_browser' && <ServerBrowser />}
      {screen === 'loading' && <LoadingScreen />}
      {screen === 'match' && (joinIntent?.server ?? currentServer) && (
        <Match
          key={(joinIntent?.server ?? currentServer)!.id}
          server={(joinIntent?.server ?? currentServer)!}
          created={Boolean(joinIntent?.created)}
        />
      )}
      {screen === 'results' && <ResultsScreen />}
      {screen === 'settings' && <SettingsScreen />}
      {screen === 'profile' && <ProfileScreen />}
      {screen === 'join_code' && <JoinCodeScreen />}
      <NicknameModal />
    </>
  );
}

export default App;
